require 'rails_helper'

RSpec.describe Admin::BxBlockDocumentstoragePrivacyPoliciesController, type: :controller do
  render_views
  let(:admin_user) { FactoryBot.create(:admin_user) }
  let(:privacy_policy) {FactoryBot.create(:privacy_policy)}
  let(:privacy_policy_params) do{
        title: 'Privacy Policy',
        description: 'Testing Description for this Privacy Policy'
    }
    end

  before do
    sign_in(admin_user)
  end

    describe '#index' do
        it 'returns a successful index' do
            privacy_policy
            get :index
            expect(response).to be_successful
        end

        it 'renders the index template' do
            privacy_policy
            get :index
            expect(response).to render_template(:index)
        end

        it 'renders correct column' do
            privacy_policy
            get :index
            expect(response.body).to include('Title')
            expect(response.body).to include('Description')
        end

        it 'destroys the old privacy policy when created a new one' do
            post :create, params: {bx_block_documentstorage_privacy_policy: privacy_policy_params}
            expect(response).to redirect_to(admin_bx_block_documentstorage_privacy_policy_path(id: BxBlockDocumentstorage::PrivacyPolicy.last.id))
        end
    end
  

    describe '#new' do
        it 'returns http success for new form' do
            get :new
            expect(response).to have_http_status(:success)
        end

        it 'renders the new template' do
            get :new
            expect(response).to render_template(:new)
        end
    end

    describe '#show' do
        it 'returns http success' do
          get :show, params: { id: privacy_policy.id }
          expect(response).to have_http_status(:success)
          expect(response).to have_http_status(200)
        end
        it 'renders the show template' do
          get :show, params: { id: privacy_policy.id }
          expect(response).to render_template(:show)
        end

        it 'renders correct attributes' do
          get :show, params: { id: privacy_policy.id }
          expect(response.body).to include('Title')
          expect(response.body).to include('Description')
        end
    end
end