# require 'rails_helper'

# RSpec.describe Admin::PaymentAdminsController, type: :controller do
#   render_views
#   let!(:super_admin_user) { FactoryBot.create(:admin_user) }
#   let!(:admin_user) { FactoryBot.create(:admin_user, email: "admin1@gmail.com", role: "admin") }
#   let!(:payment_admin) { FactoryBot.create(:payment_admin) }

#   before do
#     sign_in(super_admin_user)
#   	$admin_flag = true
#   end

#   describe '#index' do
#     context 'when current user is Super Admin' do
#       it 'returns a successful index' do
#         get :index
#         expect(response).to be_successful
#       end

#       it 'renders the index template' do
#         get :index
#         expect(response).to render_template(:index)
#       end

#       it 'renders correct column' do
#         get :index
#         response_body = response.body
#         expect(response_body).to include('Transaction')
#         expect(response_body).to include('Account')
#         expect(response_body).to include('Payment Status')
#         expect(response_body).to include('Payment Method')
#         expect(response_body).to include('User Amount')
#         expect(response_body).to include('Post Creator Amount')
#         expect(response_body).to include('Third Party Amount')
#         expect(response_body).to include('Admin Amount')
#       end
#     end

#     context 'when current user is Admin' do
#       before do
#         sign_in(admin_user)
#         $admin_flag = true
#       end
#       it 'returns an unauthorized error message' do
#         get :index
#         expect(response).to_not be_successful
#       end
#     end
#   end

#   describe '#show' do
#     context 'when current user is super admin' do
#       it 'returns http success' do
#         get :show, params: { id: payment_admin.id }
#         expect(response).to have_http_status(:success)
#       end
#       it 'renders the show template' do
#         get :show, params: { id: payment_admin.id }
#         expect(response).to render_template(:show)
#       end

#       it 'renders correct attributes' do
#         get :show, params: { id: payment_admin.id }
#         response_body = response.body
#         response_body = response.body
#         expect(response_body).to include('Transaction')
#         expect(response_body).to include('Account')
#         expect(response_body).to include('Payment Status')
#         expect(response_body).to include('Payment Method')
#         expect(response_body).to include('User Amount')
#         expect(response_body).to include('Post Creator Amount')
#         expect(response_body).to include('Third Party Amount')
#         expect(response_body).to include('Admin Amount')
#       end
#     end

#     context 'when current user is admin' do
#       before do
#         sign_in(admin_user)
#         $admin_flag = true
#       end
#       it 'returns http failure' do
#         get :show, params: { id: payment_admin.id }
#         expect(response).to have_http_status(302)
#       end
#     end
#   end
# end
