require 'rails_helper'

RSpec.describe Admin::UsersController, type: :controller do
  render_views
  let(:admin_user) { FactoryBot.create(:admin_user) }

  before do
    sign_in(admin_user)
  end

  describe '.link_tag' do
    it 'returns the correct link tag text' do
      expect(Account::Load.link_tag).to eq("Click For Viewing")
    end
  end

  describe '#index' do
    let(:account) { FactoryBot.create(:account) }
    it 'returns a successful index' do
      account
      get :index
      expect(response).to be_successful
    end

    it 'renders the index template' do
      account
      get :index
      expect(response).to render_template(:index)
    end

    it 'renders correct column' do
      account
      get :index
      expect(response.body).to include('Email')
      expect(response.body).to include('First Name')
      expect(response.body).to include('Last Name')
      expect(response.body).to include('Full Phone Number')
      expect(response.body).to include('Activated')
      expect(response.body).to include('Status')
      expect(response.body).to include('Type')
      expect(response.body).to include('Gender')
      expect(response.body).to include('Date Of Birth')
      expect(response.body).to include('height')
      expect(response.body).to include('weight')
      expect(response.body).to include('personality')
      expect(response.body).to include('interests')
      expect(response.body).to include('interested in')
    end
  end

  describe '#new' do
    it 'returns http success for new form' do
      get :new
      expect(response).to have_http_status(:success)
    end

    it 'renders the new template' do
      get :new
      expect(response).to render_template(:new)
    end
  end

  describe '#create' do
  let!(:image_file) { Rack::Test::UploadedFile.new('spec/fixtures/files/test.png', 'image/png', true) }
  let!(:pdf_file) { Rack::Test::UploadedFile.new('spec/fixtures/files/example.pdf', 'application/pdf', true) }
  let!(:video_file) { Rack::Test::UploadedFile.new('spec/fixtures/files/test_video.mp4', 'video/mp4', true) }
    let(:valid_params) do
      {
        first_name: 'John222',
        last_name: 'Doe',
        status: 'regular',
        email: 'test@example.com',
        password: 'Password@123',
        account_role: 'Jobseeker',
        gender: 'Male',
        full_phone_number: '917891278618',
        activated: true,
        type: "EmailAccount",
        privacy_policy: true,
        profile_data_attributes: {
          height_type: "cm", 
          weight_type: "kg", 
          height: 123,
          weight: 230,
          open_for: 'Full-Time',
          seamen_book_number: '1928482623',
          available?: true,
          linkedin_url: 'swdefrgbthnyjm.com',
          salary_range_usd: 10000,
          total_work_experience: 2,
          resume: pdf_file,
          selfie_picture: image_file,
          covid_19_certificate: pdf_file, 
          passport_picture: image_file,
          video_cv: video_file,
          training_and_certifications: [pdf_file],
          health_record: [pdf_file],
          personality: [],
          interests: [],
          interested_in: ["Shore", "Ship"]
        }
      }
    end

    it 'creates a user' do
      FactoryBot.create(:account)
      expect {
        post :create, params: { account: valid_params }
      }.to change(AccountBlock::Account, :count).by(1)
      expect(response).to have_http_status(302)
    end
  end

  describe '#edit' do
    let!(:admin_user_to_edit) { FactoryBot.create(:account, email: "test2@example.com") }

    it 'returns a successful edit form' do
      get :edit, params: { id: admin_user_to_edit.id }
      expect(response).to be_successful
      expect(response).to have_http_status(200)
    end
  end

  describe '#update' do
    let!(:admin_user_to_update) { FactoryBot.create(:account, email: "test3@example.com") }
    let(:update_params) do
      {
        first_name: 'Updated First Name',
        last_name: 'demo',
        full_phone_number: 911234567890
      }
    end

    it 'updates the admin user' do
      put :update, params: { id: admin_user_to_update.id, account: update_params }
      admin_user_to_update.reload
      expect(admin_user_to_update.first_name).to eq('Updated First Name')
      expect(admin_user_to_update.last_name).to eq('demo')
      expect(response).to have_http_status(302)
    end
  end

  describe '#show' do
    let!(:admin_user_to_show) { FactoryBot.create(:account, email: "test3@example.com") }

    it 'returns http success' do
      get :show, params: { id: admin_user_to_show.id }
      expect(response).to have_http_status(:success)
      expect(response).to have_http_status(200)
    end
    it 'renders the show template' do
      get :show, params: { id: admin_user_to_show.id }
      expect(response).to render_template(:show)
    end

    it 'renders correct attributes' do
      get :show, params: { id: admin_user_to_show.id }
      expect(response.body).to include('Email')
      expect(response.body).to include('First Name')
      expect(response.body).to include('Last Name')
      expect(response.body).to include('Full Phone Number')
      expect(response.body).to include('Activated')
      expect(response.body).to include('Status')
      expect(response.body).to include('Type')
      expect(response.body).to include('Gender')
      expect(response.body).to include('Interested In')
      expect(response.body).to include('Open For')
      expect(response.body).to include('Seamen Book Number')
      expect(response.body).to include('height')
      expect(response.body).to include('weight')
      expect(response.body).to include('Height Type')
      expect(response.body).to include('Weight Type')
      expect(response.body).to include('personality')
      expect(response.body).to include('interests')
      expect(response.body).to include('Selfie Picture')
      expect(response.body).to include('resume')
      expect(response.body).to include('Passport Picture')
      expect(response.body).to include('Covid 19 Certificate')
      expect(response.body).to include('Training And Certifications')
      expect(response.body).to include('Health Record')
      expect(response.body).to include('Video Cv')
    end 
  end

  # describe '#destroy' do
  #   let!(:admin_user_to_destroy) { FactoryBot.create(:account, email: "test4@example.com") }

  #   it 'destroys the admin user' do
  #     expect {
  #       delete :destroy, params: { id: admin_user_to_destroy.id }
  #     }.to change(AccountBlock::Account, :count).by(-1)
  #   end
  # end
end
