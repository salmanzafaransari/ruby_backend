require 'rails_helper'

RSpec.describe Admin::PromoCodesController, type: :controller do
	render_views

	let(:admin_user) { FactoryBot.create(:admin_user) }
	before { sign_in(admin_user) }
	let(:formatted_time) { Time.now.strftime("%Y-%m-%d %H:%M:%S") }
	let(:formatted_future_time) { (Time.now+2.months).strftime("%Y-%m-%d %H:%M:%S") }

	before do
		@code = BxBlockCouponCg::CouponCode.create(title: "test3",description: "testing", code: "NW1234", discount_type: "flat", discount: 20.0, valid_from: formatted_time, valid_to: formatted_future_time)
	end

	let!(:coupon_params) do
		{ title: "test3",description: "testing", code: "NW12345", discount_type: "flat", discount: 20.0, valid_from: formatted_time, valid_to: formatted_future_time}
	end

	describe '#index' do
		it "index for coupon code data" do
			get :index
			expect(response).to have_http_status(200)
		end
	end

	describe 'POST#create' do
		it 'should pass params for coupon' do
			post :new, params: { coupon_code: coupon_params }
			expect(response).to have_http_status(200)
		end
	end

	describe 'PUT#edit' do
		it 'edits a coupon code' do
			put :edit, params: { id: @code.id, coupon_code: coupon_params }
			expect(response).to have_http_status(200)
		end
	end

	context 'deletes the coupon code' do
		it 'deletes the particular coupon code' do
			delete :destroy, params: { id: @code.id }
      		expect(response).to redirect_to(admin_promo_codes_path)
		end
	end
end