require 'rails_helper'

RSpec.describe Admin::PaymentTransactionsController, type: :controller do
  render_views
  let!(:super_admin_user) { FactoryBot.create(:admin_user) }
  let!(:admin_user) { FactoryBot.create(:admin_user, email: "admin1@gmail.com", role: "admin") }
  let!(:recruiter_account) { FactoryBot.create(:account, account_role: "Recruiter", email: "eight@test.com") }
  let!(:jobseeker_account) { FactoryBot.create(:account, account_role: "Jobseeker", email: "stu1@test.com") }
  let!(:subscription) { FactoryBot.create(:subscription, advertisement_type: true) }
  let!(:order_trx) { FactoryBot.create(:order_transaction, plan_type: 'advertisement', user_email: 'eight@test.com') }

  before do
    sign_in(super_admin_user)
  end

  describe '#index' do
    it 'returns a successful index' do
      order_trx
      get :index
      expect(response).to be_successful
    end

    it 'renders the index template' do
      order_trx
      get :index
      expect(response).to render_template(:index)
    end

    it 'renders correct column' do
      order_trx
      get :index
      expect(response.body).to include('Payment Type')
      expect(response.body).to include('Amount')
      expect(response.body).to include('Charge Status')
      expect(response.body).to include('user_name')
    end
  end

  describe '#edit' do
    it 'returns a successful edit form' do
      get :edit, params: { id: order_trx.id }
      expect(response).to be_successful
      expect(response.body).to include('order_transaction_amount')
    end

    it 'renders correct plan_type options based on user role' do
      order_trx.update(user_email: recruiter_account.email)
      get :edit, params: { id: order_trx.id }
      expect(response.body).to include('Plan')
      expect(response.body).to match(/option>/)
    end

    it 'renders correct plan_type options based on user role' do
      order_trx.update(user_email: jobseeker_account.email)
      subscription.update_column(:advertisement_type, true)
      get :edit, params: { id: order_trx.id }
      expect(response.body).to include('Plan')
      expect(response.body).to match(/option>/)
    end
  end

  describe '#update_status' do
    let(:success_status) { 'Succeeded Transaction' }

    it 'must update the status of transaction to success' do
      patch :update_status, params: { id: order_trx.id, status: success_status }
      expect(response).to render_template(:payment_received_email)
    end

    it 'must update the status of transaction to failed' do
      order_trx
      FactoryBot.create(:user_subscription, account_id: order_trx.account_id, subscription_id: order_trx.subscription_id)
      patch :update_status, params: { id: order_trx.id, status: 'Failed Transaction' }
      expect(response).to render_template(:payment_failed_email)
    end

    it 'must redirect without doing anything if old and new status matches' do
      order_trx.update_column(:charge_status, success_status)
      patch :update_status, params: { id: order_trx.id, status: success_status }
      expect(response.redirect_url).to eq("http://test.host/admin/payment_transactions/#{order_trx.id}")
    end

    context 'when user requests a payment for plan update' do
      let(:current_user) { FactoryBot.create(:account) }
      let!(:subscription) { FactoryBot.create(:subscription) }
      let!(:subscription2) { FactoryBot.create(:subscription) }
      let!(:order2) { FactoryBot.create(:order, subscription_id: subscription2.id, amount: subscription2.price, sub_total: subscription2.price, account_id: current_user.id) }
      let!(:order_trx2) { FactoryBot.create(:order_transaction, account_id: current_user.id, subscription_id: subscription2.id, order_management_order_id: order2.id, plan_type: 'advertisement') }

      before do
        FactoryBot.create(:user_subscription, subscription_id: subscription.id, account_id: current_user.id)
      end

      it 'must update the new subscription' do
        patch :update_status, params: { id: order_trx2.id, status: success_status }
        expect(response).to render_template(:payment_received_email)
      end
    end

    it 'redirects to index with alert if transaction ID is zero' do
      patch :update_status, params: { id: 0, status: success_status }
      expect(response).to redirect_to(admin_payment_transactions_path)
      expect(flash[:alert]).to eq('Invalid transaction ID')
    end
  end

  describe 'Subscription input field' do
    let(:f) { double('form') }
    let(:advertisement_subscriptions) { [double('Subscription', name: 'Ad Plan 1', id: 1, price: 10), double('Subscription', name: 'Ad Plan 2', id: 2, price: 20)] }
    let(:recruiter_subscriptions) { [double('Subscription', name: 'Recruiter Plan 1', id: 3, price: 30), double('Subscription', name: 'Recruiter Plan 2', id: 4, price: 40)] }
    let(:jobseeker_subscriptions) { [double('Subscription', name: 'Jobseeker Plan 1', id: 5, price: 50), double('Subscription', name: 'Jobseeker Plan 2', id: 6, price: 60)] }

    before do
      allow(f).to receive(:input)
      allow(BxBlockCustomUserSubs::Subscription).to receive(:advertisement_subscription).and_return(advertisement_subscriptions)
      allow(BxBlockCustomUserSubs::Subscription).to receive(:recruiter_signup_subscription).and_return(recruiter_subscriptions)
      allow(BxBlockCustomUserSubs::Subscription).to receive(:jobseeker_signup_subscription).and_return(jobseeker_subscriptions)
    end

    context 'when user role is Recruiter' do
      before { @user_role = 'Recruiter' }

      context 'and plan type is advertisement' do
        let(:plan_type) { 'advertisement' }

        it 'renders advertisement subscription input' do
          expect(f).to receive(:input).with(
            :subscription_id,
            as: :select,
            collection: advertisement_subscriptions.map { |sub| [sub.name, sub.id, { 'data-amount': sub.price }] },
            include_blank: "Select",
            input_html: { id: 'order_transaction_plan_type' },
            multiple: false,
            label: "Plan"
          )
          render_input_field(f, plan_type)
        end
      end

      context 'and plan type is not advertisement' do
        let(:plan_type) { 'other' }

        it 'renders recruiter subscription input' do
          expect(f).to receive(:input).with(
            :subscription_id,
            as: :select,
            collection: recruiter_subscriptions.map { |sub| [sub.name, sub.id, { 'data-amount': sub.price }] },
            include_blank: "Select",
            input_html: { id: 'order_transaction_plan_type' },
            multiple: false,
            label: "Plan"
          )
          render_input_field(f, plan_type)
        end
      end
    end

    context 'when user role is Jobseeker' do
      before { @user_role = 'Jobseeker' }
      let(:plan_type) { 'any' }

      it 'renders jobseeker subscription input' do
        expect(f).to receive(:input).with(
          :subscription_id,
          as: :select,
          collection: jobseeker_subscriptions.map { |sub| [sub.name, sub.id, { 'data-amount': sub.price }] },
          include_blank: "Select",
          input_html: { id: 'order_transaction_plan_type' },
          multiple: false,
          label: "Plan"
        )
        render_input_field(f, plan_type)
      end
    end

    def render_input_field(f, plan_type)
      if @user_role == 'Recruiter'
        if plan_type == 'advertisement'
          f.input :subscription_id, as: :select, collection: BxBlockCustomUserSubs::Subscription.advertisement_subscription.map { |sub| [sub.name, sub.id, { 'data-amount': sub.price }] }, include_blank: "Select", input_html: { id: 'order_transaction_plan_type' }, multiple: false, label: "Plan"
        else
          f.input :subscription_id, as: :select, collection: BxBlockCustomUserSubs::Subscription.recruiter_signup_subscription.map { |sub| [sub.name, sub.id, { 'data-amount': sub.price }] }, include_blank: "Select", input_html: { id: 'order_transaction_plan_type' }, multiple: false, label: "Plan"
        end
      elsif @user_role == 'Jobseeker'
        f.input :subscription_id, as: :select, collection: BxBlockCustomUserSubs::Subscription.jobseeker_signup_subscription.map { |sub| [sub.name, sub.id, { 'data-amount': sub.price }] }, include_blank: "Select", input_html: { id: 'order_transaction_plan_type' }, multiple: false, label: "Plan"
      end
    end
  end
end
