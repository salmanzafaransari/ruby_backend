require 'rails_helper'

RSpec.describe Admin::FaqsController, type: :controller do
  render_views
  let(:admin_user) { FactoryBot.create(:admin_user) }
  let(:tutorial) { FactoryBot.create(:tutorial) }

  before do
    sign_in(admin_user)
  	$admin_flag = true
  end

  describe '#index' do
    it 'returns a successful index and renders the index template' do
			get :index
			expect(response).to be_successful
      expect(response).to render_template(:index)
    end

    it 'renders correct column' do
      tutorial
			get :index
			expect(response.body).to include('Video Title')
			expect(response.body).to include('Video')
			expect(response.body).to include('Created At')
			expect(response.body).to include('Updated At')
    end
  end

  describe '#new' do
    it 'returns http success for new form' do
			get :new
			expect(response).to have_http_status(:success)
    end

    it 'renders the new template' do
			get :new
			expect(response).to render_template(:new)
    end
	end

  describe '#create' do
    let(:valid_params) do
      {
        video_title: "Test video title",
        # video: Rack::Test::UploadedFile.new('spec/fixtures/files/test_video.mp4', 'video/mp4', true)
      }
    end

    it 'creates a tutorial' do
      post :create, params: { tutorial: valid_params }
      expect(BxBlockHelpCentre::Tutorial.all.count).to eq(1)
      expect(response).to have_http_status(302)
    end
  end


  describe '#edit' do
    it 'returns a successful edit form' do
			get :edit, params: { id: tutorial.id }
			expect(response).to be_successful
			expect(response).to have_http_status(200)
    end
	end

  describe "#update" do
    let(:updated_title) { 'Updated Title' }
    let(:updated_params) do
      {
        video_title: updated_title,
        video: Rack::Test::UploadedFile.new('spec/fixtures/files/test_video.mp4', 'video/mp4', true)
      }
    end
    it 'updates a tutorial successfully' do
      put :update, params: { id: tutorial.id, tutorial: updated_params }
      tutorial.reload
      expect(response).to have_http_status(302)
      expect(tutorial.video_title).to eq(updated_title)
    end
  end

  describe "#show" do
    it 'returns http success' do
      get :show, params: { id: tutorial.id }
      expect(response).to have_http_status(:success)
      expect(response).to have_http_status(200)
      expect(response).to render_template(:show)
    end

    it 'renders correct attributes' do
      get :show, params: { id: tutorial.id }
      expect(response.body).to include('Video Title')
      expect(response.body).to include('Video')
    end
  end

  describe "#delete" do
    it 'deletes a tutorial successfully' do
      tutorial
      expect {
        delete :destroy, params: { id: tutorial.id }
      }.to change(BxBlockHelpCentre::Tutorial, :count).by(-1)
    end
  end
end
