require 'rails_helper'

RSpec.describe Admin::AdminUsersController, type: :controller do
  render_views
  let(:admin_user) { FactoryBot.create(:admin_user) }

  before do
    sign_in admin_user
  end

  describe '#index' do
    it 'returns a successful index' do
      get :index
      expect(response).to be_successful
    end

    it 'renders the index template' do
      get :index
      expect(response).to render_template(:index)
    end

    it 'renders correct column' do
      get :index
      response_body = response.body
      expect(response_body).to include('First Name')
      expect(response_body).to include('Last Name')
      expect(response_body).to include('Email')
      expect(response_body).to include('Full Phone Number')
      expect(response_body).to include('Country')
      expect(response_body).to include('Landline Number')
      expect(response_body).to include('Role')
      expect(response_body).to include('activated?')
      expect(response_body).to include('Sign In Count')
      expect(response_body).to include('Created At')
      expect(response_body).to include('Current Sign In At')
      expect(response_body).to include('Ad-Hoc Reports')
      expect(response_body).to include('Number of Jobseekers')
      expect(response_body).to include('Number of Recruiters')
      expect(response_body).to include('Number of Job Postings')
      expect(response_body).to include('Number of Applied Job Postings')
      expect(response_body).to include('Percentage of Applied Job Postings')
    end
  end

  describe '#new' do
    it 'returns http success for new form' do
      get :new
      expect(response).to have_http_status(:success)
    end

    it 'renders the new template' do
      get :new
      expect(response).to render_template(:new)
    end
  end

  describe '#create' do
    let(:valid_params) do
      {
        first_name: 'Super',
        last_name: 'Admin',
        email: 'test@example.com',
        full_phone_number: '919876543210',
        country: 'India',
        landline_number: '07923451234',
        password: 'password',
        password_confirmation: 'password',
        role: 'super_admin',
        activated: true
      }
    end

    it 'creates a user' do
      expect {
        post :create, params: { admin_user: valid_params }
      }.to change(AdminUser, :count).by(1)
      expect(response).to have_http_status(302)
    end
  end

  describe '#edit' do
    let!(:admin_user_to_edit) { FactoryBot.create(:admin_user, email: "test2@example.com") }

    it 'returns a successful edit form' do
      get :edit, params: { id: admin_user_to_edit.id }
      expect(response).to be_successful
      expect(response).to have_http_status(200)
    end
  end

  describe '#update' do
    let!(:admin_user_to_update) { FactoryBot.create(:admin_user, email: "test3@example.com") }
    let(:update_params) do
      {
        role: 'admin',
        activated?: true
      }
    end

    it 'updates the admin user' do
      put :update, params: { id: admin_user_to_update.id, admin_user: update_params }
      admin_user_to_update.reload
      expect(admin_user_to_update.role).to eq('admin')
      expect(admin_user_to_update.activated?).to eq(true)
    end
  end

  describe '#show' do
    let!(:admin_user_to_show) { FactoryBot.create(:admin_user, email: "test3@example.com") }

    it 'returns http success' do
      get :show, params: { id: admin_user_to_show.id }
      expect(response).to have_http_status(:success)
    end
    it 'renders the show template' do
      get :show, params: { id: admin_user_to_show.id }
      expect(response).to render_template(:show)
    end

    it 'renders correct attributes' do
      get :show, params: { id: admin_user_to_show.id }
      response_body = response.body
      expect(response_body).to include('First Name')
      expect(response_body).to include('Last Name')
      expect(response_body).to include('Email')
      expect(response_body).to include('Full Phone Number')
      expect(response_body).to include('Country')
      expect(response_body).to include('Landline Number')
      expect(response_body).to include('Role')
      expect(response_body).to include('activated')
      expect(response_body).to include('Sign In Count')
      expect(response_body).to include('Created At')
      expect(response_body).to include('Updated At')
      expect(response_body).to include('Current Sign In At')
    end 
  end
end
