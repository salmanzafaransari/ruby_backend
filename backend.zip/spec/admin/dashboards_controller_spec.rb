require 'rails_helper'

RSpec.describe Admin::DashboardController, type: :controller do
  render_views
  let(:admin_user) { FactoryBot.create(:admin_user) }
   let(:jobseeker) { FactoryBot.create(:account) }
   let(:recruiter) { FactoryBot.create(:account, account_role: "Recruiter") }

    before do
      sign_in(admin_user)
    end

    it "displays registered users details" do
      get :index
      expect(response).to have_http_status(:success)
      expect(response.body).to include("Registered Users Details")
    end
end
