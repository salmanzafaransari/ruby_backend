require 'rails_helper'

RSpec.describe Admin::BxBlockCustomUserSubsSubscriptionsController, type: :controller do
  render_views
  let(:admin_user) { FactoryBot.create(:admin_user) }
  let(:subscription) { FactoryBot.create(:subscription) }
  let!(:ad){FactoryBot.create(:ads_frequency)}

  before do
    sign_in(admin_user)
  end

  describe '#index' do
    it 'returns a successful index' do
      subscription
      get :index
      expect(response).to be_successful
    end

    it 'renders the index template' do
      subscription
      get :index
      expect(response).to render_template(:index)
    end

    it 'renders correct column' do
      subscription
      get :index
      expect(response.body).to include('Name')
      expect(response.body).to include('Price')
      expect(response.body).to include('Valid For')
      expect(response.body).to include('Description')
      expect(response.body).to include('advertisement_type')
    end
  end

  describe '#new' do
    it 'returns http success for new form' do
      get :new
      expect(response).to have_http_status(:success)
    end

    it 'renders the new template' do
      get :new
      expect(response).to render_template(:new)
    end
  end

  describe '#create' do
    let(:valid_params) do
      {
        name: 'Prime Promotion Plan',
        description: '{"benefit1": "Max 5 jobs can be promoted"}',
        price: 100,
        currency: 'usd',
        valid_for: 12,
        advertisement_type: true,
        max_advertisements: 7,
        ads_frequency_id: ad&.id
      }
    end

    it 'creates a Subscription plan' do
      expect {
        post :create, params: { subscription: valid_params }
      }.to change(BxBlockCustomUserSubs::Subscription, :count).by(1)
      expect(response).to have_http_status(302)
    end
  end

  describe '#edit' do
    it 'returns a successful edit form' do
      get :edit, params: { id: subscription.id }
      expect(response).to be_successful
      expect(response).to have_http_status(200)
    end
  end

  describe '#update' do
    let(:update_params) do
      {
        name: 'Updated promotion plan',
        price: 200,
        max_promotions: 8,
        advertisement_type: true,
        max_advertisements: 6,
        ads_frequency_id: ad&.id
      }
    end

    let(:update_params2) do
      {
        advertisement_type: false,
        max_advertisements: 5
      }
    end

    it 'updates the admin user' do
      put :update, params: { id: subscription.id, subscription: update_params }
      subscription.reload
      expect(subscription.name).to eq(update_params[:name])
      expect(subscription.price).to eq(update_params[:price])
      expect(response).to have_http_status(302)
    end

    it 'updates the ads frequency id field to nil' do
      put :update, params: {id: subscription.id, subscription: update_params2}
      subscription.reload
      expect(subscription&.ads_frequency_id).to eq(nil)
    end
  end

  describe '#show' do
    it 'returns http success' do
      get :show, params: { id: subscription.id }
      expect(response).to have_http_status(:success)
      expect(response).to have_http_status(200)
    end
    it 'renders the show template' do
      get :show, params: { id: subscription.id }
      expect(response).to render_template(:show)
    end

    it 'renders correct attributes' do
      get :show, params: { id: subscription.id }
      expect(response.body).to include('Name')
      expect(response.body).to include('Description')
      expect(response.body).to include('Price')
      expect(response.body).to include('Valid For')
      expect(response.body).to include('advertisement_type')
    end 
  end
end
