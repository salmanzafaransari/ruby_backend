require 'rails_helper'

RSpec.describe Admin::JoblistingsController, type: :controller do
  render_views
  let(:admin_user) { FactoryBot.create(:admin_user) }
    let(:category1) { FactoryBot.create(:category, name: "Test category") }
    let(:category2) { FactoryBot.create(:category, name: "Test category2") }
    let(:sub_category1) { FactoryBot.create(:sub_category, name: "Test Sub Category", category_id: category1.id) }

  before do
    sign_in(admin_user)
  	$admin_flag = true
  end

	describe "GET new_recruiter_assignment" do
		let(:joblisting) { FactoryBot.create(:joblisting) }
		it "renders a form to assign recruiter to the joblisting" do
			get :new_recruiter_assignment, params: {id: joblisting.id}
			expect(response).to render_template("admin/joblistings/_new_recruiter_assignment")
		end
	end

	describe "PATCH assign_recruiter" do
		let(:recruiter) { FactoryBot.create(:account, account_role: "Recruiter") }
		let(:joblisting) { FactoryBot.create(:joblisting) }
		it "assigns a recruiter to joblisting" do
			patch :assign_recruiter, params: { id: joblisting.id, bx_block_joblisting_joblisting: { account_id: recruiter.id } }
			joblisting.reload

			expect(joblisting.account_id).to eq(recruiter.id)
			expect(response).to redirect_to(admin_joblisting_path(joblisting))
			expect(flash[:notice]).to eq('Recruiter assigned successfully!')
		end
	end

	describe '#index' do
    let(:joblisting) { FactoryBot.create(:joblisting) }
    it 'returns a successful index' do
			joblisting
			get :index
			expect(response).to be_successful
    end

    it 'renders the index template' do
			joblisting
			get :index
			expect(response).to render_template(:index)
    end

    it 'renders correct column' do
			joblisting
			get :index
			expect(response.body).to include('Job Title')
			expect(response.body).to include('Location')
			expect(response.body).to include('Duration Of Position')
			expect(response.body).to include('Vessel Type')
			expect(response.body).to include('Categories')
			expect(response.body).to include('Created At')
			expect(response.body).to include('Updated At')
    end

    it 'destroy the joblisting and renders the index again' do
			joblisting
			delete :destroy, params: { id: joblisting.id }
			expect(response).to redirect_to(admin_joblistings_path)
    end
	end

	describe '#new' do
    it 'returns http success for new form' do
			get :new
			expect(response).to have_http_status(:success)
    end

    it 'renders the new template' do
			get :new
			expect(response).to render_template(:new)
    end
	end

	describe '#create' do
    let(:invalid_params_with_category) do
			{
				job_title: '',
				required_certifications: 'A, B',
				positions: 'Post A, Post B',
				joblisting_categories_attributes: [
					{ category_id: category1.id }
				]
			}
    end
    let(:valid_params) do
			{
				job_title: 'Software',
				position_location: 'India',
				salary_range: '$80,000 - $100,000',
				duration_of_position: 'Full-time',
				months_on_board: 12,
				months_off_board: 2,
				open_position: 'Technology',
				vessel_type: 'N/A',
				location: 'India',
				currency: 'usd',
				starting_condition: Date.today.strftime("%d/%m/%Y"),
				job_description: 'Testing this Description',
				responsibilities: 'Tester1',
				required_certifications: 'Cert A, Cert B',
				positions: 'Position A, Position B',
				joblisting_categories_attributes: [
					{ category_id: category1.id }
				]
			}
    end

    context "when valid params are passed" do
			it 'creates a joblisting' do
				expect {
					post :create, params: { bx_block_joblisting_joblisting: valid_params }
				}.to change(BxBlockJoblisting::Joblisting, :count).by(1)
				expect(response).to have_http_status(302)
			end
    end

    context "when invalid params are passed with atleast one joblisting category" do
			it 'returns field related error' do
				expect {
					post :create, params: { bx_block_joblisting_joblisting: invalid_params_with_category }
				}.to change(BxBlockJoblisting::Joblisting, :count).by(0)
				expect(flash[:error]).to eq("There are errors in the form. Please check the fields.") 
				expect(response).to have_http_status(:ok)
			end
    end

    context "when invalid params are passed without any joblisting category" do
			it 'returns category need to be present error' do
				expect {
					post :create, params: { bx_block_joblisting_joblisting: { job_title: 'Title',
						required_certifications: 'A, B', positions: 'Post A, Post B' } }
				}.to change(BxBlockJoblisting::Joblisting, :count).by(0)
				expect(flash[:error]).to eq("Atleast One Category Need To Be Present")
				expect(response).to have_http_status(:ok)
			end
    end
  end

	describe '#edit' do
    let(:joblisting) { FactoryBot.create(:joblisting) }

    it 'returns a successful edit form' do
			get :edit, params: { id: joblisting.id }
			expect(response).to be_successful
			expect(response.body).to include('Atleast One Joblisting category should be present')
			expect(response).to have_http_status(200)
    end
	end

	describe '#update' do
    let!(:joblisting2) { FactoryBot.create(:joblisting) }
    let(:invalid_update_params_with_category) do
			{
				job_title: '',
				positions: joblisting2&.positions&.first,
				joblisting_categories_attributes: [
					{ category_id: joblisting2.joblisting_categories.last.category.id }
				]
			}
    end
    # let(:invalid_update_params_without_category) do
    #     {
    #         joblisting_categories_attributes: [
    #             { category_id: joblisting2.joblisting_categories.last.category.id, _destroy: true },
    #             { category_id: joblisting2.joblisting_categories.first.category.id, _destroy: true }
    #         ]
    #     }
    # end
    let(:valid_update_params) do
			{
				job_title: 'Updated job title',
				job_description: 'demo description updated',
				positions: joblisting2&.positions&.first
			}
    end

    context "when valid params are passed" do
			it 'updates the joblisting' do
				put :update, params: { id: joblisting2.id, bx_block_joblisting_joblisting: valid_update_params }
				joblisting2.reload
				expect(joblisting2.job_title).to eq('Updated job title')
				expect(joblisting2.job_description).to eq('demo description updated')
				expect(response).to have_http_status(302)
			end
    end

    context "when invalid params are passed with atleast one joblisting category" do
			it 'returns "Please check the fields" error.' do
				put :update, params: { id: joblisting2.id, bx_block_joblisting_joblisting: invalid_update_params_with_category }
				joblisting2.reload
				expect(joblisting2.job_title).to eq('Software Engineer')
				expect(flash[:error]).to eq("There are errors in the form. Please check the fields.")
				expect(response).to have_http_status(200)
			end
    end

    # context "when invalid params are passed without joblisting category" do
    #     it 'returns "Atleast one category need to be present" error' do
    #         put :update, params: { id: joblisting2.id, bx_block_joblisting_joblisting: invalid_update_params_without_category }
    #         joblisting2.reload
    #         expect(joblisting2.job_title).to eq('Software Engineer')
    #         expect(flash[:error]).to eq("Atleast One Category Need To Be Present") 
    #         expect(response).to have_http_status(302)
    #     end
    # end
	end

  describe '#show' do
    let!(:joblisting) { FactoryBot.create(:joblisting) }

    it 'returns http success' do
			get :show, params: { id: joblisting.id }
			expect(response).to have_http_status(:success)
			expect(response).to have_http_status(200)
    end

    it 'renders the show template' do
			get :show, params: { id: joblisting.id }
			expect(response).to render_template(:show)
    end

    it 'renders correct attributes' do
    	get :show, params: { id: joblisting.id }
			expect(response.body).to include('Job Title')
			expect(response.body).to include('Duration Of Position')
			expect(response.body).to include('Vessel Type')
			expect(response.body).to include('Salary Range')
			expect(response.body).to include('Location')
			expect(response.body).to include('Starting Condition')
			expect(response.body).to include('Job Description')
			expect(response.body).to include('Responsibilities')
			expect(response.body).to include('Categories')
    end
  end
end
