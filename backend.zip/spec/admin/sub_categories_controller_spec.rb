# require 'rails_helper'

# RSpec.describe Admin::SubCategoriesController, type: :controller do
#   render_views
#   let(:admin_user) { FactoryBot.create(:admin_user) }
#   let(:category) { FactoryBot.create(:category) }
#   let!(:sub_category_to_edit) { FactoryBot.create(:sub_category, name: "Sub Category test", category_id: category.id) }

#   before do
#     sign_in(admin_user)
#   end

#   describe '#index' do
#     let(:sub_category) {FactoryBot.create(:sub_category, category_id: category.id,
#                         name: 'Test Sub_Category')}
#     it 'returns a successful index' do
#       sub_category
#       get :index
#       expect(response).to be_successful
#     end

#     it 'renders the index template' do
#       sub_category
#       get :index
#       expect(response).to render_template(:index)
#     end

#     it 'renders correct column' do
#       sub_category
#       get :index
#       expect(response.body).to include('Name')
#       expect(response.body).to include('Category')
#       expect(response.body).to include('Created At')
#       expect(response.body).to include('Updated At')
#     end
#   end

#   describe '#new' do
#     it 'returns http success for new form' do
#       get :new
#       expect(response).to have_http_status(:success)
#     end

#     it 'renders the new template' do
#       get :new
#       expect(response).to render_template(:new)
#     end
#   end

#   describe '#create' do
#     let(:valid_params) do
#       {
#         name: "Test Sub Category 2",
#         category_id: category.id
#       }
#     end

#     it 'creates a user' do
#       expect {
#         post :create, params: { sub_category: valid_params }
#       }.to change(BxBlockCategories::SubCategory, :count).by(1)
#       expect(response).to have_http_status(302)
#     end
#   end

#   describe '#edit' do
#     it 'returns a successful edit form' do
#       get :edit, params: { id: sub_category_to_edit.id }
#       expect(response).to be_successful
#       expect(response).to have_http_status(200)
#     end
#   end

#   describe '#update' do
#     let(:update_params) do
#       {
#         name: 'Updated Sub Category Name',
#       }
#     end

#     it 'updates the admin user' do
#       put :update, params: { id: sub_category_to_edit.id, sub_category: update_params }
#       sub_category_to_edit.reload
#       expect(sub_category_to_edit.name).to eq('Updated Sub Category Name')
#       expect(response).to have_http_status(302)
#     end
#   end

#   describe '#show' do
#     it 'returns http success' do
#       get :show, params: { id: sub_category_to_edit.id }
#       expect(response).to have_http_status(:success)
#       expect(response).to have_http_status(200)
#     end
#     it 'renders the show template' do
#       get :show, params: { id: sub_category_to_edit.id }
#       expect(response).to render_template(:show)
#     end

#     it 'renders correct attributes' do
#       get :show, params: { id: sub_category_to_edit.id }
#       expect(response.body).to include('Name')
#       expect(response.body).to include('Category')
#       expect(response.body).to include('Created At')
#       expect(response.body).to include('Updated At')
#     end 
#   end
# end
