require 'rails_helper'

RSpec.describe Admin::AdsFrequenciesController, type: :controller do
  render_views
  let(:admin_user) { FactoryBot.create(:admin_user) }
  let(:ads_frequency) { FactoryBot.create(:ads_frequency) }
  before do
    sign_in(admin_user)
  end

  describe '#index' do
    it 'returns a successful index' do
      ads_frequency
      get :index
      expect(response).to be_successful
    end

    it 'renders the index template' do
      ads_frequency
      get :index
      expect(response).to render_template(:index)
    end

    it 'renders correct column' do
      ads_frequency
      get :index
      expect(response.body).to include('Name')
      expect(response.body).to include('Rank')
    end
  end

  describe '#new' do
    it 'returns http success for new form' do
      get :new
      expect(response).to have_http_status(:success)
    end

    it 'renders the new template' do
      get :new
      expect(response).to render_template(:new)
    end
  end

  describe '#create' do
    let(:valid_params) do
      {
        name: '5th Priority',
        rank: 5
      }
    end

    it 'creates an ads frequency' do
      expect {
        post :create, params: { ads_frequency: valid_params }
      }.to change(BxBlockCustomAds::AdsFrequency, :count).by(1)
      expect(response).to have_http_status(302)
    end
  end

  # describe '#edit' do
  #   it 'returns a successful edit form' do
  #     get :edit, params: { id: ads_frequency.id }
  #     expect(response).to be_successful
  #     expect(response).to have_http_status(200)
  #   end
  # end

  describe '#update' do
    let(:update_params) do
      {
        name: '4 per 100',
        rank: 4
      }
    end

    it 'updates the admin user' do
      put :update, params: { id: ads_frequency.id, ads_frequency: update_params }
      ads_frequency.reload
      expect(ads_frequency.name).to eq('4 per 100')
      expect(ads_frequency.rank).to eq(4)
      expect(response).to have_http_status(302)
    end
  end

  describe '#show' do
    it 'returns http success' do
      get :show, params: { id: ads_frequency.id }
      expect(response).to have_http_status(:success)
      expect(response).to have_http_status(200)
    end
    it 'renders the show template' do
      get :show, params: { id: ads_frequency.id }
      expect(response).to render_template(:show)
    end

    it 'renders correct attributes' do
      get :show, params: { id: ads_frequency.id }
      expect(response.body).to include('Name')
      expect(response.body).to include('Rank')
    end 
  end

  describe '#destroy' do
    it 'destroys the ads frequency' do
      ads_frequency
      expect {
        delete :destroy, params: { id: ads_frequency.id }
      }.to change(BxBlockCustomAds::AdsFrequency, :count).by(-1)
    end

    it 'must not destroy the ads frequency' do
      FactoryBot.create(:subscription, ads_frequency_id: ads_frequency.id)
      expect {
        delete :destroy, params: { id: ads_frequency.id }
      }.to change(BxBlockCustomAds::AdsFrequency, :count).by(0)
    end
  end
end
