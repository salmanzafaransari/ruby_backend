require 'rails_helper'

RSpec.describe BxBlockProfile::ChangePasswordValidator do
  let(:account_id) { FactoryBot.create(:account).id }
  let(:password) { 'Admin1234' }
  let(:new_password) { 'Newpassword1234' }
  let(:account_block) {AccountBlock::Account}
  let(:account) { FactoryBot.create(:account) }

  describe '#validate' do
    context 'with valid parameters' do
      it 'does not add any errors' do
        validator = described_class.new(account.id, password, new_password)
        allow(account_block).to receive(:find_by).with(id: account.id).and_return(account)
        allow(account).to receive(:authenticate).with(password).and_return(true)

        validator.validate

        expect(validator.errors).to be_empty
      end
    end

    context 'with missing account' do
      it 'adds error' do
        validator = described_class.new(account_id, password, new_password)
        allow(account_block).to receive(:find_by).with(id: account_id).and_return(nil)

        validator.validate

        expect(validator.errors.full_messages).to eq(['Account not found'])
      end
    end

    context 'with invalid password' do
      it 'adds an error' do
        validator = described_class.new(account.id, password, new_password)
        allow(account_block).to receive(:find_by).with(id: account.id).and_return(account)
        allow(account).to receive(:authenticate).with(password).and_return(false)

        validator.validate

        expect(validator.errors.full_messages).to eq(["Invalid password"])
      end
    end

    context 'with invalid new password format' do
      it 'return an error' do
        validator = described_class.new(account.id, password, 'invalid_new_password')
        allow(account_block).to receive(:find_by).with(id: account.id).and_return(account)
        allow(account).to receive(:authenticate).with(password).and_return(true)

        validator.validate

        expect(validator.errors.full_messages).to eq(['New password is invalid'])
      end
    end
  end
end
