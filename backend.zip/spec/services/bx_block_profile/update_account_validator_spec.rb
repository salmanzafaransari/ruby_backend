require 'rails_helper'

RSpec.describe BxBlockProfile::UpdateAccountValidator do
  let(:account_id) { 1 }
  let(:params) { {} }
  let(:account_block) {AccountBlock::Account}

  describe '#validate' do
    context 'with valid parameters' do
      let(:account) { FactoryBot.create(:account) } 

      it 'does not add any errors' do
        validator = described_class.new(account_id, params)
        allow(account_block).to receive(:find_by).with(id: account_id).and_return(account)

        validator.validate

        expect(validator.errors).to be_empty
      end
    end

    context 'with missing account' do
      it 'return error' do
        validator = described_class.new(account_id, params)
        allow(account_block).to receive(:find_by).with(id: account_id).and_return(nil)

        validator.validate

        expect(validator.errors.full_messages).to eq(['Account not found'])
      end
    end

    context 'with invalid password' do
      let(:params) { { current_password: 'Admin1234', new_password: 'new_password' } }
      let(:validator) { described_class.new(account_id, params) }
      let(:change_password_validator) { instance_double(BxBlockProfile::ChangePasswordValidator) }

      it 'adds error' do
        allow(account_block).to receive(:find_by).with(id: account_id).and_return(FactoryBot.create(:account)) # Assuming you have a factory defined for Account
        allow(BxBlockProfile::ChangePasswordValidator).to receive(:new).with(account_id, params[:current_password], params[:new_password]).and_return(change_password_validator)
        allow(change_password_validator).to receive(:valid?).and_return(false)
        allow(change_password_validator).to receive(:errors).and_return({ base: 'Invalid credentials' })

        validator.validate

        expect(validator.errors.full_messages).to eq(['Invalid credentials'])
      end
    end

    context 'with invalid email' do
      let(:params) { { new_email: 'invalid_email' } }
      let(:validator) { described_class.new(account_id, params) }
      let(:change_email_validator) { instance_double(BxBlockProfile::ChangeEmailValidator) }

      it 'return an error' do
        allow(account_block).to receive(:find_by).with(id: account_id).and_return(FactoryBot.create(:account)) # Assuming you have a factory defined for Account
        allow(BxBlockProfile::ChangeEmailValidator).to receive(:new).with(account_id, params[:new_email]).and_return(change_email_validator)
        allow(change_email_validator).to receive(:valid?).and_return(false)
        allow(change_email_validator).to receive(:errors).and_return({ new_email: 'is invalid' })

        validator.validate

        expect(validator.errors.full_messages).to eq(['New email is invalid'])
      end
    end
  end

  describe '#attributes' do
    let(:account) { FactoryBot.create(:account, first_name: 'John', last_name: 'Doe', full_phone_number: '+123456789') } # Assuming you have a factory defined for Account
    let(:params) { { first_name: 'Jane', full_phone_number: '+987654321' } }
    let(:validator) { described_class.new(account_id, params) }

    it 'returns the attributes that are present and valid' do
      allow(account_block).to receive(:find_by).with(id: account_id).and_return(account)

      validator.validate

      expect(validator.attributes).to eq({ first_name: 'Jane', full_phone_number: '+987654321' })
    end
  end
end
