require 'rails_helper'

RSpec.describe AccountBlock::PasswordValidation do
  describe '.regex' do
    it 'matches the expected regex pattern' do
      expect(described_class.regex).to match('Abcdefg1')
      expect(described_class.regex).to match('Password123')
      expect(described_class.regex).not_to match('password')
      expect(described_class.regex).not_to match('abcdefg')
      expect(described_class.regex).not_to match('ABCDEFG')
    end
  end

  describe '.regex_string' do
    it 'returns the regex pattern as a string' do
      expect(described_class.regex_string).to eq('^(?=.*[A-Z])(?=.*[0-9])(?=.*[a-z]).{8,}$')
    end
  end

  describe '.rules' do
    it 'returns the password validation rules' do
      expect(described_class.rules).to eq('should be a minimum of 8 characters long, contain both uppercase and lowercase characters, at least one digit')
    end
  end

  describe '#validate' do
    context 'with a valid password' do
      let(:password) { 'Abcdefg1' }
      let(:validator) { described_class.new(password) }

      it 'does not add any errors' do
        validator.validate

        expect(validator.errors).to be_empty
      end
    end

    context 'with an invalid password' do
      let(:password) { 'password' }
      let(:validator) { described_class.new(password) }

      it 'adds an error' do
        validator.validate

        expect(validator.errors.full_messages).to eq(['Password should be a minimum of 8 characters long, contain both uppercase and lowercase characters, at least one digit'])
      end
    end
  end
end
