require 'rails_helper'

RSpec.describe BxBlockCustomAds::Advertisement, type: :model do

  describe "table name" do
    it { expect(described_class.table_name).to eq("advertisements") }
  end

  describe "associations" do
    it { should belong_to(:account).class_name("AccountBlock::Account") }
    it { should belong_to(:joblisting).class_name("BxBlockJoblisting::Joblisting") }
  end

  describe '#set_ads_count' do
  let!(:account){FactoryBot.create(:account, account_role: 'Recruiter')}
  let!(:joblisting){FactoryBot.create(:joblisting, account_id: account.id)}
  let!(:joblisting2){FactoryBot.create(:joblisting, account_id: account.id)}
  let!(:advertisement1){FactoryBot.create(:advertisement, account_id: account.id, joblisting_id: joblisting.id)}  
    context 'when advertisement is present earlier for a user' do
      it 'must set the job count and ads count to new advertisements' do
        advertisement1.update_column(:ads_count, 4)
        advertisement2 = FactoryBot.create(:advertisement, account_id: account.id, joblisting_id: joblisting2.id,
                                        ads_count: nil, jobs_count: nil)
        expect(advertisement2.ads_count).to eq(advertisement1.ads_count)
      end
    end

    context 'when advertisement is not present' do
      it 'must set the job count and ads count to default' do
        advertisement1.destroy
        advertisement2 = FactoryBot.create(:advertisement, account_id: account.id, joblisting_id: joblisting2.id)
        expect(advertisement2.ads_count).to eq(1)
      end
    end
  end
end