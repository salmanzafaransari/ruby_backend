require 'rails_helper'

RSpec.describe BxBlockCustomAds::AdsFrequency, type: :model do

  describe "table name" do
    it { expect(described_class.table_name).to eq("ads_frequencies") }
  end
end