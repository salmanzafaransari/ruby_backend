require 'rails_helper'

RSpec.describe AdminUser, type: :model do
	let(:admin_user) { FactoryBot.build(:admin_user) }

	describe 'valid params' do
		it 'sends a verification email when email is changed' do
			# admin_user.email = 'new@example.com'
			# expect {
			# 	admin_user.save
			# }.to have_enqueued_mail(BxBlockAdmin::SuperAdminMailer).with(super_admin_email_changed: admin_user)
		end

		it 'does not send a verification email when email is not changed' do
			expect {
				admin_user.save
			}.not_to have_enqueued_mail
		end
	end
end
  