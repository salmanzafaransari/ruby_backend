require 'rails_helper'

RSpec.describe BxBlockHelpCentre::Tutorial, type: :model do

  describe "table name" do
    it { expect(described_class.table_name).to eq("tutorials") }
  end

  describe "validations" do
    it { should validate_presence_of(:video_title) }
    # it { should validate_presence_of(:video) }
  end
end
