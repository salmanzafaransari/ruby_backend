require 'rails_helper'

RSpec.describe BxBlockProfile::PassportAndVisaDetail, type: :model do

  describe "associations" do
    it { should belong_to(:cv).class_name("BxBlockProfile::Cv").inverse_of(:passport_and_visa_detail) }
  end

  # describe "validations" do
  #   # it { should validate_presence_of(:sid) }
  #   it { should validate_presence_of(:passport_number) }
  #   # it { should validate_presence_of(:us_visa) }
  #   it { should validate_presence_of(:expiry_date) }
  # end

  describe "table name" do
    it { expect(described_class.table_name).to eq("passport_and_visa_details") }
  end
end
