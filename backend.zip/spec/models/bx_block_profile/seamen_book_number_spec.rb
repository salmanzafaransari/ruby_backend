require 'rails_helper'

RSpec.describe BxBlockProfile::SeamenBookNumber, type: :model do

  describe "associations" do
    it { should belong_to(:cv).class_name("BxBlockProfile::Cv").inverse_of(:seamen_book_numbers) }
  end

  # describe "validations" do
  #   it { should validate_presence_of(:seamen_book_number) }
  #   it { should validate_presence_of(:place_of_issue) }
  #   it { should validate_presence_of(:issue_date) }
  #   it { should validate_presence_of(:expiry_date) }
  # end

  describe "table name" do
    it { expect(described_class.table_name).to eq("seamen_book_numbers") }
  end
end
