require 'rails_helper'

RSpec.describe BxBlockProfile::Cv, type: :model do

  describe "associations" do
    it { should belong_to(:account).class_name("AccountBlock::Account").inverse_of(:cv) }
    it { should have_one(:passport_and_visa_detail).class_name("BxBlockProfile::PassportAndVisaDetail").inverse_of(:cv).dependent(:destroy) }
    it { should have_many(:seamen_book_numbers).class_name("BxBlockProfile::SeamenBookNumber").inverse_of(:cv).dependent(:destroy) }
    it { should have_many(:professional_acedemic_qualifications).class_name("BxBlockProfile::ProfessionalAcedemicQualification").inverse_of(:cv).dependent(:destroy) }
    it { should have_many(:licence_certificates_of_competencies).class_name("BxBlockProfile::LicenceCertificatesOfCompetency").inverse_of(:cv).dependent(:destroy) }
    it { should have_many(:stcw_value_added_courses).class_name("BxBlockProfile::StcwValueAddedCourse").inverse_of(:cv).dependent(:destroy) }
    it { should have_many(:work_experiences).class_name("BxBlockProfile::WorkExperience").inverse_of(:cv).dependent(:destroy) }
  end

  describe "validations" do
    it { should validate_presence_of(:bio) }
    it { should validate_presence_of(:first_name) }
    # it { should validate_presence_of(:last_name) }
    # it { should validate_presence_of(:full_phone_number) }
    # it { should validate_presence_of(:email) }
    # it { should validate_presence_of(:rank) }
    # it { should validate_presence_of(:date_of_birth) }
    # it { should validate_presence_of(:place_of_birth) }
    # it { should validate_presence_of(:nationality) }
    # it { should validate_presence_of(:city) }
    # it { should validate_presence_of(:nearest_intl_airport) }
  end

  describe "table name" do
    it { expect(described_class.table_name).to eq("cvs") }
  end

  describe "accepts_nested_attributes_for" do
    it { should accept_nested_attributes_for(:passport_and_visa_detail).allow_destroy(true) }
    it { should accept_nested_attributes_for(:seamen_book_numbers).allow_destroy(true) }
    it { should accept_nested_attributes_for(:professional_acedemic_qualifications).allow_destroy(true) }
    it { should accept_nested_attributes_for(:licence_certificates_of_competencies).allow_destroy(true) }
    it { should accept_nested_attributes_for(:stcw_value_added_courses).allow_destroy(true) }
    it { should accept_nested_attributes_for(:work_experiences).allow_destroy(true) }
  end

  describe '#valid_phone_number' do
    context 'when number is wrong' do
      let(:cv){FactoryBot.create(:cv)}
      it 'must give error message' do
        cv.update(full_phone_number: "+221234567890")
        expect(cv.errors[:full_phone_number]&.first).to include('Invalid or Unrecognized Phone Number')
      end
    end
  end
end
