require 'rails_helper'

RSpec.describe BxBlockProfile::LicenceCertificatesOfCompetency, type: :model do

  describe "associations" do
    it { should belong_to(:cv).class_name("BxBlockProfile::Cv").inverse_of(:licence_certificates_of_competencies) }
  end

  describe "table name" do
    it { expect(described_class.table_name).to eq("licence_certificates_of_competencies") }
  end
end