require 'rails_helper'

RSpec.describe BxBlockProfile::ProfessionalAcedemicQualification, type: :model do

  describe "associations" do
    it { should belong_to(:cv).class_name("BxBlockProfile::Cv").inverse_of(:professional_acedemic_qualifications) }
  end

  describe "table name" do
    it { expect(described_class.table_name).to eq("professional_acedemic_qualifications") }
  end

  describe "validations" do
    it { should validate_presence_of(:course).on(:update) }
    it { should validate_presence_of(:institution).on(:update) }
    it { should validate_presence_of(:qualification).on(:update) }
    it { should validate_presence_of(:grade).on(:update) }
    it { should validate_presence_of(:start_date).on(:update) }
    it { should validate_presence_of(:end_date).on(:update) }
  end
end
