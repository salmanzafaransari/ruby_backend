require 'rails_helper'

RSpec.describe BxBlockProfile::StcwValueAddedCourse, type: :model do

  describe "associations" do
    it { should belong_to(:cv).class_name("BxBlockProfile::Cv").inverse_of(:stcw_value_added_courses) }
  end

  describe "table name" do
    it { expect(described_class.table_name).to eq("stcw_value_added_courses") }
  end
end