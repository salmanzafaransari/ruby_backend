require 'rails_helper'

RSpec.describe BxBlockCategories::SubCategory, type: :model do
  # describe "associations" do
  #   it { should belong_to(:parent).class_name("BxBlockCategories::SubCategory").optional }
  # end
  describe 'associations' do
    it { should belong_to(:category).class_name("BxBlockCategories::Category").with_foreign_key("category_id") }
    it { should have_many(:joblisting_sub_categories).class_name("BxBlockCategories::JoblistingSubCategory").dependent(:destroy) }
  end

  describe "validations" do
    it { should validate_presence_of(:name) }
    # it { should validate_uniqueness_of(:category) }
  end

  describe "table name" do
    it { expect(described_class.table_name).to eq("sub_categories") }
  end
end
