require 'rails_helper'

RSpec.describe BxBlockCategories::JoblistingCategory, type: :model do
    describe 'associations' do
        it { should belong_to(:category).class_name("BxBlockCategories::Category") }
        it { should belong_to(:joblisting).class_name("BxBlockJoblisting::Joblisting") }
        it { should have_many(:joblisting_sub_categories).class_name("BxBlockCategories::JoblistingSubCategory").dependent(:delete_all) }
        it { should have_many(:sub_categories).through(:joblisting_sub_categories).class_name("BxBlockCategories::SubCategory") }
    end

    describe "validations" do
        it { should validate_presence_of(:category) }
        # it { should validate_uniqueness_of(:name) }
    end

    describe "table name" do
        it { expect(described_class.table_name).to eq("joblisting_categories") }
    end

end
