# spec/models/bx_block_profile_bio/profile_bio_spec.rb

require 'rails_helper'

RSpec.describe BxBlockProfileBio::ProfileBio, type: :model do
  describe 'file uploads' do
    let!(:pdf_name) {'example.pdf'}
    let!(:image_name) {'test.png'}
    let!(:profile_bio) { FactoryBot.create(:profile_bio) }
		let!(:pdf_file) { Rails.root.join('spec', 'fixtures', 'files', pdf_name) }
		let!(:image_file) { Rails.root.join('spec', 'fixtures', 'files', image_name) }
    let!(:prof_id) {profile_bio.id}
    it 'should upload and store the covid_19_certificate' do
      expect(profile_bio.covid_19_certificate.present?).to be_truthy
      profile_bio.covid_19_certificate = File.open(pdf_file)
      profile_bio.save!
      expect(profile_bio.covid_19_certificate).to be_present
      expect(profile_bio.covid_19_certificate.url).to include(pdf_name)
    end

    it 'should remove the uploaded file when covid_19_certificate is destroyed' do
      file = CarrierWave::SanitizedFile.new({
        tempfile: File.open(pdf_file.to_s),
        filename: pdf_name
      })
      profile_bio.covid_19_certificate = file
      profile_bio.save!
      expect(profile_bio.covid_19_certificate).to be_present
      profile_bio.destroy
      profile = BxBlockProfileBio::ProfileBio.find_by(id: prof_id)
      expect(profile.try(:covid_19_certificate)).to be_blank
    end


		it 'should upload and store the health_record' do
      expect(profile_bio.health_record.present?).to be_truthy
      profile_bio.health_record = [File.open(pdf_file)]
      profile_bio.save!
      expect(profile_bio.health_record).to be_present
      expect(profile_bio.health_record.first&.url).to include(pdf_name)
    end


		# it 'should upload and store the training_and_certifications' do
    #   expect(profile_bio.training_and_certifications.present?).to be_truthy
    #   profile_bio.training_and_certifications = [File.open(pdf_file)]
    #   profile_bio.save!
    #   expect(profile_bio.training_and_certifications).to be_present
    #   expect(profile_bio.training_and_certifications.first&.url).to include(pdf_name)
    # end


		it 'should upload and store the resume' do
      expect(profile_bio.resume.present?).to be_truthy
      profile_bio.resume = File.open(pdf_file)
      profile_bio.save!
      expect(profile_bio.resume).to be_present
      expect(profile_bio.resume.url).to include(pdf_name)
    end

    it 'should remove the uploaded file when resume is destroyed' do
      profile_bio.resume = File.open(pdf_file)
      profile_bio.save!
      expect(profile_bio.resume).to be_present
      profile_bio.destroy
      profile_2 = BxBlockProfileBio::ProfileBio.find_by(id: prof_id)
      expect(profile_2.try(:resume)).to be_blank
    end


		it 'should upload and store the passport_picture' do
      expect(profile_bio.passport_picture.present?).to be_truthy
      profile_bio.passport_picture = File.open(image_file)
      profile_bio.save!
      expect(profile_bio.passport_picture).to be_present
      expect(profile_bio.passport_picture.url).to include(image_name)
    end

    it 'should remove the uploaded file when passport_picture is destroyed' do
      profile_bio.passport_picture = File.open(image_file)
      profile_bio.save!
      expect(profile_bio.passport_picture).to be_present
      profile_bio.destroy
      profile_3 = BxBlockProfileBio::ProfileBio.find_by(id: prof_id)
      expect(profile_3.try(:passport_picture)).to be_blank
    end


		it 'should upload and store the selfie_picture' do
      expect(profile_bio.selfie_picture.present?).to be_truthy
      profile_bio.selfie_picture = File.open(image_file)
      profile_bio.save!
      expect(profile_bio.selfie_picture).to be_present
      expect(profile_bio.selfie_picture.url).to include(image_name)
    end

    it 'should remove the uploaded file when selfie_picture is destroyed' do
      profile_bio.selfie_picture = File.open(image_file)
      profile_bio.save!
      expect(profile_bio.selfie_picture).to be_present
      profile_bio.destroy
      profile_4 = BxBlockProfileBio::ProfileBio.find_by(id: prof_id)
      expect(profile_4.try(:selfie_picture)).to be_blank
    end
  end
end
