require 'rails_helper'

RSpec.describe BxBlockDocumentstorage::PrivacyPolicy, type: :model do
  
  let(:privacy_policy) {FactoryBot.create(:privacy_policy)}

  describe "table name" do
    it { expect(described_class.table_name).to eq("privacy_policies") }
  end

  describe 'constants' do
    # it 'defines the COLOR CODE constant' do
    #   expect(BxBlockDocumentstorage::PrivacyPolicy::COLOR_CODES).to eq({ "Red" => "0xFF0000", "Blue" => "0x0000FF", "Green" => "0x00FF00" })
    # end

    it 'defines the TITLE constant' do
      expect(BxBlockDocumentstorage::PrivacyPolicy::TITLE).to eq(["Terms and Conditions", "Privacy Policy"])
    end
  end

  describe '#update' do
    context 'when updating description or title to nil' do
      # it 'must give presence error of can\'t be blank' do
      #   expect { privacy_policy.update!(description: nil) }.to raise_error(ActiveRecord::RecordInvalid, "Validation failed: Description can't be blank")
      # end

      it 'must give presence error of can\'t be blank' do
        expect { privacy_policy.update!(title: nil) }.to raise_error(ActiveRecord::RecordInvalid, "Validation failed: Title can't be blank")
      end
    end
  end

  describe '#perform_ocr' do
    context 'when create policy using PDF' do
      it 'must give presence error of can\'t be blank' do
        privacy_policy.update(file_for_description: fixture_file_upload('/files/test.pdf', 'txt/pdf'))
        privacy_policy.perform_ocr
        expect(privacy_policy.description).to eq('test description')
      end
    end
  end
end
