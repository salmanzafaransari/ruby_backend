require 'rails_helper'

RSpec.describe AccountBlock::Account, type: :model do
	before(:each) do
		@account = FactoryBot.create(:account)
	end
	
  describe 'associations' do
    it "should have a user profile bio" do
      @account.should respond_to(:profile_bio)
    end

    it "should have the black listed user" do
			@account.should respond_to(:blacklist_user)    
		end
	end

  describe 'validations' do
    it { should validate_presence_of(:password) }
    it { should validate_length_of(:password).is_at_least(8) }
    it { should allow_value('Abc12345').for(:password) }
    it { should_not allow_value('password').for(:password) }
    it { should validate_presence_of(:email) }
    it { should validate_presence_of(:first_name).on(:update) }
    it { should validate_presence_of(:last_name).on(:update) }
    it { should_not allow_value(911234).for(:full_phone_number).on(:update) }
    it { should allow_value(911234567890).for(:full_phone_number).on(:update) }
    it { should validate_presence_of(:account_role).on(:create) }
  end

  describe 'enums' do
    it { should define_enum_for(:account_role).with_values(%i[Jobseeker Recruiter]) }
    it { should define_enum_for(:status).with_values(%i[regular suspended deleted deactivate]) }
    it { should define_enum_for(:gender).with_values(%i[Male Female]) }
  end

  describe 'scopes' do
    it '.active returns active accounts' do
      account1 = FactoryBot.create(:account, activated: true)
      account2 = FactoryBot.create(:account, activated: false)
      expect(AccountBlock::Account.active).to include(account1)
      expect(AccountBlock::Account.active).not_to include(account2)
    end

    it '.recruiters returns accounts with account_role "Recruiter"' do
      recruiter = FactoryBot.create(:account, account_role: 'Recruiter')
      jobseeker = FactoryBot.create(:account, account_role: 'Jobseeker')
      expect(AccountBlock::Account.recruiters).to include(recruiter)
      expect(AccountBlock::Account.recruiters).not_to include(jobseeker)
    end

    it '.jobseekers returns accounts with account_role "Jobseeker"' do
      recruiter = FactoryBot.create(:account, account_role: 'Recruiter')
      jobseeker = FactoryBot.create(:account, account_role: 'Jobseeker')
      expect(AccountBlock::Account.jobseekers).to include(jobseeker)
      expect(AccountBlock::Account.jobseekers).not_to include(recruiter)
    end

    it '.existing_accounts returns accounts with status "regular" or "suspended"' do
      regular = FactoryBot.create(:account, status: 'regular')
      suspended = FactoryBot.create(:account, status: 'suspended')
      deleted = FactoryBot.create(:account, status: 'deleted')
      expect(AccountBlock::Account.existing_accounts).to include(regular)
      expect(AccountBlock::Account.existing_accounts).to include(suspended)
      expect(AccountBlock::Account.existing_accounts).not_to include(deleted)
    end
  end

  describe 'callbacks' do
    it 'parses full_phone_number before validation' do
      account = FactoryBot.create(:account, full_phone_number: '+11234567890')
      account.valid?
      expect(account.full_phone_number).to eq('+11234567890')
    end

    it 'generates unique_auth_id before create' do
      account = FactoryBot.create(:account)
      expect(account.unique_auth_id).to be_present
    end

    it 'sets blacklist_user after save if is_blacklisted has changed' do
      account = FactoryBot.create(:account)
      account.update(is_blacklisted: true)
      expect(account.blacklist_user).to be_present
    end

    it 'deletes all the jobs before recruiter account deletion' do
      recruiter = FactoryBot.create(:account, account_role: 'Recruiter')
      joblisting = FactoryBot.create(:joblisting, account_id: recruiter.id)
      response = recruiter.destroy
      expect(BxBlockJoblisting::Joblisting.find_by_id(recruiter.id)).to eq(nil)
    end
  end
end
