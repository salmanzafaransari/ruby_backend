require 'rails_helper'

RSpec.describe BxBlockCustomUserSubs::Subscription, type: :model do
    describe '#associations' do
        it{should have_many(:user_subscriptions).class_name('BxBlockCustomUserSubs::UserSubscription')}
        it{should have_many(:accounts).through(:user_subscriptions).class_name('AccountBlock::Account')}
        it{should have_one_attached(:image)}
    end

    describe '#validation' do
    let!(:plan) { FactoryBot.create(:subscription) }
        context 'when name is blank' do
            it 'must give error message for blank name' do
                plan.name = nil
                expect(plan).to be_invalid
                expect(plan.errors.messages[:name]).to include('can\'t be blank')
            end
        end

        context 'when description is blank' do
            it 'must give error message for blank description' do
                plan.description = {}
                expect(plan).to be_invalid
                plan.validate
                expect(plan.errors.messages[:subscription]).to include('At least One Benefit Should be There For Any Plan')
            end
        end

        context 'when description is incorrect' do
            it 'must give error message for blank description' do
                plan.description = {"1": "something test", '2':'something 2'}
                expect(plan).to be_invalid
                plan.validate
                expect(plan.errors.messages[:description]).to include("Please provide correct format: {\"1\": \"some benefit\", \"2\": \"some benefit 2\"}")
            end
        end

        context 'when price is blank' do
            it 'must give error message for no price given' do
                plan.price = nil
                expect(plan).to be_invalid
                expect(plan.errors.messages[:price]).to include('can\'t be blank')
            end
        end
    end


end