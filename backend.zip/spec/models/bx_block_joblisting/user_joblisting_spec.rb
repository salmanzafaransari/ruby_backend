require 'rails_helper'

RSpec.describe BxBlockJoblisting::UserJoblisting, type: :model do

  describe "associations" do
    it { should belong_to(:joblisting).class_name("BxBlockJoblisting::Joblisting") }
    it { should belong_to(:account).class_name("AccountBlock::Account").inverse_of(:user_joblistings) }
  end

  describe "table name" do
    it { expect(described_class.table_name).to eq("user_joblistings") }
  end

  describe 'enums' do
    it { should define_enum_for(:status).with_values(%i[applied viewed shortlisted rejected in_progress]) }
  end

  define "validations" do
    it { should validate_presence_of(:full_name) }
    it { should validate_presence_of(:email) }
    it { should validate_presence_of(:full_phone_number) }
    it { should validate_presence_of(:resume) }
  end
end
