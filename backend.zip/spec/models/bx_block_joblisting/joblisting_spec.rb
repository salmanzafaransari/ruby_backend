require 'rails_helper'

RSpec.describe BxBlockJoblisting::Joblisting, type: :model do
  describe 'constants' do
    # it 'defines the POSITION_LOCATION constant' do
    #   expect(BxBlockJoblisting::Joblisting::POSITION_LOCATION).to eq(['ship', 'shore'])
    # end

    it 'defines the POSITIONS constant' do
      expect(BxBlockJoblisting::Joblisting::POSITIONS).to eq(["Contractual", "Temporary", "Permanent"])
    end 

    # it 'defines the DURATION_OF_POSITION constant' do
    #   expect(BxBlockJoblisting::Joblisting::DURATION_OF_POSITION).to eq(['Contractual', 'Temporary',
    #     'Permanent'])
    # end

    it 'defines the OPEN_POSITION constant' do
      expect(BxBlockJoblisting::Joblisting::OPEN_POSITION).to eq(['ship', 'shore'])
    end

    
    it 'defines the JOB_TITLE constant' do
      expect(BxBlockJoblisting::Joblisting::JOB_TITLE).to eq(["Able Bodied Seaman","Additional 3rd Officer","Additional Master","Additional Second Engineer","Anchor Handler","Bosun","Chief Cook","Chief Engineer","Chief Officer","Crew","Crew Officer","Deck Cadet","Deck Fitter","Accounts Executive","Accounts Manager","Accounts Officer","Accounts Payable Executive","Accounts Receivable Executive","Ashore Company Security Officer","Commercial Director","Commercial Manager","Company Information Security Officer","Compliance Manager","Crewing Director","Crewing Executive","Crewing manager","Designated Person","Documentation executive","Environment Manager","Environmental Superintendent","Finance Director","Finance Manager","Fleet Manager","Fleet Personnel manager","Fleet Personnel officer","HR Executive","HR Manager","HR Officer","Invoices Manager","ISO Certification Manager","IT Manager","IT Officer","Managing Director","Marine Director","Marine Executive","Marine Manager","Marine Superintendent","MLC Officer","Office Assistant","Office Manager","Payroll Manager","Personnel Manager","Planned Maintenance Manager","Planned Maintenance Officer","Purchase Executive","Purchase Manager","QHSE Executive","QHSE Manager","Receptionist","Technical Director","Technical Executive","Technical Manager","Technical Superintendent","Training Director","Training Executive","Training Manager","Training Superintendent","Vessel Accountant","Vessel Accounts Manager","Vessel Manager","Vessel Operator","Voyage analyst","Voyage Manager"])
    end

    it 'defines the VESSEL_TYPE constant' do
      expect(BxBlockJoblisting::Joblisting::VESSEL_TYPE).to eq(["ASPHALT / BITUMEN Tanker", "Bulk Carrier",
        "Chemical Tanker", "Container", "GEN Cargo / Multi-Purpose Vessel", "LNG Carrier", "LPG Carrier",
        "Offshore Vessel", "Oil / Chemical Tanker", "Oil Tanker - Barge", "Oil Tanker",
        "Supply Vessel / Tug Boat / AHTS","Other"])
    end

    it 'defines the PLACEHOLDER constant' do
      expect(BxBlockJoblisting::Joblisting::PLACEHOLDER).to eq("Enter only number")
    end

    # it 'defines the REQUIRED_CERTIFICATIONS constant' do
    #   expect(BxBlockJoblisting::Joblisting::REQUIRED_CERTIFICATIONS).to eq(['abc', '123', 'xyz'])
    # end
  end

  describe "associations" do
    it { should have_many(:joblisting_categories).class_name("BxBlockCategories::JoblistingCategory").dependent(:delete_all) }
    it { should have_many(:categories).through(:joblisting_categories).class_name("BxBlockCategories::Category")}
  end

  describe "accepts_nested_attributes_for" do
    it { should accept_nested_attributes_for(:joblisting_categories).allow_destroy(true) }
  end

  describe "table name" do
    it { expect(described_class.table_name).to eq("joblistings") }
  end

  describe 'joblisting_categories count check' do
    let(:category) {FactoryBot.create(:category)}
    let(:sub_category) {FactoryBot.create(:sub_category, category: category)}
    let(:title) {'Software Engineer'}
    let(:place) {'New York'}
    let(:start_date) {Date.today.strftime("%d/%m/%Y")}
    before do
      $admin_flag = true
    end

    context 'when joblisting attributes are not added' do
      
     
      let(:invalid_params) do
        {
                job_title: title,
                position_location: place,
                salary_range: '$80,000 - $100,000',
                duration_of_position: 'Full-time',
                months_on_board: 12,
                months_off_board: 2,
                open_position: 'Technology',
                vessel_type: 'N/A',
                location: 'Remote',
                currency: 'usd',
                starting_condition: start_date,
                job_description: 'Testing this Description',
                responsibilities: 'Tester1',
                required_certifications: ['Cert A', 'Cert B'],
                positions: ['Position A', 'Position B']
        }
      end

      it 'must give error message'do
        joblisting = BxBlockJoblisting::Joblisting.create(invalid_params)
        joblisting.validate
        expect(joblisting.errors[:joblisting_categories]).to include("error")
      end
    end

    context 'when joblisting attributes are added' do
      let(:valid_params) do
        {
          job_title: title,
          position_location: place,
          salary_range: '$80,000 - $100,000',
          duration_of_position: 'Full-time',
          months_on_board: 12,
          months_off_board: 2,
          open_position: 'Technology',
          vessel_type: 'N/A',
          location: 'Remote',
          currency: 'usd',
          starting_condition: start_date,
          job_description: 'Testing this Description',
          responsibilities: 'Tester1',
          required_certifications: ['Cert A', 'Cert B'],
          positions: ['Position A', 'Position B'],
          joblisting_categories: [
            BxBlockCategories::JoblistingCategory.new(category_id: category.id, sub_category_ids: [sub_category.id])
          ]
        }
      end

      it 'must not give error' do
        joblisting = BxBlockJoblisting::Joblisting.create(valid_params)
        joblisting.validate
        expect(joblisting.errors[:joblisting_categories]).to be_empty
      end

      it 'must give error for updating certification or positions field to nil' do
        joblisting1 = BxBlockJoblisting::Joblisting.create(valid_params)
        joblisting1.update_attributes(positions: [])
        expect(joblisting1.errors[:positions].first).to include("can't be blank")
      end

      it 'must save the dusration with NA value for no value passed' do
        valid_params[:duration_of_position] = ""
        joblisting2 = BxBlockJoblisting::Joblisting.create(valid_params)
        expect(joblisting2&.duration_of_position).to eq("NA")
      end
    end
  end

  describe 'class methods' do
    context '.valid_date?' do
      it 'returns true for a valid date string' do
        expect(BxBlockJoblisting::Joblisting.valid_date?((Date.today + 2.days).strftime("%d/%m/%Y"))).to be true
      end

      it 'returns false for an invalid date string' do
        expect(BxBlockJoblisting::Joblisting.valid_date?('invalid_date')).to be false
      end
    end
  end
end
