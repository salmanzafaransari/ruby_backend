require 'rails_helper'

RSpec.describe BxBlockProfile::ChangePasswordCommand do
  let(:account) { FactoryBot.create(:account) }
  let(:old_password) {'Admin1234'}

  describe '#execute' do
    context 'with valid parameters' do
      it 'changes the password' do
        old_password = account.password
        new_password = 'Newpassword123'
  
        result = described_class.execute(account.id, old_password, new_password)
				
        expect(result).to eq([:created, [{ account: { id: account.id, email: account.email }, new_password: new_password }]])
        expect(account.reload.authenticate(new_password)).to be_truthy
      end
    end
  
    context 'with missing current password' do
      it 'returns error' do
        new_password = 'new_password'
  
        result = described_class.execute(account.id, nil, new_password)
  
        expect(result).to eq([:unprocessable_entity, ['Current password is required.']])
        expect(account.reload.authenticate(new_password)).to be_falsey
      end
    end
  
    context 'with invalid parameters' do
      it 'returns an error' do
        old_password = 'old_password'
        new_password = 'new_password'
  
        allow_any_instance_of(BxBlockProfile::ChangePasswordValidator).to receive(:valid?).and_return(false)
        allow_any_instance_of(BxBlockProfile::ChangePasswordValidator).to receive_message_chain(:errors, :full_messages).and_return(['Invalid password.'])
  
        result = described_class.execute(account.id, old_password, new_password)
  
        expect(result).to eq([:unprocessable_entity, ['Invalid password.']])
        expect(account.reload.authenticate(new_password)).to be_falsey
      end
    end
  
    context 'when password update fails' do
      it 'error is return' do
        old_password = 'old_password'
        new_password = 'new_password'
  
        allow(account).to receive(:update).and_return(false)
  
        result = described_class.execute(account.id, old_password, new_password)
  
        expect(result).to eq([:unprocessable_entity, ["Invalid password", "New password is invalid"]])
        expect(account.reload.authenticate(new_password)).to be_falsey
      end
    end
  end
end
