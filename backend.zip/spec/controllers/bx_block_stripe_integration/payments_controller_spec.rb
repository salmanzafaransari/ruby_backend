require 'rails_helper'
require 'spec_helper'

RSpec.describe BxBlockStripeIntegration::PaymentsController, type: :controller do
	let!(:current_user) { FactoryBot.create(:account) }
	let!(:subscription){FactoryBot.create(:subscription)}
	let!(:order){FactoryBot.create(:order, subscription_id: subscription.id, amount: subscription.price, sub_total: subscription.price, account_id: current_user.id)}

	let(:payment_method_params) do
		{
			number: '4242424242424242',
			exp_month: 11,
			exp_year: 30,
			cvc: 678
		}
	end

	let(:payment_params) do
		{
			order_id: order.id,
			subscription_id: subscription.id
		}
	end

  let(:billing_params) do
    {
      name: 'Test Owner'
    }
  end

	let(:invalid_payment_params) do
		{
			order_id: order.id,
			subscription_id: '1234l'
		}
	end

  before do
    @token = BuilderJsonWebToken.encode current_user.id
    request.headers[:token] = @token
  end

  describe '#create' do
  	context 'when all the params are present' do
  		it 'must create the payment intent' do
  			post :create, params: {token: @token, payment: payment_params,
  				payment_method: payment_method_params, details: billing_params}
  			expect(response.status).to eq(200)
  			expect(JSON.parse(response.body)['stripe_payment_intent']['data']['attributes']['amount']).to eq(order.amount*100)
  		end
  	end

  	context 'when params are not present correctly' do
  		it 'must give error message for subscription id not found' do
  			post :create, params: {token: @token, payment: invalid_payment_params,
  				payment_method: payment_method_params, details: billing_params}
  			expect(response.status).to eq(404)
  			expect(JSON.parse(response.body)['errors']&.first['subscription']).to eq("Plan is no more Active.")
  		end

  	end

    context 'when payment method or card is already present' do
      before do
        stripe_customer1 = Stripe::Customer.create({email: current_user.email})
        result = BxBlockStripeIntegration::CreatePaymentMethod.new(payment_method_params.to_h, billing_params.to_h).call
        Stripe::PaymentMethod.attach(result[1].id, {customer: stripe_customer1.id})
        payment_params[:payment_method_id] = result[1].id
        current_user.update_column(:stripe_id, stripe_customer1.id)
      end
    end
  end

  describe '#offline_payment_request' do
  	context 'when all params are present' do
  		it 'must create order trx response' do
	  		post :offline_payment_request, params: {token: @token, order_management_order_id: order&.id, subscription_id: subscription&.id}
	  		expect(response.status).to eq(200)
	  		expect(JSON.parse(response.body)['success']).to eq("Your request has been created, iSail team will contact you soon.")
  		end
  	end

    context 'when order_management_order_id is present but the order is not found' do
      it 'returns an error response' do
        allow(BxBlockOrderManagement::Order).to receive(:find_by_id).with(999).and_return(nil)

        post :offline_payment_request, params: { order_management_order_id: 999 }

        expect(response).to have_http_status(:not_found)
        # Add more expectations here to verify the error response
      end
    end

  	context 'when order is not present' do
  		it 'must give error message' do
  			post :offline_payment_request, params: {token: @token,subscription_id: subscription&.id}
  			expect(response.status).to eq(404)
	  		expect(JSON.parse(response.body)['errors']&.first['order']).to eq("Subscription not Active anymore.")
  		end
  	end

    context 'when before action validation fails' do
      it 'must give error msg for subscription_id absent' do
        post :offline_payment_request, params: {token: @token, order_management_order_id: order&.id}
        expect(response.status).to eq(404)
        expect(JSON.parse(response.body)['errors']&.first['subscription']).to eq("Plan is no longer active.")
      end

      it 'must give error msg for already subscribed' do
        FactoryBot.create(:user_subscription, account_id: current_user.id,
          subscription_id: subscription&.id)
        post :offline_payment_request, params: {token: @token, order_management_order_id: order&.id, subscription_id: subscription&.id}
        expect(response.status).to eq(422)
        expect(JSON.parse(response.body)['error']).to eq('You have already subscribed to this plan.')
      end

      it 'gives error msg for order trx already present' do
        FactoryBot.create(:order_transaction, account_id: current_user.id,
        subscription_id: subscription.id, order_management_order_id: order.id)
        post :offline_payment_request, params: {token: @token, order_management_order_id: order&.id, subscription_id: subscription&.id}
        expect(response.status).to eq(422)
        expect(JSON.parse(response.body)['error']).to eq('You already have a request. Please wait till iSail team contacts.')
      end
    end
  end

  describe '#update_online_trx_status' do
    context 'when before action validation fails' do
      let!(:current_user2) { FactoryBot.create(:account) }
      let!(:order_trx) {FactoryBot.create(:order_transaction, account_id: current_user.id,
        subscription_id: subscription.id, order_management_order_id: order.id)}
      before do
        @token_2 = BuilderJsonWebToken.encode current_user2.id
        request.headers[:token] = @token_2
      end
      it 'must give error for invalid user updating the transaction' do
        patch :update_online_trx_status, params: {token: @token_2, order_id: order.id}
        expect(response.status).to eq(403)
      end
    end

    context 'when all the params are passed correctly' do
      let!(:order_trx2) {FactoryBot.create(:order_transaction, account_id: current_user.id,
        subscription_id: subscription.id, order_management_order_id: order.id)}
      it 'must update the transaction status to success' do
        patch :update_online_trx_status, params: {token: @token, status: 'succeeded', subscription_id: subscription.id, order_id: order.id, type: 'advertisement', payment_for: 'new_plan'}
        expect(response.status).to eq(200)
        exp_subscription_id = current_user.user_subscriptions.last.subscription_id
        expect(exp_subscription_id).to eq(subscription.id)
      end

      it 'must update the transaction status to failed' do
        patch :update_online_trx_status, params: {token: @token, status: 'Failed', subscription_id: subscription.id, order_id: order.id}
        expect(response.status).to eq(200)
        current_user.reload
        expect(current_user.activated).to eq(true)
      end
    end

    context 'when payment for updating the subscription is done' do
      let!(:subscription2){FactoryBot.create(:subscription)}
      let!(:order2){FactoryBot.create(:order, subscription_id: subscription2.id, amount: subscription2.price, sub_total: subscription2.price, account_id: current_user.id)}
      let!(:order_trx2) {FactoryBot.create(:order_transaction, account_id: current_user.id,
        subscription_id: subscription2.id, order_management_order_id: order2.id)}
      before do
        FactoryBot.create(:user_subscription, subscription_id: subscription.id, account_id: current_user.id)
      end
      it 'must update the user with new subscription' do
        patch :update_online_trx_status, params: {token: @token, status: 'succeeded', subscription_id: subscription2.id, order_id: order2.id, payment_for: 'updating_plan',
          type: 'advertisement'}
        expect(response.status).to eq(200)
        exp_subscription_id = current_user.user_subscriptions.last.subscription_id
        expect(exp_subscription_id).to eq(subscription2.id)
      end
    end
  end

end
