require 'rails_helper'
require 'spec_helper'

RSpec.describe BxBlockCategories::CategoriesController, type: :controller do
    let(:account) { FactoryBot.create(:account) }
    let(:admin_user) { FactoryBot.create(:admin_user) }
    let(:category) { FactoryBot.create(:category) }
    let(:sub_category) {FactoryBot.create(:sub_category, category_id: category.id)}

    # let(:valid_params) do
    #     {
    #         name: "Test dummy name",
    #         admin_user_id: admin_user.id,
    #         rank: 1,
    #         light_icon: category.light_icon,
    #         light_icon_active: category.light_icon_active,
    #         light_icon_inactive: category.light_icon_inactive,
    #         dark_icon: category.dark_icon,
    #         dark_icon_active: category.dark_icon_active,
    #         dark_icon_inactive: category.dark_icon_inactive,
    #         identifier: category.identifier
    #     }
    # end

    before do
        @token = BuilderJsonWebToken.encode account.id
        request.headers['token'] = @token
    end

    #path is not included in routes now.
    # describe "Create" do
    #     context "when invalid params are passed" do
    #         it "does not creates a category" do
    #             post :create, params: { categories: {name: ''} }
    #             expect(response).to raise_exception('Wrong Input data')
    #         end
    #     end

    #     context "when valid params are passed" do
    #         it "creates a category" do
    #             post :create, params: { categories: valid_params }
    #             expect(response).to have_http_status(201)
    #         end
    #     end
    # end

    describe "Index" do
        context "if subcategory is not passed" do
            it "shows a list of all categories" do
                get :index
                expect(response).to have_http_status(:ok)
                response_body = JSON.parse(response.body)
                expect(response_body).to include("data")
                expect(response_body["data"].map{|x| x["attributes"]["name"]}.uniq).to be_truthy
                expect(response_body["data"].map{|x| x["attributes"]["name"]}.count).to eq(BxBlockCategories::Category.count)
            end
        end

        context "if subcategory is passed" do
            it "shows a list of categories with specific sub_category" do
                get :index, params: {sub_category_id: sub_category.id}
                response_body = JSON.parse(response.body)
                expect(response_body).to include("data")
                expect(response_body["data"]["attributes"]["name"]).to eq(category.name)
                expect(response).to have_http_status(:ok)
            end
        end
    end

    describe "List Sub Categories" do
        it "shows subcategories of a particular category" do
            get :get_sub_categories, params: {category_id: sub_category.category_id}
            expect(response).to have_http_status(:ok)
            data = JSON.parse(response.body)["data"]
            expect(data).to be_a(Array)
            expect(data.map{ |x| x["attributes"]["name"] })
                .to eq(category.sub_categories.pluck(:name))
        end
    end
end