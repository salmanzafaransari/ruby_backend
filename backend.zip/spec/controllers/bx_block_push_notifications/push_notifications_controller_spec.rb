# frozen_string_literal: true

require 'rails_helper'
require 'spec_helper'

RSpec.describe BxBlockPushNotifications::PushNotificationsController, type: :controller do
  let!(:jobseeker) { FactoryBot.create(:account, account_role: "Jobseeker") }
  let!(:push_notification) { FactoryBot.create(:push_notification, push_notificable_id: jobseeker.id) }

  before do
    @token = BuilderJsonWebToken.encode jobseeker.id
    request.headers[:token] = @token
  end

  describe "GET index" do
    context "when current user is not present" do
      before do
        @token = nil
        request.headers[:token] = @token
      end

      it "returns invalid token error" do
        get :index
        expect(response).to have_http_status(400)
        expect(JSON.parse(response.body)["errors"].count).to be > 0
      end
    end

    context "when current user is present" do
      context "atleast one push notification is present" do
        it "it returns the list of push notifications" do
          get :index
          expect(response).to have_http_status(200)
          expect(JSON.parse(response.body)["data"].count).to be > 0
          expect(JSON.parse(response.body)["data"][0]["attributes"].keys)
            .to include("push_notificable", "notify_type", "remarks",
                        "is_read", "created_at", "updated_at")
        end
      end

      context "no push notifications are present" do
        before do
          push_notification.destroy
        end

        it "returns no notifications present message" do
          get :index
          expect(response).to have_http_status(404)
          expect(JSON.parse(response.body)["errors"]).to eq("There is no push notification.")
        end
      end
    end
  end

  describe "PATCH #read_notification" do
    context "when push notification is not present" do
      before do
        push_notification.destroy
      end

      it "returns not found error" do
        patch :read_notification, params: {push_notification_id: push_notification.id}
        expect(response).to have_http_status(404)
        expect(JSON.parse(response.body)["errors"]).to include("Record not found")
      end
    end

    context "when push notification is present" do
      context "and it is already read" do
        before do
          push_notification.update(is_read: true)
        end

        it "returns already read message" do
          patch :read_notification, params: {push_notification_id: push_notification.id}
          expect(response).to have_http_status(200)
          expect(JSON.parse(response.body)["message"]).to eq("Push Notification is already read.")
        end
      end

      context "and it is unread" do
        it "updates the push notification to read and returns the notification record" do
          patch :read_notification, params: {push_notification_id: push_notification.id}
          expect(response).to have_http_status(200)
          expect(JSON.parse(response.body)["data"]["attributes"]["is_read"]).to eq(true)
        end
      end
    end
  end
end
