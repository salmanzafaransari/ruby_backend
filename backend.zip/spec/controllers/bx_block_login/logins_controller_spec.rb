# frozen_string_literal: true

require 'rails_helper'
require 'spec_helper'

RSpec.describe BxBlockLogin::LoginsController, type: :controller do
  let(:email_account_var) {AccountBlock::EmailAccount}
	let!(:account1) {email_account_var.create(email: "demo@example.com", password: "Demo1234", account_role: "Jobseeker", activated: false)}
  let!(:account2) {email_account_var.create(email: "demo2@example.com", password: "Demo@1234", account_role: "Jobseeker", activated: true)}
  let(:account) {FactoryBot.create(:account)}
  before do
    @token = BuilderJsonWebToken.encode account.id
  end
	
  describe 'POST #create' do
    context 'with valid params' do
      let(:valid_params) do
        {
          data: {
            type: 'email_account',
            attributes: {
              account_role: 'Jobseeker',
              email: "admintest@gmail.com",
              password: "Admin1234"
            }
          }, token: @token
        }
      end
      let(:account1_params) do
        {
          data: {
            type: 'email_account',
            attributes: {
              account_role: 'Jobseeker',
              email: account1.email,
              password: "Demo1234"
            }
          }, token: @token
        }
      end
      let(:invalid_password) do
        {
          data: {
            type: 'email_account',
            attributes: {
              account_role: 'Jobseeker',
              email: account2.email,
              password: "admin1234"
            }
          }, token: @token
        }
      end

      it 'returns the token and account ID on successful login' do
				email_account = FactoryBot.create(:email_account)
        FactoryBot.create(:profile_bio, account_id: email_account.id)
				refresh_token = 'refresh_token'
        post :create, params: valid_params

        expect(response).to have_http_status(:ok)
        expect(JSON.parse(response.body)).to include("meta")
        expect(JSON.parse(response.body)["account"].keys).to include("first_name", "last_name", "email", "full_phone_number", "selfie_picture")
      end

      it 'renders an error message when account role is not specified' do
        invalid_params = valid_params.deep_dup
        invalid_params[:data][:attributes].delete(:account_role)

        post :create, params: invalid_params

        expect(response).to have_http_status(:unauthorized)
        expect(JSON.parse(response.body)).to include("errors")
      end

      it 'renders an error message when no account is registered with the specified email' do
				invalid_params = valid_params.deep_dup
				invalid_params[:data][:attributes][:email] = "email@example.com"

        post :create, params: invalid_params

        expect(response).to have_http_status(:unprocessable_entity)
				expect(JSON.parse(response.body)).to include("errors")
      end

      it 'renders an error message when the account is not activated' do
        post :create, params: account1_params

        expect(response).to have_http_status(:unprocessable_entity)
				expect(JSON.parse(response.body)).to include("errors")
      end

      it 'renders an error message when the password is incorrect' do
        post :create, params: invalid_password

        expect(response).to have_http_status(:unauthorized)
				expect(JSON.parse(response.body)).to include("errors")
      end
    end
  end
end
