require 'rails_helper'
require 'spec_helper'
RSpec.describe BxBlockOrderManagement::OrdersController, type: :controller do

	describe '#apply_promo_code' do
		let!(:user){FactoryBot.create(:account)}
		let!(:promo_code){FactoryBot.create(:coupon_code)}
		let!(:invalid_response){"Invalid Coupon Code"}

		before do
			@token = BuilderJsonWebToken.encode user.id
    		request.headers['token'] = @token
		end

		context 'valid promo code present' do
			it 'must give true status response' do
				get :apply_promo_code, params: {token: @token, code: promo_code.code  }
				expect(JSON.parse(response.body)['message']).to eq("Coupon Applied Successfully")
				expect(JSON.parse(response.body)['status']).to eq(true)
				expect(response.status).to eq(200)
			end

			it 'must give error for validity ended promo code' do
				promo_code.update_columns(valid_from: DateTime.now-7.months, valid_to: DateTime.now-2.months )
				get :apply_promo_code, params: {token: @token, code: promo_code.code  }
				expect(JSON.parse(response.body)['message']).to eq(invalid_response)
				expect(JSON.parse(response.body)['status']).to eq(false)
				expect(response.status).to eq(422)
			end
		end

		context 'invalid promo code present' do
			it 'must give error for invalid promo code' do
				get :apply_promo_code, params: {token: @token, code: 'XYZ123'  }
				expect(JSON.parse(response.body)['message']).to eq(invalid_response)
				expect(JSON.parse(response.body)['status']).to eq(false)
				expect(response.status).to eq(422)
			end

			it 'must give error for invalid promo code' do
				get :apply_promo_code, params: {token: @token }
				expect(JSON.parse(response.body)['message']).to eq(invalid_response)
				expect(JSON.parse(response.body)['status']).to eq(false)
				expect(response.status).to eq(422)
			end
		end
	end

	describe '#create' do
		let!(:user2){FactoryBot.create(:account)}
		let(:plan){FactoryBot.create(:subscription)}

		before do
			@token = BuilderJsonWebToken.encode user2.id
    		request.headers['token'] = @token
		end
		context 'when params present properly' do
			it 'must create an order' do
				post :create, params: {amount: plan.price, sub_total: plan.price, subscription_id: plan.id, token: @token}
				expect(response.status).to eq(200)
				expected_result = BxBlockOrderManagement::Order.last.sub_total
				expect(expected_result).to eq(plan.price)
			end
		end

		context 'when params not present properly' do
			it 'must give error when amount is not present' do
				post :create, params: {sub_total: plan.price, subscription_id: plan.id, token: @token}
				expect(response.status).to eq(422)
				expect(JSON.parse(response.body)['errors']).to eq({"amount"=>["can't be blank"]})
			end

			it 'must give error when subscription_id not present' do
				post :create, params: {amount: plan.price, sub_total: plan.price, token: @token}
				expect(response.status).to eq(422)
				expect(JSON.parse(response.body)['error']).to eq("Please select one Plan to continue.")
			end

			it 'must give error for already subscribed' do
				FactoryBot.create(:user_subscription, subscription_id: plan.id,
                            account_id: user2.id)
				post :create, params: {amount: plan.price, sub_total: plan.price, subscription_id: plan.id, token: @token}
				expect(JSON.parse(response.body)['error']).to eq("You have already subscribed to a Plan.")
				expect(response.status).to eq(422)
			end
		end
	end


end
