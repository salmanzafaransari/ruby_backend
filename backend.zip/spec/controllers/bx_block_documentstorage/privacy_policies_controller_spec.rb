require 'rails_helper'
require 'spec_helper'

RSpec.describe BxBlockDocumentstorage::PrivacyPoliciesController, type: :controller do

    let!(:privacy_policy) {FactoryBot.create(:privacy_policy)}

    describe '#show' do
        context 'it will open the show page of the terms and conditions' do
            it 'must show the data' do
                get :show_term_and_condition, params: {type: 'Terms and Conditions'}
                expect(response.status).to eq(200)
                expect(JSON.parse(response.body)["data"]["attributes"]["title"]).to eq("#{privacy_policy.title}")
            end

            it 'must give nil data for type not present' do
                get :show_term_and_condition
                expect(response.status).to eq(200)
                expect(JSON.parse(response.body)["data"]).to eq([])
            end
        end
    end

    describe '#show_static_files' do
        context 'when file name is passed' do
            let!(:file_path) { Rails.root.join('public', 'static', 'Privacy-policy.html') }
            it 'sends the static file' do
              expect(File.exist?(file_path)).to be(true)
              get :show_static_files, params: { filename: 'Privacy-policy.html' }
              expect(response.body).to eq(File.read(file_path))
              expect(response.header['Content-Type']).to eq('text/html')
            end

            it 'does not find file' do
               get :show_static_files, params: { filename: 'privacy-policy.html' } 
               expect(response.status).to eq(404)
            end
        end
    end
end