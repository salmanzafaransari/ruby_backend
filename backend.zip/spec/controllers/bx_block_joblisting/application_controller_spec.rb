# frozen_string_literal: true

require 'rails_helper'
require 'spec_helper'

RSpec.describe BxBlockJoblisting::ApplicationController, type: :controller do
  # describe 'before_action :validate_json_web_token' do
  #   controller do
  #     def index
  #       render json: { message: 'Index action' }
  #     end
  #   end

  #   context 'when a valid token is provided' do
	# 		let!(:account) do
	# 			account = FactoryBot.build(:account)
	# 			account.save(validate: false)
	# 			account
	# 		end
  #     let(:valid_token) { BuilderJsonWebToken.encode account.id }

  #     before do
  #       allow(controller).to receive(:validate_json_web_token).and_return(true)
  #       allow(controller).to receive(:request).and_return(double(protocol: 'http://', host_with_port: 'localhost:3000'))
  #     end

  #     it 'calls validate_json_web_token before the action' do
  #       expect(controller).to receive(:validate_json_web_token)

  #       get :index, params: { token: valid_token }

  #       expect(response).to have_http_status(:ok)
  #       expect(response.body).to include_json(message: 'Index action')
  #     end
  #   end
  # end

  describe 'rescue_from ActiveRecord::RecordNotFound' do
    controller do
      def show
        raise ActiveRecord::RecordNotFound
      end
    end

    it 'renders an error message with status :not_found' do
      get :show, params: { id: 123 }
			
      expect(response.status).to be(400)
      expect(response.body).to include("errors")
    end
  end

  describe '#serialization_options' do
    controller do
      def index
        render json: { message: 'Index action' }
      end
    end

    it 'returns the serialization options with the correct host' do
      request = double(protocol: 'http://', host_with_port: 'localhost:3000')
      allow(controller).to receive(:request).and_return(request)

      options = controller.send(:serialization_options)
      expect(options).to eq(params: {:action_name=>nil, :host=>"http://localhost:3000", :joblisting_id=>nil, :user=>nil})
    end
  end
end
