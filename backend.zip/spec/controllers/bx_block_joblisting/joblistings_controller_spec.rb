# frozen_string_literal: true

require 'rails_helper'
require 'spec_helper'

RSpec.describe BxBlockJoblisting::JoblistingsController, type: :controller do
	let!(:account) do
		account = FactoryBot.create(:account, account_role: 'Recruiter')
		account.save(validate: false)
		account
	end
  let!(:account2) do
		account = FactoryBot.create(:account)
		account.save(validate: true)
		account
	end
  let!(:signup_subscription){FactoryBot.create(:subscription, promotion_type: false, advertisement_type: false)}
  let(:category) {FactoryBot.create(:category)}
  let(:sub_category) {FactoryBot.create(:sub_category, category: category)}
  let(:title) {'Software Engineer'}
  let(:place) {'New York'}
  let(:start_date) {Date.today.strftime("%d/%m/%Y")}
	let(:valid_params) do
		{
			data: {
        attributes: {
          job_title: title,
          position_location: place,
          salary_range: '$80,000 - $100,000',
          duration_of_position: 'Full-time',
          months_on_board: 12,
          months_off_board: 2,
          open_position: 'Technology',
          vessel_type: 'N/A',
          location: 'Remote',
          currency: 'usd',
          starting_condition: start_date,
          job_description: 'Testing this Description',
          responsibilities: 'Tester1',
          required_certifications: ['Cert A', 'Cert B'],
          positions: ['Position A', 'Position B']
        }
      },
      joblisting_categories: {
        attributes: {
          category_ids: [category.id],
          sub_category_ids: [sub_category.id]
        }
      },
      token: @token
		}
	end

  let!(:account_jobseeker) do
    account = FactoryBot.create(:account)
    account.save(validate: false)
    account
  end

  let!(:account_recruiter) do
    account = FactoryBot.create(:account, email: 'recruiter@test.com', account_role: 'Recruiter')
    account.save(validate: false)
    account
  end

  let!(:account_recruiter2) do
    account = FactoryBot.create(:account, email: 'recruiter2@test.com', account_role: 'Recruiter')
    account.save(validate: false)
    account
  end

  let!(:jobseeker_profile){ FactoryBot.create(:profile_bio, account_id: account_jobseeker.id) }
  let!(:jobseeker_cv){ FactoryBot.create(:cv, account_id: account_jobseeker.id) }
  let!(:work_experience) { FactoryBot.create(:work_experience, cv_id: jobseeker_cv.id) }
  let!(:joblisting_test) { FactoryBot.create(:joblisting, account_id: account_recruiter.id) }
  let!(:joblisting_test2) { FactoryBot.create(:joblisting, account_id: account_recruiter.id) }
  let!(:joblisting_other) { FactoryBot.create(:joblisting) }
  let!(:user_joblisting){ FactoryBot.create(:user_joblisting, account_id: account_jobseeker.id,
        joblisting_id: joblisting_test.id, status: "applied", full_name: "#{account_jobseeker.first_name} #{account_jobseeker.last_name}",
        email: account_jobseeker.email, full_phone_number: account_jobseeker.full_phone_number)}
  let!(:promotion_plan) { FactoryBot.create(:subscription) }
  let!(:recruiter_subscription) { FactoryBot.create(:user_subscription,
        account_id: account_recruiter.id, subscription_id: promotion_plan.id) }
  let(:unauthorized_error) { "Only Recruiter Have Access To This Feature" }

	
	before do
    FactoryBot.create(:user_subscription, account_id: account.id, subscription_id: signup_subscription.id, expiry_date: Date.today + signup_subscription.valid_for.months)
		@token = BuilderJsonWebToken.encode account.id
    request.headers['token'] = @token
  end

  describe 'POST #create' do
    context 'with valid params' do
      around do |example|
        Sidekiq::Testing.inline! { example.run }
      end
      it 'creates a new joblisting and renders a successful response' do
        post :create, params: valid_params
        joblisting = BxBlockJoblisting::Joblisting.last
        serialization_options = { params: { user: account, action_name: "create" } }
        expect(joblisting.job_title).to eq(title)
        expect(joblisting.position_location).to eq(place)
        serialized_joblisting = BxBlockJoblisting::JoblistingSerializer.new(joblisting, serialization_options).serializable_hash
        expect(JSON.parse(response.body)).to include("data")
      end
    end

    context "with invalid joblisting categories" do
      it "does not create a joblisting" do
        category.destroy
        post :create, params: valid_params
        expect(response).to have_http_status(422)
        expect(JSON.parse(response.body)["errors"]).to eq("Atleast One Category is Required")
      end
    end

    context 'when recruiter has no signup advertisement' do
      before do
        account.user_subscriptions.destroy_all
      end
      it 'must not allow recruiter to create jobs' do
        post :create, params: valid_params
        expect(response).to have_http_status(422)
        expect(JSON.parse(response.body)["error"]).to eq("You don't have access to perform this action")
      end
    end

    context "with invalid params" do
      let(:invalid_params) do
        {
          data: {
            attributes: {
            position_location: place,
            salary_range: '$80,000 - $100,000',
            duration_of_position: 'Full-time',
            months_on_board: 12,
            months_off_board: 2,
            open_position: 'Technology',
            vessel_type: 'N/A',
            location: 'Remote',
            starting_condition: start_date,
            job_description: 'Testing this Description',
            responsibilities: 'Tester1',
            required_certifications: ['Cert A', 'Cert B'],
            positions: ['Position A', 'Position B']
          }
        },
        joblisting_categories: {
          attributes: {
            category_ids: [category.id],
            sub_category_ids: [sub_category.id]
          }
        },
        token: @token
      }
    end

      it "does not create a joblisting" do
        post :create, params: invalid_params
        expect(response).to have_http_status(422)
        expect(JSON.parse(response.body)["errors"]["job_title"][0]).to eq("can't be blank")
      end
    end
  end

  describe 'GET #index' do
    let(:joblisting1) {FactoryBot.create(:joblisting)}
    let!(:advertisement1) { FactoryBot.create(:advertisement, ads_count: 3, account_id: account_recruiter.id,
      joblisting_id: joblisting_test.id) }
    let!(:advertisement2) { FactoryBot.create(:advertisement, ads_count: 2, account_id: account_recruiter.id,
      joblisting_id: joblisting_test2.id)}
    before do
      FactoryBot.create(:user_subscription, account_id: account_jobseeker.id, subscription_id: signup_subscription.id)
      @token = BuilderJsonWebToken.encode account_jobseeker.id
      request.headers['token'] = @token
    end
    context 'index of joblisting' do
      it 'returns error' do
        BxBlockCategories::JoblistingCategory.destroy_all
        BxBlockJoblisting::Joblisting.destroy_all
        get :index, params: {token: @token}

        expect(response).to have_http_status(:ok)
        expect(JSON.parse(response.body)).to include("errors")
      end
    end

    context 'when params query is present' do
      it 'must list the joblisting on the basis of query and also show the advertisements based on the jobs viewed' do
        joblisting1.update_attribute(:job_title, "Testing Spec")
        get :index, params: {token: @token, query: "spec", page: 1, per: 10, jobs_viewed: 30}
        expect(response).to have_http_status(:ok)
        expect(JSON.parse(response.body)["joblistings"]["data"].count).to eq(1)
      end
    end

    context "when params query is not present" do
      it 'must list all the joblisting and show the advertisements based on the jobs viewed' do
        get :index, params: {token: @token, page: 1, per: 10, jobs_viewed: 30}
        expect(response).to have_http_status(:ok)
        expect(JSON.parse(response.body)["joblistings"]["data"].count).to be > 1
      end
    end

    context "when params sort_by is passed " do
      context "and is equal to starting_condition" do
        it "sorts the joblistings by starting_condition" do
          get :index, params: {token: @token, page: 1, per: 10, sort_by: "starting_condition"}
          expect(response).to have_http_status(:ok)
          consecutive_jobs_starting_condition = assigns(:joblistings)[-2..-1].map(&:starting_condition)
          sc_date1 = Date.parse(consecutive_jobs_starting_condition[0])
          sc_date2 = Date.parse(consecutive_jobs_starting_condition[1])
          expect( sc_date1 >= sc_date2).to be_truthy
        end
      end

      context "and is equal to created_at" do
        it "sorts the joblistings by created_at" do
          get :index, params: {token: @token, page: 1, per: 10, sort_by: "created_at"}
          expect(response).to have_http_status(:ok)
          consecutive_jobs_creation_date = assigns(:joblistings)[-2..-1].map(&:created_at)
          expect(consecutive_jobs_creation_date[0] >= consecutive_jobs_creation_date[1]).to be_truthy
        end
      end
    end
  end

  describe "GET show" do
    let(:joblisting) {FactoryBot.create(:joblisting)}
    it "shows the joblisting" do
      get :show, params: {id: joblisting.id}
      expect(response).to have_http_status(200)
      expect(JSON.parse(response.body)["data"]["attributes"]["job_title"]).to eq(joblisting.job_title)
      expect(JSON.parse(response.body)["data"]["attributes"]["job_description"]).to eq(joblisting.job_description)
    end
  end

  describe "GET job_application" do
    let(:joblisting) {FactoryBot.create(:joblisting)}
    context "when jobliting is found" do
      it "returns the contact info for job application" do
        get :job_application, params: { joblisting_id: joblisting.id }
        expect(response).to have_http_status(200)
        expect(JSON.parse(response.body).keys).to include("full_name", "email", "phone", "job_id", "video_cv")
      end
    end

    context "when joblisting is not found" do
      before do
        joblisting.destroy
      end

      it "returns not found error for joblisting" do
        get :job_application, params: { joblisting_id: joblisting.id }
        expect(response).to have_http_status(:not_found)
        expect(JSON.parse(response.body)["errors"]).to include("Record not found")
      end
    end
  end

  describe "POST apply" do
    let(:joblisting) {FactoryBot.create(:joblisting)}
    let(:valid_user_joblisting_params) do
      {
        joblisting_id: joblisting.id,
        data: {
          attributes: {
            full_name: account.full_name || "#{account&.first_name} #{account&.last_name}",
            email: account.email,
            full_phone_number: account.full_phone_number,
            resume: fixture_file_upload("files/My_Resume.pdf", "application/pdf"),
            video_cv: fixture_file_upload('files/test_video.mp4', 'video/mp4')
          }
        }
      }
    end
    before do
      FactoryBot.create(:user_subscription, account_id: account2.id, subscription_id: signup_subscription.id)
      @token = BuilderJsonWebToken.encode account2.id
      request.headers['token'] = @token 
    end
    context "when curent_user is a Jobseeker" do
      context "and user has already applied to this job" do
        before do
          FactoryBot.create(:user_joblisting, account_id: account2.id, joblisting_id: joblisting.id)
        end

        it 'will render "You have already applied to the job" error' do
          post :apply, params: valid_user_joblisting_params
          expect(response).to have_http_status(422)
          expect(JSON.parse(response.body)["error"]).to eq("You have already applied to this job listing.")
        end
      end

      context "and user has not applied to this job" do
        it "will apply to the Job successfully" do
          expect { post :apply, params: valid_user_joblisting_params }.to change {BxBlockJoblisting::UserJoblisting.count}.by(1)
          expect(response).to have_http_status(200)
          expect(JSON.parse(response.body)["success"]).to eq("Application submitted successfully.")
        end
      end

      context "when invalid params for job application are passed" do
        it "will raise an exception" do
          valid_user_joblisting_params[:data][:attributes][:full_name] = nil
          post :apply, params: valid_user_joblisting_params
          expect(response).to have_http_status(422)
          expect(JSON.parse(response.body)["errors"].count).to be > 0
        end
      end

      context 'when jobseeker don\'t have a signup subscription' do
        before do
          account2.user_subscriptions.destroy_all
        end
        it 'must not allow jobseeker to aply for any jobs' do
          post :apply, params: valid_user_joblisting_params
          expect(response).to have_http_status(422)
          expect(JSON.parse(response.body)["error"]).to eq("You don't have access to perform this action")
        end
      end
    end

    context "when current_user is not a Jobseeker" do
      let(:recruiter) { FactoryBot.create(:account, account_role: "Recruiter") }
      before do
        FactoryBot.create(:user_subscription, account_id: recruiter.id, subscription_id: signup_subscription.id)
        @token = BuilderJsonWebToken.encode recruiter.id
        request.headers['token'] = @token
      end

      it 'renders "Only Jobseekers can apply to the Job" error' do
        post :apply, params: valid_user_joblisting_params
        expect(response).to have_http_status(422)
        expect(JSON.parse(response.body)["error"]).to eq("Only Jobseeker users can apply to job listings.")
      end
    end

    context "when joblisting is not found" do
      before do
        joblisting.destroy
      end

      it "returns joblisting not found error" do
        post :apply, params: valid_user_joblisting_params
        expect(response).to have_http_status(:not_found)
        expect(JSON.parse(response.body)["errors"]).to include("Record not found")
      end
    end
  end

  describe "GET applied jobs" do
    context "when current user is not present" do
      before do
        allow(controller).to receive(:current_user).and_return(nil)
      end

      it "returns an error" do
        get :applied_joblistings
        expect(response).to have_http_status(422)
      end
    end

    context "when current user is present and he is a Jobseeker" do
      let(:joblisting) { FactoryBot.create(:joblisting) }
      before do
        FactoryBot.create(:user_subscription, account_id: account2.id, subscription_id: signup_subscription.id)
        @token = BuilderJsonWebToken.encode account2.id
        request.headers['token'] = @token
      end
      context "and has applied to atleast one job" do
        before do
          FactoryBot.create(:user_joblisting, account_id: account2.id, joblisting_id: joblisting.id)
        end
        it "returns a list of all the Jobs in which Jobseeker has applied" do
          get :applied_joblistings
          expect(response).to have_http_status(200)
          expect(JSON.parse(response.body)["data"].count).to eq(account2.user_joblistings.count)
        end
      end

      context "and has not applied to any jobs" do
        it 'returns "You have not applied to any jobs" message' do
          get :applied_joblistings
          expect(response).to have_http_status(200)
          expect(JSON.parse(response.body)["message"]).to eq("You have not applied to any jobs yet.")
        end
      end
    end

    context "when current user is not Jobseeker" do
      it 'renders "Only Jobseekers can perform this action" error' do
        account.update(account_role: "Recruiter")
        get :applied_joblistings
        expect(response).to have_http_status(422)
        expect(JSON.parse(response.body)["error"]).to eq("Only Jobseeker users can perform this action.")
      end
    end
  end

  describe 'PATCH #update' do
    let(:joblisting) { FactoryBot.create(:joblisting, account_id: account.id) }
    let(:joblisting2) { FactoryBot.create(:joblisting, account_id: account2.id) }
    context 'with valid params' do
      let(:valid_params) do
        {
          id: joblisting.id,
          data: {
            attributes: {
              job_title: 'Updated Job Title'
            }
          }, token: @token
        }
      end

      it 'updates the joblisting and renders a successful response' do
        put :update, params: valid_params
        serialization_options = { params: { user: account, action_name: "create" } }
        expect(response).to have_http_status(:ok)

        joblisting.reload
        expect(joblisting.job_title).to eq('Updated Job Title')
        # Ensure other attributes match your input

        serialized_joblisting = BxBlockJoblisting::JoblistingSerializer.new(joblisting, serialization_options).serializable_hash
        expect(JSON.parse(response.body)).to include("data")
      end
    end

    context 'with invalid params' do
      let(:invalid_params) do
        {
          id: joblisting2.id,
          data: {
            attributes: {
              job_title: 'Joblisting Title'
            }
          }, token: @token
        }
      end

      it 'must give error status 422' do
        put :update, params: invalid_params
        expect(response.status).to eq(422)
      end

    end
  end

  describe "DELETE destroy" do
    let(:joblisting) { FactoryBot.create(:joblisting) }
    context "when current user is not present" do
      before do
        allow(controller).to receive(:current_user).and_return(nil)
      end

      it "will raise an exception" do
        delete :destroy, params: {id: joblisting.id}
        expect(response).to have_http_status(422)
      end
    end

    context "when current user is not the owner of Joblisting or current user is not Admin/Super Admin" do
      it "will not delete the Joblisting due to unauthorized error" do
        delete :destroy, params: {id: joblisting.id}
        expect(response).to have_http_status(422)
        expect(JSON.parse(response.body)["message"]).to include("You are not authorized to perform this action.")
      end
    end

    context "when current user is owner of the Joblisting or it is Admin/Super Admin" do
      it "will destroy the joblisting successfully" do
        joblisting.update(account_id: account.id)
        delete :destroy, params: {id: joblisting.id}
        expect(response).to have_http_status(200)
        expect(JSON.parse(response.body)["message"]).to eq("Your Joblisting Deleted Successfully")
      end
    end
  end

  describe '#filter_joblisting' do
    let!(:joblisting1){ FactoryBot.create(:joblisting, vessel_type: 'Big Ship') }
    
    context 'must filter when params are passed correctly' do

      it 'must filter on the single params selection' do
        get :filter_joblisting, params: { token: @token, vessel_type: joblisting1.vessel_type }
        expect(response).to have_http_status(:ok)
        expect(JSON.parse(response.body)["joblistings"]["data"].count).to eq(1)
      end
      
      it 'must filter on the required_certifications params selection' do
        joblisting1.update_columns(positions: ["Abra", "Kaa", "Dabra"])
        get :filter_joblisting, params: { token: @token, positions: ['Dabra'] }
        expect(response).to have_http_status(:ok)
        expect(JSON.parse(response.body)["joblistings"]["data"].count).to eq(1)
      end

      it 'must filter with multiple params from filter is passed' do
        joblisting1.update_columns(positions: ["Abra", "Dabra"])
        get :filter_joblisting, params: { token: @token, vessel_type: joblisting1.vessel_type,positions: ['Dabra'] }
        expect(response).to have_http_status(:ok)
        expect(JSON.parse(response.body)["joblistings"]["data"].count).to eq(1)
      end

      it 'must return all the joblisting if no filter is selected' do
        get :filter_joblisting, params: { token: @token }
        expect(response).to have_http_status(:ok)
        expected = BxBlockJoblisting::Joblisting.all.blank? ? 0 : BxBlockJoblisting::Joblisting.all.size
        expect(JSON.parse(response.body)["joblistings"]["data"].count).to eq((expected < 10) ? expected : 10 )
      end

      it 'must return on the joblisting on the basis of salary range' do
        joblisting1.update_columns(salary_range: 900000)
        get :filter_joblisting, params: { token: @token , lower_salary_range: 700000, upper_salary_range: 1100000}
        job_count = BxBlockJoblisting::Joblisting.where(salary_range: 700000..1100000).count
        expect(response).to have_http_status(:ok)
        expect(JSON.parse(response.body)["joblistings"]["data"].count).to eq(job_count)
      end

      # it 'must filter on the basis of created at when less than 6 months is' do
      #   joblisting1.update_columns(created_at: DateTime.now - 2.months)
      #   date_range = 6.months.ago..DateTime.now
      #   expected_count = BxBlockJoblisting::Joblisting.where(created_at: date_range).count
      #   get :filter_joblisting, params: { token: @token , created_at: "less_than_6_months" }
      #   expect(response).to have_http_status(:ok)
      #   expect(JSON.parse(response.body)["joblistings"]["data"].count).to eq((expected_count < 10) ? expected_count : 10 )
      # end

      # it 'must filter on the basis of created at when more than 6 months is' do
      #   joblisting1.update_columns(created_at: DateTime.now - 9.months)
      #   date_range = 1.years.ago..DateTime.now
      #   expected_count = BxBlockJoblisting::Joblisting.where(created_at: date_range).count
      #   get :filter_joblisting, params: { token: @token , created_at: "more_than_6_months" }
      #   expect(response).to have_http_status(:ok)
      #   expect(JSON.parse(response.body)["joblistings"]["data"].count).to eq((expected_count < 10) ? expected_count : 10 )
      # end

      # it 'must filter on the basis of created at when more than 1 years is' do
      #   joblisting1.update_columns(created_at: DateTime.now - 15.months)
      #   date_range = 1.years.ago-6.months..DateTime.now
      #   expected_count = BxBlockJoblisting::Joblisting.where(created_at: date_range).count
      #   get :filter_joblisting, params: { token: @token , created_at: "more_than_1_year" }
      #   expect(response).to have_http_status(:ok)
      #   expect(JSON.parse(response.body)["joblistings"]["data"].count).to eq((expected_count < 10) ? expected_count : 10 )
      # end

      # it 'must filter all the past joblistings when cases do not match' do
      #   joblisting1.update_columns(created_at: DateTime.now - 23.months)
      #   date_range = 2.years.ago..DateTime.now
      #   expected_count = BxBlockJoblisting::Joblisting.where(created_at: date_range).count
      #   get :filter_joblisting, params: { token: @token , created_at: "all_from_past_years" }
      #   expect(response).to have_http_status(:ok)
      #   expect(JSON.parse(response.body)["joblistings"]["data"].count).to eq((expected_count < 10) ? expected_count : 10 )
      # end

      context 'when wrong params is passed' do
       it 'must filter on the basis of the passed params and give blank list' do
        get :filter_joblisting, params: { token: @token, vessel_type: '88x8y88'}
        expect(response).to have_http_status(:ok)
        expect(JSON.parse(response.body)["joblistings"]["data"].count).to eq(0)
       end
      end
    end 
  end

  describe '#Recruiter flow for candidate flow' do
    before do
      FactoryBot.create(:user_subscription, account_id: account_recruiter.id, subscription_id: signup_subscription.id)
  		@token = BuilderJsonWebToken.encode account_recruiter.id
      request.headers['token'] = @token
  	end

    context '#candidates_list' do
      it 'when candidate is valid and user_joblisting is present will give candidate list' do
        get :candidates_list, params: { token: @token, joblisting_id: joblisting_test.id }
        expect(response.status).to eq(200)
        expect(JSON.parse(response.body).count).to eq(1)
        expect(JSON.parse(response.body).first['id']).to eq(account_jobseeker.id)
      end

      it 'gives error message when no user joblisting is present' do
        user_joblisting.destroy!
        get :candidates_list, params: { token: @token, joblisting_id: joblisting_test.id }
        expect(response.status).to eq(200)
        expect(JSON.parse(response.body)['error']).to eq('No Jobseeker applied for this joblisting yet.')
      end

      it 'gives error when joblisting does not belong to recruiter' do
        joblisting_test.update(account_id: account.id)
        get :candidates_list, params: { token: @token, joblisting_id: joblisting_test.id }
        expect(response.status).to eq(422)
      end
    end

    context '#show_cv' do
      it 'shows the cv data of the candidate' do
        get :show_cv, params: { token: @token, joblisting_id: joblisting_test.id, candidate_id: account_jobseeker.id }
        expect(JSON.parse(response.body)['data']['attributes']['bio']).to eq('Test bio')
      end
    end

    context '#application_status_change' do
      let!(:invalid_status_params) do
        {
          user_id: account_jobseeker.id,
          joblisting_id: joblisting_test.id,
          data: {
              status: 'something'
          }, token: @token
        }
      end
  
      let!(:approved_status_params) do
        {
          user_id: account_jobseeker.id,
          joblisting_id: joblisting_test.id,
          data: {
              status: 'approved'
          }, token: @token
        }
      end

      let!(:rejected_status_params) do
        {
          user_id: account_jobseeker.id,
          joblisting_id: joblisting_test.id,
          data: {
              status: 'rejected'
          }, token: @token
        }
      end

      let!(:missing_params) do
        {
          user_id: '',
          joblisting_id: joblisting_test.id,
          data: {
              status: 'rejected'
          }, token: @token
        }
      end

      it 'will update the status of joblisting to in progress when no status passed' do
        patch :application_status_change, params: invalid_status_params
        expect(response.status).to eq(200)
        expect(JSON.parse(response.body)['data']['attributes']['status']).to eq('in_progress')
      end

      it 'must give error when candidate already got shortlisted' do
        user_joblisting.update(status: 'shortlisted')
        patch :application_status_change, params: approved_status_params
        expect(response.status).to eq(200)
        expect(JSON.parse(response.body)['error']).to eq("You have already approved the Candidate")
      end

      it 'must give error when candidate is rejected already' do
        user_joblisting.update(status: 'rejected')
        patch :application_status_change, params: rejected_status_params
        expect(response.status).to eq(200)
        expect(JSON.parse(response.body)['error']).to eq("Already updated with status rejected")
      end

      it 'must update the status with shortlisted when approved is passed in params' do
        patch :application_status_change, params: approved_status_params
        expect(response.status).to eq(200)
        expect(JSON.parse(response.body)['data']['attributes']['status']).to eq('shortlisted')
      end

      it 'must update the status with rejected when rejected is passed in params' do
        patch :application_status_change, params: rejected_status_params
        expect(response.status).to eq(200)
        expect(JSON.parse(response.body)['data']['attributes']['status']).to eq('rejected')
      end

      it 'must give error when parameter missing' do
        patch :application_status_change, params: missing_params
        expect(response.status).to eq(422)
        expect(JSON.parse(response.body)['error']).to eq("parameter missing")
      end
  
      context 'when jobseeker logs in' do
        before do
          FactoryBot.create(:user_subscription, account_id: account_jobseeker.id, subscription_id: signup_subscription.id)
          @token = BuilderJsonWebToken.encode account_jobseeker.id
          request.headers['token'] = @token
        end
        it 'must give error' do
          patch :application_status_change, params: approved_status_params
          expect(response.status).to eq(422) 
          expect(JSON.parse(response.body)['error']).to eq(unauthorized_error)
        end
      end
    end
  end

  describe '#Recruiter joblisting' do    
    it 'when recruiter get our joblisting with paramns query present' do
      FactoryBot.create(:user_subscription, account_id: account_recruiter.id, subscription_id: signup_subscription.id)
      @token = BuilderJsonWebToken.encode account_recruiter.id
      request.headers['token'] = @token

      get :recruiter_joblisting, params: { token: @token, query: title }

      data = JSON.parse(response.body)
      expect(response.status).to eq(200)
      expect(data['data'].count).to eq(2)
      expect(data['data'].map { |j| j['id'].to_i }).to eq([joblisting_test.id, joblisting_test2.id])
    end

    it 'when recruter has not joblisting' do
      FactoryBot.create(:user_subscription, account_id: account_recruiter2.id, subscription_id: signup_subscription.id)
      @token = BuilderJsonWebToken.encode account_recruiter2.id
      request.headers['token'] = @token

      get :recruiter_joblisting, params: { token: @token }

      data = JSON.parse(response.body)

      expect(response.status).to eq(200)
      expect(data['data'].count).to eq(0)
    end

    it 'when current_user jobseeker' do
      FactoryBot.create(:user_subscription, account_id: account_jobseeker.id, subscription_id: signup_subscription.id)
      @token = BuilderJsonWebToken.encode account_jobseeker.id
      request.headers['token'] = @token

      get :recruiter_joblisting, params: { token: @token }

      data = JSON.parse(response.body)
      expect(response.status).to eq(422)
      expect(data['error']).to eq(unauthorized_error)
    end

    it 'not login account' do
      request.headers['token'] = ''

      get :recruiter_joblisting, params: { token: '' }

      data = JSON.parse(response.body)
      expect(response.status).to eq(400)
      expect(data['errors'].last['token']).to eq('Invalid token')
    end
  end

  describe "#GET download_video_cv" do
    context "when current user is recruiter" do
      before do
        @token = BuilderJsonWebToken.encode account_recruiter.id
        request.headers['token'] = @token
        FactoryBot.create(:user_subscription, account_id: account_recruiter.id, subscription_id: signup_subscription.id)
      end
      context "when candidate and joblisting both are present" do
        context "when video Cv is uploaded by the candidate while applying for the job" do
          it "returns the video cv" do
            get :download_video_cv, params: {joblisting_id: joblisting_test.id, candidate_id: account_jobseeker.id}
            expect(response).to have_http_status(200)
            expect(JSON.parse(response.body)["video_cv"]).to eq(user_joblisting.video_cv.url)
          end
        end

        context "when video cv is not uploaded by the candidate while apply for the job" do
          before do
            user_joblisting.update(video_cv: nil)
          end
          it "returns video cv not present error" do
            get :download_video_cv, params: {joblisting_id: joblisting_test.id, candidate_id: account_jobseeker.id}
            expect(response).to have_http_status(422)
            expect(JSON.parse(response.body)["error"]).to eq("Video CV not uploaded.")
          end
        end
      end

      context "when candidate or joblisting any of them is not present" do
        before do
          joblisting_test.destroy
        end
        it "returns not found error for joblisting or candidate" do
          get :download_video_cv, params: {joblisting_id: joblisting_test.id, candidate_id: account_jobseeker.id}
          expect(response).to have_http_status(404)
          expect(JSON.parse(response.body)["error"]).to eq("Candidate or job application not found.")
        end
      end
    end

    context "when current user is jobseeker" do
      it "gives unauthorized error" do
        FactoryBot.create(:user_subscription, account_id: account_jobseeker.id, subscription_id: signup_subscription.id)
        @token = BuilderJsonWebToken.encode account_jobseeker.id
        request.headers['token'] = @token
        get :download_video_cv, params: {joblisting_id: joblisting_test.id, candidate_id: account_jobseeker.id}

        expect(response).to have_http_status(422)
        expect(JSON.parse(response.body)['error']).to eq(unauthorized_error)
      end
    end
  end

  describe "PATCH #promote_joblisting" do
    context "when current user is not recruiter" do
      before do
        @token = BuilderJsonWebToken.encode account2.id
        request.headers['token'] = @token
      end

      it "returns authorization error" do
        patch :promote_joblisting, params: {joblisting_id: joblisting_test.id}
        expect(response).to have_http_status(422)
        expect(JSON.parse(response.body)["error"]).to eq(unauthorized_error)
      end
    end

    context "when current user is recruiter" do
      before do
        @token = BuilderJsonWebToken.encode account_recruiter.id
        request.headers['token'] = @token
      end
      around do |example|
        Sidekiq::Testing.inline! { example.run }
      end

      context "when joblisting is present and recruiter has subscribed to promotion plan" do
        context "and maximum jobs promotion limit is not reached" do
          it "promotes the joblisting successfully" do
            patch :promote_joblisting, params: {joblisting_id: joblisting_test.id}
            expect(response).to have_http_status(200)
            expect(JSON.parse(response.body)["data"]["attributes"]["promoted"]).to eq(true)
          end
        end

        context "and maximum jobs promotion limit is reached" do
          it "does not promote the job and returns error" do
            allow(BxBlockJoblisting::Joblisting).to receive(:where).with(account_id: account_recruiter.id, promoted: true).and_return(double(count: 5))
            patch :promote_joblisting, params: {joblisting_id: joblisting_test.id}
            expect(response).to have_http_status(200)
            expect(JSON.parse(response.body)["error"]).to eq("You have promoted maximum jobs as per your plan")
          end
        end
      end

      context "when joblisting is present and recruiter has no promotion plans subcribed" do
        before do
          recruiter_subscription.destroy
        end

        it "returns no promotion plan subscribed error" do
          patch :promote_joblisting, params: {joblisting_id: joblisting_test.id}
          expect(response).to have_http_status(422)
          expect(JSON.parse(response.body)["error"]).to eq("You don't have any job promotion subscription plan.")
        end
      end
    end
  end
end
