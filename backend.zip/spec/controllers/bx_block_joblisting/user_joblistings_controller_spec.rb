# frozen_string_literal: true

require 'rails_helper'
require 'spec_helper'

RSpec.describe BxBlockJoblisting::UserJoblistingsController, type: :controller do
    # let!(:recruiter_account) do
	# 	account = FactoryBot.create(:account, account_role: 'Recruiter')
	# 	account.save(validate: false)
	# 	account
	# end
    # let!(:jobseeker_account) do
	# 	account = FactoryBot.create(:account)
	# 	account.save(validate: false)
	# 	account
	# end
    # let(:joblisting) {FactoryBot.create(:joblisting, account_id: recruiter_account.id)}
    # let(:user_joblisting) {FactoryBot.create(:user_joblisting, account_id: jobseeker_account.id, joblisting_id: joblisting.id)}
    # let(:expecting_response) {JSON.parse(response.body)['data']['attributes']['status']}
    # before do
    #     @token = BuilderJsonWebToken.encode recruiter_account.id
    #     request.headers['token'] = @token
	# end

    # describe '#show' do
    #     context 'when correct id is present' do
    #         it 'will show the user made application for the job' do
    #             get :show , params: {id: user_joblisting.id}
    #             expect(response.status).to eq(200)
    #             expect(expecting_response).to eq('viewed')
    #         end

    #         it 'will give error if jobseeker tries to change the status' do
    #             @token2 = BuilderJsonWebToken.encode jobseeker_account.id
    #             request.headers['token'] = @token2
    #             get :show , params: {id: user_joblisting.id}
    #             expect(response.status).to eq(422)
    #         end
    #     end

    #     context 'when wrong id is passed' do
    #         it 'will give error for account not found' do
    #             get :show , params: {id: 'xyz'}
    #             expect(response.status).to eq(422)
    #             expect(JSON.parse(response.body)['errors']).to eq("No Application found")
    #         end
    #     end
    # end

    # describe '#application_status_change' do
    #     context 'when status params is passed' do
    #         it 'will update the status to rejected if stus param passed as Rejected' do
    #             put :application_status_change, params: {user_joblisting_id: user_joblisting.id,
    #                     status: 'rejected'}
    #             expect(expecting_response).to eq('rejected')          
    #         end

    #         it 'will update the status to approved if status param passed as Approve' do
    #             put :application_status_change, params: {user_joblisting_id: user_joblisting.id,
    #             status: 'approved'}
    #             expect(expecting_response).to eq('shortlisted')   
    #         end

    #         it 'will update the status In Progress if the status params doen\'t match any case' do
    #             put :application_status_change, params: {user_joblisting_id: user_joblisting.id,
    #             status: 'In Review'}
    #             expect(expecting_response).to eq('in_progress') 
    #         end
    #     end

    #     context 'when new status params matches the status' do
    #         it 'will give message of already updated error' do
    #             user_joblisting.update(status: 'rejected')
    #             status_now = user_joblisting.status
    #             put :application_status_change, params: {user_joblisting_id: user_joblisting.id,
    #             status: 'rejected'}
    #             expect(JSON.parse(response.body)['error']).to eq("Already uptodated with status #{status_now}")
    #         end
    #     end

    #     context 'when any one of the params is missing' do
    #         it 'will give error for missing parameter' do
    #             put :application_status_change, params: {user_joblisting_id: user_joblisting.id,
    #                 status: nil}
    #             expect(response.status).to eq(422)
    #             expect(JSON.parse(response.body)['error']).to eq("parameter missing") 
    #         end
    #     end
    # end
end