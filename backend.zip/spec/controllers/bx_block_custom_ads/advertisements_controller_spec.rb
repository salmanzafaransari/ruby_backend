# frozen_string_literal: true

require 'rails_helper'
require 'spec_helper'

RSpec.describe BxBlockCustomAds::AdvertisementsController, type: :controller do
  CURRENT_USER_NOT_PRESENT = "current user not present"
  CURRENT_USER_JOBSEEKER = "when current user is a Jobseeker"
  CURRENT_USER_RECRUITER = "when current user is a Recruiter"
  let!(:jobseeker) { FactoryBot.create(:account) }
  let!(:recruiter) { FactoryBot.create(:account, account_role: "Recruiter") }
  let(:joblistings) { FactoryBot.create_list(:joblisting, 3, account_id: recruiter.id) }
  let!(:ads_subscription){FactoryBot.create(:subscription, promotion_type: false, advertisement_type: true)}
  let!(:signup_subscription){FactoryBot.create(:subscription, promotion_type: false, advertisement_type: false)}
  let(:advertisement1) { FactoryBot.create(:advertisement, account: recruiter, joblisting_id: joblistings[0].id) }
  let(:advertisement2) { FactoryBot.create(:advertisement, account: recruiter, joblisting_id: joblistings[1].id) }
  let(:authorization_error) { "You are not authorized to perform this action." }
  # let!(:plan_1) {FactoryBot.create(:subscription)}
  let!(:plan_2) {FactoryBot.create(:subscription, name: 'Plan B')}
  let!(:count) {BxBlockCustomUserSubs::Subscription.all.count}
  RSpec.shared_context CURRENT_USER_NOT_PRESENT do
    before do
      @token = nil
      request.headers[:token] = @token
    end
  end

  RSpec.shared_context CURRENT_USER_JOBSEEKER do
    before do
      FactoryBot.create(:user_subscription, account_id: jobseeker.id, subscription_id: signup_subscription.id)
      @token = BuilderJsonWebToken.encode jobseeker.id
      request.headers[:token] = @token
    end
  end
  
  RSpec.shared_context CURRENT_USER_RECRUITER do
    before do
      FactoryBot.create(:user_subscription, account_id: recruiter.id, subscription_id: ads_subscription.id)
      @token = BuilderJsonWebToken.encode recruiter.id
      request.headers[:token] = @token
    end
  end

  describe "GET #index" do
    context CURRENT_USER_NOT_PRESENT do
      include_context CURRENT_USER_NOT_PRESENT
      it "returns invalid token error" do
        get :index
        expect(response).to have_http_status(400)
        expect(JSON.parse(response.body)["errors"][0]["token"]).to eq("Invalid token")
      end
    end

    context CURRENT_USER_JOBSEEKER do
      include_context CURRENT_USER_JOBSEEKER
      it "gives all the advertisements" do
        get :index
        expect(response).to have_http_status(200)
      end
    end

    context CURRENT_USER_RECRUITER do
      include_context CURRENT_USER_RECRUITER
      
      context "when no advertisements are created by the recruiter" do
        before do
          BxBlockCustomAds::Advertisement.where(account_id: recruiter.id).destroy_all
        end

        it "returns a message if no advertisements are present" do
          get :index
          expect(response).to have_http_status(200)
          expect(JSON.parse(response.body)["message"]).to eq("No advertisements present.")
        end
      end

      context "when atleast one advertisement is created by the recruiter" do
        it "returns a list of advertisements created by current user" do
          advertisement1
          get :index
          expect(response).to have_http_status(200)
          expect(JSON.parse(response.body)["data"]).to_not be_empty
        end
      end
    end
  end

  describe "POST #create" do
    let(:valid_params) do
      {
        advertisement: {
          banner: fixture_file_upload("files/test.png", "image/png"),
          account_id: recruiter.id,
          joblisting_id: joblistings[2].id,
          ads_count: 5,
          jobs_count: 100
        }
      }
    end
    let(:invalid_params) do
      {
        advertisement: {
          banner: fixture_file_upload("files/test.png", "image/png"),
          account_id: recruiter.id,
          joblisting_id: nil,
          ads_count: 5,
          jobs_count: 100
        }
      }
    end

    context CURRENT_USER_NOT_PRESENT do
      include_context CURRENT_USER_NOT_PRESENT
      it "returns invalid token error" do
        post :create
        expect(response).to have_http_status(400)
        expect(JSON.parse(response.body)["errors"][0]["token"]).to eq("Invalid token")
      end
    end

    context CURRENT_USER_JOBSEEKER do
      include_context CURRENT_USER_JOBSEEKER
      it "returns authorization error" do
        post :create
        expect(response).to have_http_status(422)
        expect(JSON.parse(response.body)["error"]).to eq(authorization_error)
      end
    end

    context CURRENT_USER_RECRUITER do
      include_context CURRENT_USER_RECRUITER
      
      context "when valid params are passed" do
        it "creates an advertisement successfully" do
          post :create, params: valid_params
          expect(response).to have_http_status(201)
          expect(JSON.parse(response.body)["data"]["attributes"]['joblisting']['id']).to eq(joblistings[2].id)
        end
      end

       context 'when advertisement plan present but expired' do
        before do
          user_sub = BxBlockCustomUserSubs::UserSubscription.find_by(subscription_id: ads_subscription.id, account_id: recruiter.id)
          user_sub.expiry_date = Date.today - 10.days
          user_sub.save!
        end
        it 'must give error message not not allow perform more action' do
          post :create, params: valid_params
          expect(response.status).to eq(422)
          expect(JSON.parse(response.body)['error']).to eq('Your Advertisement Plan has expired.')
        end
      end

      context 'when no subscription present' do
        before do
          BxBlockCustomUserSubs::UserSubscription.destroy_all
        end
        it 'must give error for no access' do
          post :create, params: valid_params
          expect(response.status).to eq(422)
          expect(JSON.parse(response.body)['error']).to eq('You don\'t have access to create Ads')
        end
      end

      context 'when limit of advertisement creating has reached' do
        before do
          5.times do
            FactoryBot.create(:advertisement, account: recruiter, joblisting_id: joblistings[0].id)
          end
        end
        it 'must give error message not not allow to create ads' do
          post :create, params: valid_params
          expect(response.status).to eq(422)
          expect(JSON.parse(response.body)['error']).to eq('You have reached your maximum limit of Ads.')
        end
      end

      context 'when ad is already created for a job' do
        before do
          FactoryBot.create(:advertisement, account: recruiter, joblisting_id: joblistings[2].id)
        end
        it 'must give error' do
          post :create, params: valid_params
          expect(response.status).to eq(422)
          expect(JSON.parse(response.body)['error']).to eq('You already have a Advertisement for this Job')
        end
      end

      context "when invalid params are passed" do
        it "does not create advertisement" do
          post :create, params: invalid_params
          expect(response).to have_http_status(422)
          expect(JSON.parse(response.body)["errors"].count).to be > 0
        end
      end
    end
  end

  describe "GET #show" do
    # context CURRENT_USER_JOBSEEKER do
    #   include_context CURRENT_USER_JOBSEEKER
    #   it "returns unauthorized error" do
    #     get :show, params: {id: advertisement1.id}
    #     expect(response).to have_http_status(422)
    #     expect(JSON.parse(response.body)["error"]).to eq(authorization_error)
    #   end
    # end

    context CURRENT_USER_RECRUITER do
      include_context CURRENT_USER_RECRUITER
      it "returns the advertisement record successfully" do
        get :show, params: {id: advertisement1.id}
        expect(response).to have_http_status(200)
      end
    end
  end

  describe "POST #set advertisement frequency" do
    context CURRENT_USER_RECRUITER do
      include_context CURRENT_USER_RECRUITER
      context "when atleast one advertisement is present" do
        it "sets the ads frequency for all the recruiter advertisements successfully" do
          advertisement1
          advertisement2
          post :set_advertisements_frequency, params: {ads_count: 5 , jobs_count: 100}
          expect(response).to have_http_status(200)
          expect(JSON.parse(response.body)["data"][0]["attributes"]["ads_count"]).to eq(5)
        end
      end

      context "when no advertisement is present" do
        it "does not set the ads frequency and gives error message" do
          post :set_advertisements_frequency, params: {ads_count: 5 , jobs_count: 100}
          expect(response).to have_http_status(422)
          expect(JSON.parse(response.body)["error"]).to eq("You don't have any advertisements yet. Please create atleast one advertisement.")
        end
      end
    end
  end

  describe '#get_viewed_and_clicked_count' do
    context 'when current user has advertisements created' do
      include_context CURRENT_USER_RECRUITER
      let!(:month){(Date.today).strftime("%B")}
      let!(:year){(Date.today).strftime("%Y")}
      before do
        advertisement1.clicked_count_verify
        advertisement1.viewed_count_verify
      end
      it 'must give the clicked and viewed count when params of year is passed' do
        get :get_viewed_and_clicked_count, params: {year: year}
        expect(JSON.parse(response.body)["monthly_clicked_count"]).to eq(advertisement1.month_wise_clicked_counts[year])
        expect(JSON.parse(response.body)["monthly_viewed_count"]).to eq(advertisement1.month_wise_viewed_counts[year])
      end

      it 'must give the clicked and viewed count of current year when params not passed' do
        get :get_viewed_and_clicked_count
        expect(JSON.parse(response.body)["monthly_clicked_count"]).to eq(advertisement1.month_wise_clicked_counts[year])
        expect(JSON.parse(response.body)["monthly_viewed_count"]).to eq(advertisement1.month_wise_viewed_counts[year])
      end
    end

    context 'when current user has no advertisement' do
      include_context CURRENT_USER_RECRUITER
      it 'will give error message as response' do
        advertisement1.destroy
        advertisement2.destroy
        get :get_viewed_and_clicked_count, format: :json
        expect(JSON.parse(response.body)["error"]).to eq("No Advertisement found")
      end
    end
  end
end
