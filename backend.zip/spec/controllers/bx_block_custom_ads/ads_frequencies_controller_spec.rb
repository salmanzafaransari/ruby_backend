# frozen_string_literal: true

require 'rails_helper'
# require 'spec_helper'

RSpec.describe BxBlockCustomAds::AdsFrequenciesController, type: :controller do
  let(:jobseeker) { FactoryBot.create(:account) }
  let(:recruiter) { FactoryBot.create(:account, account_role: "Recruiter") }
  let(:ads_frequency1) { FactoryBot.create(:ads_frequency, name: "1 per 100", rank: 1) }
  let(:ads_frequency2) { FactoryBot.create(:ads_frequency, name: "2 per 100", rank: 2) }
  let(:ads_frequency3) { FactoryBot.create(:ads_frequency, name: "3 per 100", rank: 3) }

  before do
    @token = BuilderJsonWebToken.encode recruiter.id
    request.headers['token'] = @token
  end

  describe "GET #index" do
    context "when current user is recruiter" do
      context "when ads frequencies are present" do
        it "returns a list of ads frequences" do
          ads_frequency1
          ads_frequency2
          ads_frequency3
          get :index
          expect(response).to have_http_status(200)
          expect(JSON.parse(response.body)["data"].count).to be > 0
        end
      end

      context "when ads frequencies are not present" do
        before do
          BxBlockCustomUserSubs::Subscription.destroy_all
          BxBlockCustomAds::AdsFrequency.destroy_all
        end

        it "returns a message for no ads frequencies present" do
          get :index
          expect(response).to have_http_status(200)
          expect(JSON.parse(response.body)["message"]).to eq("No Ads Frequencies present.")
        end
      end
    end

    context "when current user is jobseeker" do
      before do
        @token = BuilderJsonWebToken.encode jobseeker.id
        request.headers['token'] = @token
      end

      it "retruns unauthorized error" do
        get :index
        expect(response).to have_http_status(422)
        expect(JSON.parse(response.body)["error"]).to eq("You are not authorized to perform this action.")
      end
    end
  end
end
