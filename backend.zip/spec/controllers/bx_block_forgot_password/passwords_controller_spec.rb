# frozen_string_literal: true

require 'rails_helper'
require 'spec_helper'

RSpec.describe BxBlockForgotPassword::PasswordsController, type: :controller do
	let(:account_email_otp) {'AccountBlock::EmailOtp'}
	let!(:account) {FactoryBot.create(:account)}
	let(:otp_record) {AccountBlock::EmailOtp.create(email: account.email, activated: true)}
	let(:token) { BuilderJsonWebToken.encode account.id }
	let(:valid_token) { BuilderJsonWebToken.encode( otp_record.id, 5.minutes.from_now, type: otp_record.class, account_id: account.id ) }
	let(:valid_new_password) { 'Validpassword123' }
	let(:valid_params) do
		{
			data: {
				token: valid_token,
				new_password: valid_new_password,
				new_password_confirmation: valid_new_password,
				otp_code: otp_record.pin
			}
		}
	end

	let(:invalid_params) do
		{
			data: {
				token: valid_token,
				new_password: valid_new_password,
				new_password_confirmation: 'Admin9765',
				otp_code: otp_record.pin
			}
		}
	end

	let(:change_pass_params) do
		{
			token: token,
			new_password: valid_new_password,
			new_password_confirmation: valid_new_password,
			current_password: account.password
		}
	end
	let(:unchange_pass_params) do
		{
			token: token,
			new_password: valid_new_password,
			new_password_confirmation: "TestPass123",
			current_password: account.password
		}
	end

	let(:invalid_current_pass_params) do
		{
			token: token,
			new_password: valid_new_password,
			new_password_confirmation: valid_new_password,
			current_password: "Adm122#"
		}
	end
	describe 'POST #create' do
		it 'renders an error response if token is missing' do
			params = valid_params.deep_dup
			params[:data].delete(:token)

			post :create, params: params

			expect(response).to have_http_status(:unprocessable_entity)
			expect(response.body).to include("errors")
		end

		it 'renders an error response if new password is missing' do
			params = valid_params.deep_dup
			params[:data].delete(:new_password)

			post :create, params: params

			expect(response).to have_http_status(:unprocessable_entity)
			expect(response.body).to include("errors")
		end

		it 'renders an error response if token is invalid' do
			allow(BuilderJsonWebToken).to receive(:decode).and_raise(JWT::DecodeError)

			post :create, params: valid_params

			expect(response).to have_http_status(:bad_request)
			expect(response.body).to include("errors")
		end

		it 'renders an error response if OTP record is not found' do
			allow(BuilderJsonWebToken).to receive(:decode).and_return(double(type: account_email_otp, id: 1))
			allow(account_email_otp.constantize).to receive(:find).and_raise(ActiveRecord::RecordNotFound)

			post :create, params: valid_params

			expect(response).to have_http_status(:unprocessable_entity)
			expect(response.body).to include("errors")
		end

		it 'renders an error response if OTP is not activated' do
			allow(BuilderJsonWebToken).to receive(:decode).and_return(double(type: account_email_otp, id: 1))
			allow(account_email_otp.constantize).to receive(:find).and_return(double(activated?: false))

			post :create, params: valid_params

			expect(response).to have_http_status(:unprocessable_entity)
			expect(response.body).to include("errors")
		end

		it 'renders an error response if new password confirmation is not matching' do
			post :create, params: invalid_params
			expect(response).to have_http_status(:unprocessable_entity)
			expect(response.body).to include("errors")
			expect(JSON.parse(response.body)["errors"]&.first['otp']).to eq("New Confirmation Password doesn't match the New Password")
		end

		it 'renders an error response if invalid password is given' do
			post :create, params: {data: {token: valid_token, new_password: '123456@9',
				new_password_confirmation: '123456@9', otp_code: otp_record.pin}}
			expect(response).to have_http_status(:unprocessable_entity)
			expect(response.body).to include("errors")	
		end

		it 'renders a successful response and updates the account password' do
			post :create, params: valid_params

			expect(response).to have_http_status(:created)
			expect(JSON.parse(response.body)).to include("data")
		end			
	end
	
	describe 'PUT #change_password' do
		context 'with valid params' do
			it 'changes account password' do
			  put :change_password, params: change_pass_params
	  
			  expect(response).to have_http_status(:created)
			  expect(JSON.parse(response.body)).to include("data")
			end
		end

		it 'renders an error if new password is missing' do
			params = change_pass_params.deep_dup
			params.delete(:new_password)
			put :change_password, params: params
			expect(response.body).to include("errors")
			expect(response).to have_http_status(:unprocessable_entity)
		end

		it 'renders an error if new password doesn\'t match confirmation password' do
			put :change_password, params: unchange_pass_params
			expect(response.body).to include("errors")
			expect(response).to have_http_status(:unprocessable_entity)
		end

		it 'renders an error if current password is wrong' do
			put :change_password, params: invalid_current_pass_params
			expect(response.body).to include("errors")
			expect(response).to have_http_status(:unprocessable_entity)
		end
	end
end
      