# frozen_string_literal: true

require 'rails_helper'
require 'spec_helper'

RSpec.describe BxBlockForgotPassword::OtpsController, type: :controller do
    describe 'POST #create' do
      context 'with valid email' do
        let(:email) { 'test@example.com' }
        let(:json_params) { { email: email } }
        let!(:account) do
            account = FactoryBot.build(:account)
            account.save(validate: false)
            account
          end
  
        before do
          allow(AccountBlock::EmailAccount).to receive(:where).and_return(AccountBlock::EmailAccount)
          allow(AccountBlock::EmailAccount).to receive(:first).and_return(account)
        end
  
        it 'creates a new EmailOtp' do
          expect {
            post :create, params: { data: { type: 'email_otp', attributes: json_params } }
          }.to change(AccountBlock::EmailOtp, :count).by(1)
        end
  
        it 'returns serialized EmailOtp and status :created' do
          post :create, params: { data: { type: 'email_otp', attributes: json_params } }
  
          expect(response).to have_http_status(:created)
          expect(response.body).to include("data")
        end
  
        it 'updates the token for the EmailOtp' do
          post :create, params: { data: { type: 'email_otp', attributes: json_params } }
          email_otp = AccountBlock::EmailOtp.last
  
          expect(email_otp.token).to be_present
          expect(email_otp.token).to be_a(String)
        end
  
        it 'returns an error message if account is not found' do
          allow(AccountBlock::EmailAccount).to receive(:first).and_return(nil)
  
          post :create, params: { data: { type: 'email_otp', attributes: json_params } }
  
          expect(response).to have_http_status(:not_found)
          expect(JSON.parse(response.body)).to include('errors')
        end
  
        it 'returns an error message if EmailOtp fails to save' do
          allow_any_instance_of(AccountBlock::EmailOtp).to receive(:save).and_return(false)
  
          post :create, params: { data: { type: 'email_otp', attributes: json_params } }
  
          expect(response).to have_http_status(:unprocessable_entity)
          expect(JSON.parse(response.body)).to include('errors')
        end
      end
    end
  end
  