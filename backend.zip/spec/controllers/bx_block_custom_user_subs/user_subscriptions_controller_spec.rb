require 'rails_helper'

RSpec.describe BxBlockCustomUserSubs::UserSubscriptionsController, type: :controller do
    let!(:jobseeker_account) do
        account = FactoryBot.create(:account)
        account.save(validate: false)
        account
    end
    let!(:plan) {FactoryBot.create(:subscription, advertisement_type: false, promotion_type: false)}
    let(:user_subscribed_plan){FactoryBot.create(:user_subscription, account_id: jobseeker_account.id, subscription_id: plan.id)}
    before do
        BxBlockCustomUserSubs::UserSubscription.destroy_all
        @token = BuilderJsonWebToken.encode jobseeker_account.id
        request.headers['token'] = @token 
    end

    describe '#index' do
    context 'when user have user_subscription present' do
        it 'must show the user_joblisting' do
            user_subscribed_plan.reload
            get :index, params: {token: @token}
            expect(response.status).to eq(200)
            expect(JSON.parse(response.body)['data']['attributes']['name']).to eq(plan.name)
        end
    end

    context 'when user has no subscribed plan present' do
        it 'must give error message' do
            user_subscribed_plan.destroy
            get :index, params: {token: @token} 
            expect(JSON.parse(response.body)['error']).to eq('No Subscried Plan Yet..!!')
        end
    end
    end
end