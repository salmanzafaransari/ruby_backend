require 'rails_helper'

RSpec.describe BxBlockCustomUserSubs::SubscriptionsController, type: :controller do
  let!(:jobseeker_account) do
      account = FactoryBot.create(:account)
  	account.save(validate: false)
  	account
  end

  let!(:recruiter_account) do
      account = FactoryBot.create(:account)
  end

  let!(:plan_1) {FactoryBot.create(:subscription)}
  let!(:plan_2) {FactoryBot.create(:subscription, name: 'Plan B')}
  let!(:count) {BxBlockCustomUserSubs::Subscription.jobseeker_signup_subscription.count}
  before do
      @token = BuilderJsonWebToken.encode jobseeker_account.id
      request.headers['token'] = @token
  end

  describe '#index' do
      context 'When valid User is present' do
          it 'must show the list of the Plans' do
             get :index, params: {token: @token} 
             expect(response.status).to eq(200)
             expect(JSON.parse(response.body)['data'].count).to eq(count)
          end
      end
  end

  describe "GET #advertisement_plan_list " do
    context 'when user is valid' do
      account = FactoryBot.create(:account) 
      subscription = FactoryBot.create(:subscription)
      user_subscription = FactoryBot.create(:user_subscription, account_id: account.id, subscription_id: subscription.id) 
      context "when advertisement plan is active" do
        it "show of advertisements plan" do
          allow(controller).to receive(:current_user).and_return(account)
          get :advertisement_plan_list
          expect(response).to have_http_status(200)
        end
      end

      context "when no plan id subscriptions" do
        it "returns a message indicating no advertisements plan is active" do
          BxBlockCustomUserSubs::Subscription.where(advertisement_type: true).delete_all
          get :advertisement_plan_list
          expect(response).to have_http_status(404)
        end
      end
    end
  end
end