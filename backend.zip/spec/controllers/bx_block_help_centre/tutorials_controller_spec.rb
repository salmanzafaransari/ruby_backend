# frozen_string_literal: true

require 'rails_helper'
require 'spec_helper'

RSpec.describe BxBlockHelpCentre::TutorialsController, type: :controller do

  let(:account) { FactoryBot.create(:account, account_role: "Jobseeker") }
  before do
    @token = BuilderJsonWebToken.encode account.id
    request.headers['token'] = @token
  end

  describe "GET index" do
    context "if atleast one Tutorial is present" do
      it "shows the list of all the tutorials" do
        FactoryBot.create_list(:tutorial, 5)
        get :index
        expect(response).to have_http_status(200)
        expect(JSON.parse(response.body)["data"]).to be_a(Array)
        expect(JSON.parse(response.body)["data"].count).to eq(BxBlockHelpCentre::Tutorial.count)
      end
    end

    context "when there are no tutorials present" do
      it "shows tutorials not present message" do
        get :index
        expect(response).to have_http_status(200)
        expect(JSON.parse(response.body)["message"]).to eq("No tutorials present.")
      end
    end
  end

  describe "GET show" do
    let(:tutorial) {FactoryBot.create(:tutorial)}
    it "shows the tutorial" do
      get :show_faq, params: {id: tutorial.id}
      expect(response).to have_http_status(200)
      expect(JSON.parse(response.body)["data"]["attributes"]["video_title"]).to eq(tutorial.video_title)
      expect(JSON.parse(response.body)["data"]["attributes"]["video"]["url"]).to eq(tutorial.video.url)
    end
  end
end
