# frozen_string_literal: true

require 'rails_helper'
require 'spec_helper'

RSpec.describe AccountBlock::AccountsController, type: :controller do
  let!(:account) do
    account = FactoryBot.build(:account)
    account.save(validate: false)
    account
  end

  let(:valid_email) {'admintest@gmail.com'}

  before do
    @token = BuilderJsonWebToken.encode account.id
  end

  let(:email_account) {FactoryBot.create(:email_account)}
  let(:json_response) {JSON.parse(response.body)}
  let(:new_account_params) do
    {
      data: {
        type: 'email_account',
        privacy_policy: true,
        attributes: {
          email: "test@example.com",
          password: 'Admin1234',
          password_confirmation: 'Admin1234',
          account_role: "Jobseeker"
        }
      }
    }
  end

  describe 'POST #create' do
    context 'when email_account type' do
      let(:email_account_params) do
        {
          data: {
            type: 'email_account',
            privacy_policy: true,
            attributes: {
              email: email_account.email,
              password: 'Admin1234',
              password_confirmation: 'Admin1234'
            }
          }
        }
      end

      before do
        allow(controller).to receive(:validate_json_web_token)
      end

      context 'when account already exists' do
        it 'returns error' do
          email_account
          FactoryBot.create(:profile_bio, account_id: email_account.id)
          post :create, params: email_account_params

          expect(response).to have_http_status(:unprocessable_entity)
          expect(json_response["errors"].first).to eq({"account"=>"Account already exist!"})
        end
      end

      context 'when account already exists' do
        it 'returns errors' do
          email_account
          post :create, params: email_account_params

          expect(response).to have_http_status(:created)
          expect(json_response).to include("data")
        end
      end

      context 'when account does not exist' do
        it 'creates a new email_account' do
          post :create, params: new_account_params

          expect(response).to have_http_status(:created)
          expect(json_response["data"]["type"]).to eq('email_account')
          expect(json_response["data"]["attributes"]["email"]).to eq('test@example.com')
          expect(json_response["meta"]["token"]).to be_present
        end
      end

      context 'when email is invalid' do
        let(:invalid_email_params) do
          new_account_params.deep_merge(data: { attributes: { email: 'invalid_email' } })
        end

        it 'return an error' do
          post :create, params: invalid_email_params

          expect(response).to have_http_status(:unprocessable_entity)
          expect(json_response["errors"][0]['account']).to eq('Email invalid')
        end
      end

      context 'when password is invalid' do
        let(:invalid_password_params) do
          new_account_params.deep_merge(data: { attributes: { password: 'pass', password_confirmation: 'pass'} })
        end

        it 'error is return' do
          post :create, params: invalid_password_params

          expect(response).to have_http_status(:unprocessable_entity)
          expect(json_response['errors'][0]['account']).to eq('Password should be a minimum of 8 characters long, contain both uppercase and lowercase characters, at least one digit')
        end
      end

      context 'when privacy_policy is not accepted' do
        let(:no_privacy_policy_params) do
          new_account_params[:data].delete(:privacy_policy)
          new_account_params
        end

        it 'error returned' do
          post :create, params: no_privacy_policy_params

          expect(response).to have_http_status(:unprocessable_entity)
          expect(json_response['errors'][0]['account']).to eq('Please accept Privacy Policy.')
        end
      end
    end

    context 'when invalid account type' do
      let(:invalid_account_params) do
        new_account_params.deep_merge(data: { type: "invalid" })
      end

      it 'returns an error' do
        post :create, params: invalid_account_params

        expect(response).to have_http_status(:unprocessable_entity)
        expect(json_response['errors'][0]['account']).to eq('Invalid Account Type')
      end
    end

    context 'when confirmation password is not present' do
      let(:invalid_account_params2) do
        new_account_params.deep_merge(data: { attributes: { password: 'Password123', password_confirmation: nil} })
      end 

      it 'gives error message of missing' do
        post :create, params: invalid_account_params2

        expect(response).to have_http_status(:unprocessable_entity)
        expect(json_response['errors'][0]['account']).to eq('Password Confirmation is missing.') 
      end
    end
  end

  describe 'Account setting cases' do
    it 'is expected to get logged user' do
      put :logged_user,
          params: { token: @token }
      expect(response).to have_http_status(:success)
    end

    it 'is expected to deactivate user' do
      put :deactivate,
          params: { token: @token }
      expect(response).to have_http_status(:success)
    end

    it 'is expected to delete user' do
      put :destroy,
          params: { token: @token }
      expect(response).to have_http_status(:success)
    end

    it 'is expected to get specific account' do
      put :specific_account,
          params: { token: @token }
      expect(response).to have_http_status(:success)
    end

    it 'is expected to edit phone number' do
      put :change_phone_number,
          params: { token: @token, full_phone_number: +918989898989 }
      expect(response).to have_http_status(:success)
    end

    it 'is expected to change user email' do
      put :change_email_address, params: { token: @token, new_email: "admintest@yopmail.com" }
      expect(response).to have_http_status(:ok)
    end

    it 'is expected to return error for invalid email' do
      put :change_email_address, params: { token: @token, new_email: "admintesyopmail.com" }
      expect(response).to have_http_status(:unprocessable_entity)
    end
  end

  describe "POST #save_device_token" do
    let(:device_token) { "jiu23hd87wchekrc8n3uwi4iw7d3hw473efcb2uy" }
    before do
      request.headers[:token] = @token
    end

    it "saves the device token" do
      post :save_device_token, params: {device_id: device_token}
      expect(response).to have_http_status(200)
      expect(json_response["data"]["attributes"]["device_ids"]).to include(device_token)
    end
  end

  describe '#get_location' do
    context 'When Params are not present' do
      it 'must give all the city with country name data set as default' do
        get :get_location, params: {token: @token}
        expect(json_response['locations'][0]).to eq('Mumbai, India')
      end

      it 'must give response on the basis of the country name present in its profile bio' do
        FactoryBot.create(:profile_bio, account_id: account.id, country: 'Saudi Arabia')
        get :get_location, params: {token: @token}
        expect(json_response['locations'][0]).to eq('Riyadh, Saudi Arabia')
      end
    end

    context 'when params are passed' do
      # it 'must give a response when exact params of state are passed' do
      #   get :get_location, params: {token: @token, location: 'Maharashtra'}
      #   expect(json_response['locations'].first).to eq('Maharashtra, India')
      # end

      # it 'must give a response when exact city name is passed' do
      #   get :get_location, params: {token: @token, location: 'Kalyani'}
      #   expect(json_response['locations']).to include('Kalyani, Nadia District, West Bengal, India')
      # end

      # it 'must give response as city name only for only_city flag set to true' do
      #   get :get_location, params: {token: @token, location: 'Kalyani', only_city: true}
      #   expect(json_response['locations'].first).to eq('Kalyani')
      # end

      # it 'must not find any location if wrong spelling or name is passed' do
      #   get :get_location, params: {token: @token, location: 'kjfshefjshfkshfk'}
      #   expect(json_response['error']).to eq('No Location found with this Name')
      # end
    end
  end

  describe '#update_location' do
    context 'when new location param is present' do
      it 'must update the user location' do
        patch :update_location, params: {token: @token, new_location: 'Kolkata, India'}
        expect(json_response['data']['attributes']['user_location']).to eq('Kolkata, India')
      end

      it 'must give error when last location and new location params are equal' do
        account.update_columns(user_location: 'Indore, India')
        patch :update_location, params: {token: @token, new_location: 'Indore, India'}
        expect(json_response['errors']).to eq('Your Location is already Updated')
      end
    end

    context 'when params is not present' do
      it 'must give error for no selection' do
        patch :update_location, params: {token: @token}
        expect(response.status).to eq(422)
        expect(json_response['errors']).to eq("You Haven't Selected any Location")
      end
    end
  end

  describe '#notification_status_change' do
    context 'when user has notify as true' do
      it 'must be updated to false' do
        patch :notification_status_change, params: {token: @token}
        expect(json_response['data']['attributes']['notify']).to eq(false)
      end
    end

    context 'when user has notify as false' do
      it 'must be updated to true' do
        account.update_column(:notify, false)
        patch :notification_status_change, params: {token: @token}
        expect(json_response['data']['attributes']['notify']).to eq(true)
      end
    end
  end
end
