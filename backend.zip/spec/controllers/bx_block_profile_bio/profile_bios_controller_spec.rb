# frozen_string_literal: true

require 'rails_helper'
require 'spec_helper'

RSpec.describe BxBlockProfileBio::ProfileBiosController, type: :controller do
  let!(:current_user) { FactoryBot.create(:account) }
  before do
    @token = BuilderJsonWebToken.encode current_user.id
    request.headers[:token] = @token
  end
  let(:resume) { 'files/Gerad_download.pdf' }
  let(:pdf_name) { 'files/Gerad_download.pdf' }
  let(:resume2) { 'files/Resume_test.pdf' }
  let(:pdf_name2) { 'files/My_Resume.pdf' }
  let(:pdf_type) { 'application/pdf' }
  let(:image_name) { 'files/passport.jpg' }
  let(:image_type) { 'image/png' }
  let(:video_name) { 'files/test_video.mp4' }
  let(:video_type) { 'video/mp4' }
  let(:account_data) do
    {
      attributes: {
        first_name: "test",
        last_name: "user",
        full_phone_number: "+919748835477"
      }
    }
  end

  let(:invalid_account_data) do
    {
      attributes: {
        first_name: "test",
        last_name: "user",
        full_phone_number: "+919748835433",
        email: "test@gmail.com"
      }
    }
  end

  let(:valid_profile_params_recruiter) do
    {
      data: {
        attributes: {
          company_name: "Test",
          country: "India",
          landline_number: 1234567890
        }
      },
      account_data: account_data,
      token: @token
    }
  end
  let!(:valid_profile_params_jobseeker) do
    {
      data: {
        attributes: {
          company_name: "Test",
          country: "India",
          height: 122,
          weight: 123,
          height_type: "cm",
          weight_type: "kg",
          open_for: "Full-Time",
          interested_in: ["Shore", "Ship"],
          seamen_book_number: 21678617825,
          available?: true,
          linkedin_url: 'frgbthnyjm.com',
          salary_range_usd: 10000,
          resume: fixture_file_upload(pdf_name, pdf_type),
          selfie_picture: fixture_file_upload(image_name, image_type),
          covid_19_certificate: fixture_file_upload(pdf_name, pdf_type),
          passport_picture: fixture_file_upload(image_name, image_type),
          health_record: [fixture_file_upload(pdf_name, pdf_type)],
          video_cv: fixture_file_upload(video_name, video_type),
          personality: [],
          interests: [],
          stcw:  fixture_file_upload(pdf_name, pdf_type),
          training_and_certifications: [fixture_file_upload(pdf_name, pdf_type)],
          total_work_experience: 2
        }
      },
      account_data: account_data,
      token: @token
    }
  end

  describe 'POST #create' do
    after(:each) do
      current_user.profile_bio.try(:destroy)
    end

    context 'when profile bio already exist' do
      before do
        FactoryBot.create(:profile_bio, account_id: current_user.id)
      end

      it 'renders "Profile Bio has already been created" error' do
        post :create, params: valid_profile_params_jobseeker
        expect(response).to have_http_status(422)
        expect(JSON.parse(response.body)["errors"]).to include({"profile"=>"Profile bio has been already created"})
      end

      it 'must give error for same number used to create new account' do
        current_user.update_columns(full_phone_number: "+919748835477", country_code: 91, phone_number: 9748835477)
        post :create, params: valid_profile_params_jobseeker
        err_msg = {"account"=>"This Phone Number is already Registered with another account"}
        expect(JSON.parse(response.body)['errors'].first).to eq(err_msg)
      end
    end

    context 'with valid params for jobseeker role' do
      # Commented below code as it was skipping the code and decreasing code coverage
      # before do
      #   allow(PDF::Reader).to receive(:new).and_return(double('PDF::Reader', pages: []))
      # end
      it 'creates a new profile bio of Jobseeker and returns serialized data' do
        current_user.update_column(:activated, false)
        # allow(RTesseract).to receive(:new).and_return("text")
        post :create, params: valid_profile_params_jobseeker

        expect(response).to have_http_status(:ok)
        response_body = JSON.parse(response.body)
        expect(response_body).to include("data")
        expect(AccountBlock::Account.find_by(id: response_body['data']['attributes']['account_id']).activated).to be true
        expect(response_body["data"]["attributes"]["account"]["account_role"]).to eq("Jobseeker")
      end

      context "when proper formatted resume is passed" do
        it "creates CV with the data mentioned into resume PDF" do
          valid_profile_params_jobseeker[:data][:attributes][:resume] = fixture_file_upload(resume, pdf_type)
          post :create, params: valid_profile_params_jobseeker
          expect(response).to have_http_status(:ok)
        end
      end

      context 'when proper formatted resume is not passed' do
        it 'creates the CV with Date of birth data as nil' do
          valid_profile_params_jobseeker[:data][:attributes][:resume] = fixture_file_upload(pdf_name2, pdf_type)
          post :create, params: valid_profile_params_jobseeker
          cv = BxBlockProfile::Cv.find_by(account_id: current_user.id)
          expect(response).to have_http_status(:ok)
          expect(cv.date_of_birth).to eq(nil)
        end
      end
    end

    context 'with valid params for Recruiter role' do
      it 'creates a new profile bio of Recruiter and returns serialized data' do
        current_user.update_columns(account_role: "Recruiter", activated: false)
        post :create, params: valid_profile_params_recruiter

        expect(response).to have_http_status(:ok)
        response_body = JSON.parse(response.body)
        expect(response_body).to include("data")
        expect(AccountBlock::Account.find_by(id: response_body['data']['attributes']['account_id']).activated).to be true
        expect(response_body["data"]["attributes"]["account"]["account_role"]).to eq("Recruiter")
      end
    end

    # context 'with invalid profile bio params' do
    #   it 'does not create profile_data' do
    #     valid_profile_params_jobseeker[:data][:attributes][:seamen_book_number] = nil
    #     post :create, params: valid_profile_params_jobseeker

    #     expect(response).to have_http_status(422)
    #     response_body = JSON.parse(response.body)
    #     expect(response_body["errors"]).to include(["Seamen book number can't be blank"])
    #   end
    # end
  end

  describe "GET edit" do
    let(:profile_bio1) { FactoryBot.create(:profile_bio, account_id: current_user.id) }
    let(:profile_bio2) { FactoryBot.create(:profile_bio) }
    context "when current_users id does not match with params[:profile_bio_id]" do
      it "returns 'Profile not found error'" do
        get :edit, params: { profile_bio_id: profile_bio2.account_id }
        expect(response).to have_http_status(404)
        expect(JSON.parse(response.body)["errors"][0]["profile"]).to eq("Profile not found")
      end
    end

    context "when current_users id match with params[:profile_bio_id]" do
      context "if profile bio exist" do
        it "returns the data successfully" do
          get :edit, params: { profile_bio_id: profile_bio1.account_id }
          expect(response).to have_http_status(200)
          expect(JSON.parse(response.body)["first_name"]).to eq(current_user.first_name)
        end
      end

      context "if profile bio does not exist" do
        it "returns 'Profile bio does not exist' error" do
          profile_bio1.destroy
          get :edit, params: { profile_bio_id: profile_bio1.account_id }
          expect(response).to have_http_status(404)
          expect(JSON.parse(response.body)["message"]).to eq("Profile bio doesn't exists")
        end
      end
    end
  end

  describe "PUT #update" do
    let(:profile_bio1) { FactoryBot.create(:profile_bio, account_id: current_user.id) }
    let(:profile_bio2) { FactoryBot.create(:profile_bio) }

    context "when current_users id does not match with params[:id]" do
      it "returns 'Profile not found error'" do
        valid_profile_params_jobseeker["id"] = profile_bio2.account_id
        put :update, params: valid_profile_params_jobseeker
        expect(response).to have_http_status(404)
        expect(JSON.parse(response.body)["errors"][0]["profile"]).to eq("Profile not found")
      end
    end

    context "when current_users id match with params[:id]" do
      let(:updated_seamen_book_number) { "abcdefgh" }
      let(:updated_company_name) { "Test name updated" }
      before do
        valid_profile_params_jobseeker["id"] = profile_bio1.account_id
        valid_profile_params_recruiter["id"] = profile_bio1.account_id
        valid_profile_params_jobseeker[:data][:attributes][:seamen_book_number] = updated_seamen_book_number
        valid_profile_params_recruiter[:data][:attributes][:company_name] = updated_company_name
      end

      context "when valid params of jobseeker role are passed" do
        let!(:cv){FactoryBot.create(:cv, account_id: current_user.id)}
        it "updates the Jobseeker profile bio and returns serialized data" do
          put :update, params: valid_profile_params_jobseeker
          expect(response).to have_http_status(:ok)
          response_body = JSON.parse(response.body)
          expect(response_body).to include("data")
          expect(response_body["data"]["attributes"]["account"]["account_role"]).to eq("Jobseeker")
          expect(response_body["data"]["attributes"]["seamen_book_number"]).to eq(updated_seamen_book_number)
          expect(current_user&.cv&.linkedin_url).to eq(valid_profile_params_jobseeker[:data][:attributes][:linkedin_url])
        end
      end

      context "when valid params of recruiter role are passed" do
        it "updates the Recruiter profile bio and returns serialized data" do
          current_user.update_column(:account_role, "Recruiter")
          put :update, params: valid_profile_params_recruiter
          expect(response).to have_http_status(:ok)
          response_body = JSON.parse(response.body)
          expect(response_body).to include("data")
          expect(response_body["data"]["attributes"]["account"]["account_role"]).to eq("Recruiter")
          expect(response_body["data"]["attributes"]["company_name"]).to eq(updated_company_name)
        end
      end

      context 'when email id matches with some other user' do
        before do
          valid_profile_params_recruiter["id"] = profile_bio1.account_id
          valid_profile_params_recruiter["account_data"] = invalid_account_data
        end
        it 'must give error' do
          FactoryBot.create(:email_account, email: 'test@gmail.com')
          current_user.update_columns(account_role: "Recruiter")
          put :update, params: valid_profile_params_recruiter
          expect(response.status).to eq(422)
          expect(JSON.parse(response.body)['error']).to eq('Email has already been taken')
        end
      end

      # context 'with invalid profile bio params' do
      #   it 'does not update profile_data' do
      #     valid_profile_params_jobseeker[:data][:attributes][:seamen_book_number] = nil
      #     put :update, params: valid_profile_params_jobseeker
  
      #     expect(response).to have_http_status(422)
      #     response_body = JSON.parse(response.body)
      #     expect(response_body["errors"]).to include({"profile"=>["Seamen book number can't be blank"]})
      #   end
      # end

      context 'when profile bio does not exist' do
        it 'renders "Profile Bio doesn\' t exist" error' do
          profile_bio1.destroy
          put :update, params: valid_profile_params_jobseeker
          expect(response).to have_http_status(404)
          expect(JSON.parse(response.body)["message"]).to eq("Profile bio doesn't exists")
        end
      end
    end
  end

  describe '#show_user_cv' do
    context 'when user signUp completed' do
      let!(:cv) { FactoryBot.create(:cv, account_id: current_user.id) }
      let!(:passport_and_visa_detail) { FactoryBot.create(:passport_and_visa_detail, cv_id: cv.id) }
      let!(:seamen_book_numbers) { FactoryBot.create_list(:seamen_book_number, 2, cv_id: cv.id) }
      let!(:professional_acedemic_qualifications) { FactoryBot.create_list(:professional_acedemic_qualification, 2, cv_id: cv.id) }
      let!(:licence_certificates_of_competencies) { FactoryBot.create_list(:licence_certificates_of_competency, 2, cv_id: cv.id) }
      let!(:stcw_value_added_courses) { FactoryBot.create_list(:stcw_value_added_course, 2, cv_id: cv.id) }
      let!(:work_experiences) { FactoryBot.create_list(:work_experience, 2, cv_id: cv.id) }
      after(:each) do
        current_user.profile_bio.try(:destroy)
      end
      before do
        FactoryBot.create(:profile_bio, account_id: current_user.id)
      end
      
      it 'must give the cv details' do
        get :show_user_cv, params: {token: @token}
        expect(response.status).to eq(200)
        expect(JSON.parse(response.body)["message"]).to eq("Your iSail CV is almost ready. Please proceed to verify and edit your details.")
      end

      it 'must give nil data for no cv' do
        current_user.cv.try(:destroy)
        get :show_user_cv, params: {token: @token}
        expect(response.status).to eq(200)
        expect(JSON.parse(response.body)["data"][0]).to eq(nil)
      end
    end
  end

  describe '#airport_list' do
    context 'searches airport csv file' do
      it 'must give the list of airports' do
        get :airport_list, params: {token: @token}
        expect(JSON.parse(response.body)['airports']).to include("Kidston Airport")
      end

      it 'should handle errors gracefully' do
        allow(controller).to receive(:read_airport_names).and_raise(StandardError, 'Failed To Retrieve Airport Names')
        get :airport_list, params: { token: @token }
        expect(response).to have_http_status(:internal_server_error)
        expect(JSON.parse(response.body)).to include('error' => 'Failed To Retrieve Airport Names')
      end
    end
  end
end