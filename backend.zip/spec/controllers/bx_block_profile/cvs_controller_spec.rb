# frozen_string_literal: true

require 'rails_helper'
require 'spec_helper'

RSpec.describe BxBlockProfile::CvsController, type: :controller do
  CURRENT_USER_NOT_PRESENT = "current user not present"
  CURRENT_USER_JOBSEEKER = "when current user is a Jobseeker"
  CURRENT_USER_NOT_JOBSEEKER = "when current user is not a Jobseeker"
  RAISE_AN_EXCEPTION = "raise an exception"
  # let(:pdf_name2) { 'files/My_Resume.pdf' }
  # let(:pdf_type) { 'application/pdf' }
  let(:jobseeker) { FactoryBot.create(:account, account_role: "Jobseeker") }
  let(:recruiter) { FactoryBot.create(:account, account_role: "Recruiter") }
  let(:cv) { FactoryBot.create(:cv, account_id: jobseeker.id) }
  let(:passport_and_visa_detail) { FactoryBot.create(:passport_and_visa_detail, cv_id: cv.id) }
  let(:seamen_book_numbers) { FactoryBot.create_list(:seamen_book_number, 2, cv_id: cv.id) }
  let(:professional_acedemic_qualifications) { FactoryBot.create_list(:professional_acedemic_qualification, 2, cv_id: cv.id) }
  let(:licence_certificates_of_competencies) { FactoryBot.create_list(:licence_certificates_of_competency, 2, cv_id: cv.id) }
  let(:stcw_value_added_courses) { FactoryBot.create_list(:stcw_value_added_course, 2, cv_id: cv.id) }
  let(:work_experiences) { FactoryBot.create_list(:work_experience, 2, cv_id: cv.id) }
  let(:passport_and_visa_detail_params) do
    {
      sid: "987654",
      passport_number: "123ABC",
      us_visa: "Yes",
      expiry_date: Date.today + 5.years
    }
  end
  let(:seamen_book_numbers_params) do
    [
      {
        seamen_book_number: "ASDFG",
        place_of_issue: "Test Place",
        issue_date: Date.today - 1.years,
        expiry_date: Date.today + 4.years
      }
    ]
  end
  let(:professional_acedemic_qualifications_params) do
    [
      {
        course: "Computer Engineering",
        institution: "Test instituition",
        qualification: "Bachelors of Engineering",
        grade: "A+",
        start_date: Date.today - 7.years,
        end_date: Date.today - 3.years
      }
    ]
  end
  let(:licence_certificates_of_competencies_params) do
    [
      {
        issue_authorithy: "Licence Authority",
        grade: "A",
        number: "123456",
        issue_date: Date.today - 2.years,
        expiry_date: Date.today + 3.years,
        revalidate_date: Date.today + 1.years,
        issue_country: "India"
      }
    ]
  end
  let(:stcw_value_added_courses_params) do
    [
      {
        stcw_course: "STCW Course",
        certificate_number: "123456",
        issue_date: "20/05/2022",
        expiry_date: "20/05/2029",
        issuing_body: "Issuing Authority"
      }
    ]
  end
  let(:work_experiences_params) do
    [
      {
        company: "Company",
        vessel_name: "Vessel1",
        vessel_type: "Spherical",
        vessel_dwt: "ASDF",
        vessel_imo: "LKJH",
        vessel_position: "Base",
        start_date: Date.today - 1.years,
        end_date: Date.today + 4.years
      }
    ]
  end
  let(:valid_params) do
    {
      data: {
        attributes: {
          bio: "Cv Bio goes here",
          first_name: jobseeker.first_name,
          last_name: jobseeker.last_name,
          email: jobseeker.email,
          full_phone_number: jobseeker.full_phone_number,
          rank: 1,
          availability_date: Date.today + 2.months,
          height: 180,
          weight: 76,
          date_of_birth: Date.today - 25.years,
          place_of_birth: "Test Place",
          nationality: "Indian",
          city: "Test city",
          nearest_intl_airport: "Ahmedabad Intl Airport"
        },
        passport_and_visa_detail_attributes: passport_and_visa_detail_params,
        seamen_book_numbers_attributes: seamen_book_numbers_params,
        professional_acedemic_qualifications_attributes: professional_acedemic_qualifications_params,
        licence_certificates_of_competencies_attributes: licence_certificates_of_competencies_params,
        stcw_value_added_courses_attributes: stcw_value_added_courses_params,
        work_experiences_attributes: work_experiences_params
      }
    }
  end

  RSpec.shared_context CURRENT_USER_NOT_PRESENT do
    before do
      @token = BuilderJsonWebToken.encode jobseeker.id
      request.headers[:token] = @token
      allow(controller).to receive(:check_account_activated).and_return(jobseeker)
      allow(controller).to receive(:current_user).and_return(nil)
    end
  end

  RSpec.shared_context CURRENT_USER_NOT_JOBSEEKER do
    before do
      @token = BuilderJsonWebToken.encode recruiter.id
      request.headers[:token] = @token
    end
  end

  RSpec.shared_context CURRENT_USER_JOBSEEKER do
    before do
      @token = BuilderJsonWebToken.encode jobseeker.id
      request.headers[:token] = @token
    end
  end

  describe "#POST create" do
    context CURRENT_USER_NOT_PRESENT do
      include_context CURRENT_USER_NOT_PRESENT

      it RAISE_AN_EXCEPTION do
        post :create, params: valid_params
        expect(response).to have_http_status(422)
        expect(JSON.parse(response.body)["errors"]).to_not be_empty
      end
    end

    context CURRENT_USER_NOT_JOBSEEKER do
      include_context CURRENT_USER_NOT_JOBSEEKER

      it 'does not create Cv and gives "Only Jobseeker is authorized to perform this action" error' do
        post :create, params: valid_params
        expect(response).to have_http_status(422)
        expect(JSON.parse(response.body)["error"]).to eq("Only Jobseeker is authorized to perform this action.")
      end
    end

    context CURRENT_USER_JOBSEEKER do
      include_context CURRENT_USER_JOBSEEKER

      context "when valid cv params are passed" do
        it "creates a CV successfully" do
          expect{ post :create, params: valid_params }.to change{BxBlockProfile::Cv.count}.by(1)
          expect(response).to have_http_status(201)
          expect(JSON.parse(response.body)["data"]["attributes"]).to include("bio")
          expect(JSON.parse(response.body)["data"]["attributes"]).to include("first_name")
          expect(JSON.parse(response.body)["data"]["attributes"]).to include("last_name")
        end
      end

      context "when invalid cv params are passed" do
        before do
          valid_params[:data][:attributes][:bio] = nil
        end

        it "does not create a CV and returns an error" do
          expect{ post :create, params: valid_params }.to change{BxBlockProfile::Cv.count}.by(0)
          expect(response).to have_http_status(422)
        end
      end
    end
  end

  describe "#GET show" do
    include_context CURRENT_USER_JOBSEEKER

    it "returns a CV" do
      get :show, params: {id: cv.id}
      expect(response).to have_http_status(200)
      expect(JSON.parse(response.body)["data"]["attributes"]["bio"]).to eq(cv.bio)
      expect(JSON.parse(response.body)["data"]["attributes"]["first_name"]).to eq(cv.first_name)
      expect(JSON.parse(response.body)["data"]["attributes"]["last_name"]).to eq(cv.last_name)
    end
  end

  describe "#PUT update" do
    before do
      valid_params[:id] = cv.id
    end

    context "when current user is a Jobseeker and the cv belongs to that user" do
      include_context CURRENT_USER_JOBSEEKER
      context "and valid params are passed" do
        let(:updated_first_name) { "Updated fname" }

        it "updates the CV successfully" do
          valid_params[:data][:attributes][:first_name] = updated_first_name
          put :update, params: valid_params

          expect(response).to have_http_status(200)
          expect(JSON.parse(response.body)["data"]["attributes"]["first_name"]).to eq(updated_first_name)
        end
      end

      context "and invalid params are passed" do
        let(:updated_first_name) { "" }

        it "does not update CV and returns the error" do
          valid_params[:data][:attributes][:first_name] = updated_first_name
          put :update, params: valid_params

          expect(response).to have_http_status(422)
          expect(JSON.parse(response.body)["errors"]).to_not be_blank
        end
      end
    end

    context CURRENT_USER_NOT_JOBSEEKER do
      include_context CURRENT_USER_NOT_JOBSEEKER

      it 'does not update Cv and gives "You are not authorized to perform this action" error' do
        valid_params[:data][:attributes][:first_name] = "Updated First name"
        put :update, params: valid_params

        expect(response).to have_http_status(422)
        expect(JSON.parse(response.body)["error"]).to eq("You are not authorized to perform this action.")
      end
    end

    context CURRENT_USER_NOT_PRESENT do
      include_context CURRENT_USER_NOT_PRESENT

      it RAISE_AN_EXCEPTION do
        put :update, params: valid_params
        expect(response).to have_http_status(422)
        expect(JSON.parse(response.body)["errors"]).to_not be_empty
      end
    end
  end

  describe "#DELETE destroy" do
    context CURRENT_USER_NOT_PRESENT do
      include_context CURRENT_USER_NOT_PRESENT

      it RAISE_AN_EXCEPTION do
        delete :destroy, params: {id: cv.id}
        expect(response).to have_http_status(422)
        expect(JSON.parse(response.body)["errors"]).to_not be_empty
      end
    end

    context CURRENT_USER_NOT_JOBSEEKER do
      include_context CURRENT_USER_NOT_JOBSEEKER

      it RAISE_AN_EXCEPTION do
        delete :destroy, params: {id: cv.id}
        expect(response).to have_http_status(422)
        expect(JSON.parse(response.body)["error"]).to eq("You are not authorized to perform this action.")
      end
    end

    context "when current user is Jobseeker and cv belongs to the current user" do
      include_context CURRENT_USER_JOBSEEKER

      context "deletes the cv succesfully" do
        it "returns success message" do
          delete :destroy, params: {id: cv.id}
          expect(response).to have_http_status(200)
          expect(JSON.parse(response.body).keys).to include("success")
        end
      end
    end
  end

  describe '#download_cv' do
    context 'when when user is present' do
    include_context CURRENT_USER_JOBSEEKER
      before do
        pdf_file = Tempfile.new(["my_cv",".pdf"])
        Prawn::Document.generate(pdf_file.path) do
          text "name: test"
        end
        pdf_file_uploader = PdfUploader.new(jobseeker, :pdf)
        pdf_file_uploader.cache!(pdf_file)
        pdf_file_uploader.store!
        jobseeker.personalise_cv = pdf_file_uploader
        jobseeker.save!
        pdf_file.close
        pdf_file.unlink
      end
      it 'must download the cv when personalise cv present' do
        get :download_cv, params: {token: @token}
        expect( JSON.parse(response.body)["personalise_cv"]).to eq(jobseeker.personalise_cv)
      end

      it 'must give error message' do
        jobseeker.personalise_cv = nil
        jobseeker.save!
        get :download_cv, params: {token: @token}
        expect( JSON.parse(response.body)['error'] ).to eq("Cv Not present.")
      end

      context '#download_candidate_cv' do
      let!(:joblisting){FactoryBot.create(:joblisting, account_id: recruiter.id)}
      let!(:user_joblisting){FactoryBot.create(:user_joblisting, account_id: jobseeker.id, joblisting_id: joblisting.id)}
        include_context CURRENT_USER_NOT_JOBSEEKER
        it 'must give the reume url of the candidate' do
          get :download_candidate_cv, params: {token: @token, candidate_id: jobseeker.id, joblisting_id: joblisting.id}
          expect( JSON.parse(response.body)["personalise_cv"]).to eq(user_joblisting.resume.url)
        end

        it 'must give error of the candidate' do
          get :download_candidate_cv, params: {token: @token, candidate_id: jobseeker.id, joblisting_id: "123w2n"}
          expect( JSON.parse(response.body)["error"]).to eq("Cv Not present.")
        end

        it 'must give error message' do
          # jobseeker.personalise_cv = nil
          # jobseeker.save!
          get :download_candidate_cv, params: {token: @token, candidate_id: jobseeker.id}
          expect( JSON.parse(response.body)['error'] ).to eq("Candidate Doesn't exist anymore or Joblisting is unavailable.")
        end
      end
    end
  end

  describe '#get_location_for_cv' do
    context 'when params are present' do
      include_context CURRENT_USER_JOBSEEKER

      # it 'must give the response of list of cities' do
      #   get :get_location_for_cv, params: {token: @token, location: 'Surat', only_city: true}
      #   expect(JSON.parse(response.body)['locations']).to include('Surat')
      # end

      # it 'must give response of city list with state and country name also' do
      #   get :get_location_for_cv, params: {token: @token, location: 'Surat', only_city: false}
      #   expect(JSON.parse(response.body)['locations']).to include("Surat, Katargam Taluka, Surat District, Gujarat, 395008, India")
      # end

      it 'must give error when wrong params are passed' do
        get :get_location_for_cv, params: {token: @token, location: 'nocityname', only_city: false}
        expect(JSON.parse(response.body)['error']).to eq("No Location found with this Name")
      end
    end

    context 'when params not present' do
      include_context CURRENT_USER_JOBSEEKER

      before do
        jobseeker.reload
        cv.reload
      end

      it 'must give the response of already present city in cv' do
        get :get_location_for_cv, params: {token: @token}
        expect(JSON.parse(response.body)['locations']).to include(cv&.city)
      end

      it 'must give empty array when city is empty' do
        cv.update_column(:city, nil)
        get :get_location_for_cv, params: {token: @token}
        expect(JSON.parse(response.body)['locations']).to eq([])
      end
    end
  end

  describe "#certifications" do
    include_context CURRENT_USER_JOBSEEKER
    let(:recruiter) { FactoryBot.create(:account, account_role: "Recruiter") }
    let(:jobseeker) { FactoryBot.create(:account) }
    let!(:joblisting) { FactoryBot.create(:joblisting, account_id: recruiter.id) }
    let!(:user_joblisting) { FactoryBot.create(:user_joblisting, account_id: jobseeker.id, joblisting_id: joblisting.id) }
    
    it "returns STCW certificate if type is 'stcw'" do
      get :certifications, params: { token: @token, candidate_id: jobseeker.id, joblisting_id: joblisting.id, type: 'stcw' }
      expect(response).to have_http_status(:ok)
      expect(JSON.parse(response.body)['data']).to have_key("stcw_certificate")
    end

    it "returns training and certifications if type is 'training_and_certifications'" do
      get :certifications, params: { token: @token, candidate_id: jobseeker.id, joblisting_id: joblisting.id, type: 'training_and_certifications' }
      expect(response).to have_http_status(:ok)
      expect(JSON.parse(response.body)['data']&.first).to have_key("training_and_certifications")
    end

    it "returns error for invalid certificate type" do
      params = { token: @token, candidate_id: jobseeker.id, joblisting_id: joblisting.id, type: 'invalid_type' }
      get :certifications, params: params
      expect(response).to have_http_status(:bad_request)
      expect(JSON.parse(response.body)).to eq({ "error" => "Invalid certificate type specified." })
    end

    it "returns error if candidate or joblisting is not present" do
      params = { token: @token, candidate_id: jobseeker.id, joblisting_id: nil, type: 'stcw' }
      get :certifications, params: params
      expect(response).to have_http_status(:bad_request)
      expect(JSON.parse(response.body)).to eq({ "error" => "Candidate ID or job listing ID not provided." })
    end

    it "returns error if no certificate found for the specified candidate and job listing" do
      params = { token: @token, candidate_id: jobseeker.id, joblisting_id: joblisting.id + 1, type: 'stcw' } 
      get :certifications, params: params
      expect(response).to have_http_status(:not_found)
      expect(JSON.parse(response.body)).to eq({ "error" => "No certificate found for the specified candidate and job listing." })
    end
  end
end
