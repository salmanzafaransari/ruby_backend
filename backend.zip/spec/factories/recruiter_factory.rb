require 'faker'

FactoryBot.define do
  factory :recruiter, class: 'BxBlockProfileBio::ProfileBio' do
    account_id { FactoryBot.create(:account).id }
    company_name { "test organization" }
    country {"India"}
    landline_number {124325}
  end
end