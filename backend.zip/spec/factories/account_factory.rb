require 'faker'

FactoryBot.define do
  factory :account, class: 'AccountBlock::Account' do
    email { "admintest@gmail.com" }
    full_phone_number { 911234567890 }
    password { "Admin1234" }
    password_confirmation { "Admin1234" }
    account_role { "Jobseeker" }
    first_name { 'test' }
    last_name { "tester" }
    activated { true }
    unique_auth_id { "absbcausyvazzxczq827" }
    device_ids { ["oiuyhtfr5467897h6546787wdh36784wchr36728d936d72hyxt"] }
  end
end