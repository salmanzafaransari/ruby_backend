require 'faker'

FactoryBot.define do
  factory :payment_admin, class: 'BxBlockPaymentAdmin::PaymentAdmin' do
    transaction_id { "123456789" }
    account_id { FactoryBot.create(:account).id }
    current_user_id { FactoryBot.create(:account).id }
    payment_status { "Pending" }
    payment_method { "paypal" }
    user_amount { 1000 }
    post_creator_amount { 500 }
    third_party_amount { 250 }
    admin_amount { 100 }
  end
end
