require 'faker'

FactoryBot.define do
  factory :push_notification, class: 'BxBlockPushNotifications::PushNotification' do
    push_notificable_type { "AccountBlock::Account" }
    push_notificable_id { FactoryBot.create(:account).id }
    notify_type { "Test Headings" }
    remarks { "Test Contents" }
    redirection_url { "dummy_redirection_url.com" }
    is_read { false }
  end
end
