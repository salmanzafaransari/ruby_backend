require 'faker'

FactoryBot.define do
  factory :ads_frequency, class: 'BxBlockCustomAds::AdsFrequency' do
    name { "2 per 100" }
    rank { 2 }
  end
end
