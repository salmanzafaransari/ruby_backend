require 'faker'

FactoryBot.define do
  factory :privacy_policy, class: 'BxBlockDocumentstorage::PrivacyPolicy' do
    title {'Terms and Conditions'}
    title_font_color_code {'Red'}
    title_font_style {'Bold'}
    description {'Testing Description for this Privacy Policy'}
    description_font_color_code {'Blue'}
    description_font_style {'Italic'}
  end
end
