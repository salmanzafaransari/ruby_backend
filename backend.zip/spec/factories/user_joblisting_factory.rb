require 'faker'

PDF_MIME_TYPE = 'application/pdf'.freeze
EXAMPLE_PDF_FILE = 'example.pdf'.freeze

FactoryBot.define do
  factory :user_joblisting, class: 'BxBlockJoblisting::UserJoblisting' do
    account_id { FactoryBot.create(:account).id }
    joblisting_id { FactoryBot.create(:joblisting).id }
    status { "applied" }
    full_name { "#{account.first_name} #{account.last_name}" }
    email { account.email }
    full_phone_number { account.full_phone_number }
    resume { File.open(Rails.root.join("spec/fixtures/files/My_Resume.pdf")) }
    video_cv { File.open(Rails.root.join("spec/fixtures/files/test_video.mp4")) }
    transient do
      attachment { Rack::Test::UploadedFile.new(Rails.root.join('spec', 'fixtures', EXAMPLE_PDF_FILE), PDF_MIME_TYPE) }
    end
    training_and_certifications {  [ Rack::Test::UploadedFile.new(Rails.root.join('spec', 'fixtures','files', EXAMPLE_PDF_FILE), PDF_MIME_TYPE) ] } 
    stcw { Rack::Test::UploadedFile.new(Rails.root.join('spec', 'fixtures','files', EXAMPLE_PDF_FILE), PDF_MIME_TYPE) } 
  end
end
