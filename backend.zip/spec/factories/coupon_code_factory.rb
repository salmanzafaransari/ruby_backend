require 'faker'

FactoryBot.define do
  factory :coupon_code, class: 'BxBlockCouponCg::CouponCode' do
    title { "Full Discount Coupon" }
    code { 'JPTFDC100' }
    discount_type { "percentage" }
    discount { 100.00 }
    valid_from { DateTime.now }
    valid_to { DateTime.now+12.months }
    min_cart_value { 0.0 }
    max_cart_value { 50000.0 }
  end
end