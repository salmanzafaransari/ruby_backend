require 'faker'

FactoryBot.define do
  factory :email_account, class: 'AccountBlock::EmailAccount' do
    email { "admintest@gmail.com" }
    full_phone_number {rand(10**9..10**10)}
    password { "Admin1234" }
    password_confirmation { "Admin1234" }
    account_role { "Jobseeker" }
    first_name { 'test' }
    last_name { "tester" }
    activated { true }
  end
end