require 'faker'

FactoryBot.define do
  factory :subscription, class: 'BxBlockCustomUserSubs::Subscription' do
    name { "Plan A" }
    description { '{"1": "Benefit First", "2": "Benefit Second", "3": "Benefit Third"}' }
    price { 2500 }
    valid_for {12}
    currency {'usd'}
    image {}
    promotion_type { true }
    max_promotions { 5 }
    advertisement_type { true }
    for_recruiter { false }
    max_advertisements { 5 }
    ads_frequency_id {FactoryBot.create(:ads_frequency)&.id}
  end
end