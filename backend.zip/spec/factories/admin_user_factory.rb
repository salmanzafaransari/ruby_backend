require 'faker'

FactoryBot.define do
  factory :admin_user, class: 'AdminUser' do
    first_name { 'Admin' }
    last_name { 'Test' }
    email { "admintest@gmail.com" }
    full_phone_number { '919876543243' }
    country { 'India' }
    landline_number { '07923456789' }
    password { "Admin1234" }
    role { "super_admin" }
  end
end