require 'faker'

FactoryBot.define do
  factory :user_subscription, class: 'BxBlockCustomUserSubs::UserSubscription' do
    account_id { FactoryBot.create(:account).id }
    subscription_id { FactoryBot.create(:subscription).id }
    expiry_date {Date.today + 12.months}
  end
end