FactoryBot.define do
  factory :bx_block_documentstorage_privacy_policy, class: 'BxBlockDocumentstorage::PrivacyPolicy' do
    
  end
end
