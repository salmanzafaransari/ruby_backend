require 'faker'

FactoryBot.define do
  factory :advertisement, class: 'BxBlockCustomAds::Advertisement' do
    name { "Text advertisement" }
    description { "Test Description" }
    ads_count { 4 }
    jobs_count { 100 }
    account_id { FactoryBot.create(:account, account_role: "Recruiter").id }
    joblisting_id { FactoryBot.create(:joblisting, account_id: account_id) }

    after(:build) do |advertisement|
      advertisement.banner.attach(io: File.open(Rails.root.join("spec/fixtures/files/test.png")), filename: 'test.png', content_type: 'image/png')
    end
  end
end
