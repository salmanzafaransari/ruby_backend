require 'faker'

FactoryBot.define do
  factory :order_transaction, class: 'BxBlockOrderManagement::OrderTransaction' do
  	account_id { FactoryBot.create(:account).id }
  	subscription_id{FactoryBot.create(:subscription).id}
  	order_management_order_id{FactoryBot.create(:order, subscription_id: subscription_id).id}
  	amount {2000}
  	payment_type {'Offline'}
  	charge_status {'Payment Initiated'}
  end
end