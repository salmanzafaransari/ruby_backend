require 'faker'

FactoryBot.define do
  factory :joblisting, class: 'BxBlockJoblisting::Joblisting' do
    account_id { FactoryBot.create(:account).id }
    job_title {'Software Engineer'}
    position_location {'New York'}
    salary_range {'$80,000 - $100,000'}
    duration_of_position {'Full-time'}
    months_on_board {12}
    months_off_board {2}
    open_position {'Technology'}
    vessel_type {'N/A'}
    location {'New York'}
    starting_condition {Date.today.strftime("%d/%m/%Y").to_s}
    job_description {'Testing Description'}
    responsibilities {'Tester'}
    required_certifications {['Cert A', 'Cert B']}
    positions {['Position A', 'Position B']}
    promoted { false }
    promoted_at { nil }
    currency {'usd'}
    
    after(:build) do |joblisting|
      category = FactoryBot.create(:category)
      
      joblisting.joblisting_categories_attributes = [
        { category_id: category.id }
      ]
    end
  end
end
