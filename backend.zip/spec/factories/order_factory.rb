require 'faker'

FactoryBot.define do
  factory :order, class: 'BxBlockOrderManagement::Order' do
  	account_id { FactoryBot.create(:account).id }
  	subscription_id{FactoryBot.create(:subscription).id}
  	amount {2000}
  	sub_total {2000.0}
  end
end
