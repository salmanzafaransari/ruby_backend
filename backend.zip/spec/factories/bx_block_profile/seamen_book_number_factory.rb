require 'faker'

FactoryBot.define do
  factory :seamen_book_number, class: 'BxBlockProfile::SeamenBookNumber' do
    cv_id { FactoryBot.create(:cv).id }
    seamen_book_number { "ABCD123" }
    place_of_issue { "India" }
    issue_date { Date.today }
    expiry_date { Date.today + 5.years }
  end
end
