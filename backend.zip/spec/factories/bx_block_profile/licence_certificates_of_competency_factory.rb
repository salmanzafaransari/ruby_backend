require 'faker'

FactoryBot.define do
  factory :licence_certificates_of_competency, class: 'BxBlockProfile::LicenceCertificatesOfCompetency' do
    cv_id { FactoryBot.create(:cv).id }
    issue_authorithy { "Authority" }
    number { "ABCD123" }
    grade { "B" }
    issue_date { Date.today }
    expiry_date { Date.today + 5.years }
    revalidate_date { Date.today + 3.years }
    issue_country { "India" }
  end
end
