require 'faker'

FactoryBot.define do
  factory :stcw_value_added_course, class: 'BxBlockProfile::StcwValueAddedCourse' do
    cv_id { FactoryBot.create(:cv).id }
    stcw_course { "Test Course" }
    certificate_number { "123456" }
    issue_date { Date.today }
    expiry_date { Date.today + 5.years }
    issuing_body { "Test Issuing Body" }
  end
end
