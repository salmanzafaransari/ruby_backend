require 'faker'

FactoryBot.define do
  factory :work_experience, class: 'BxBlockProfile::WorkExperience' do
    cv_id { FactoryBot.create(:cv).id }
    company { "Test company" }
    vessel_name { "Test Vessel" }
    vessel_type { "Cylindrical" }
    vessel_dwt { "ABCD" }
    vessel_imo { "PQRS" }
    vessel_position { "Top" }
    start_date { Date.today }
    end_date { Date.today + 5.years }
  end
end
