require 'faker'

FactoryBot.define do
  factory :cv, class: 'BxBlockProfile::Cv' do
    account_id { FactoryBot.create(:account).id }
    bio { "Test bio" }
    first_name { "John" }
    middle_name { "Parker" }
    last_name { "Doe" }
    email { "test@yopmail.com" }
    full_phone_number { "918448411276" }
    availability_date { Date.today + 1.month }
    rank { "Officer" }
    date_of_birth { Date.today - 25.years }
    place_of_birth { "Mumbai" }
    nationality { "Indian" }
    city { "Mumbai" }
    nearest_intl_airport { "Mumbai" }
    height { 180 }
    weight { 75 }
    blood_group { "A+" }
    gender { "Male" }
    boiler_suit_size { "Large" }
    eyes_color { "Blue" }
    hair_color { "Black" }
  end
end