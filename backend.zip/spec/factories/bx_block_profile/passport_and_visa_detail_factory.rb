require 'faker'

FactoryBot.define do
  factory :passport_and_visa_detail, class: 'BxBlockProfile::PassportAndVisaDetail' do
    cv_id { FactoryBot.create(:cv).id }
    sid { "123456" }
    passport_number { "ABCD1234" }
    expiry_date { Date.today + 5.years }
    us_visa { "ABCD123" }
  end
end
