require 'faker'

FactoryBot.define do
  factory :professional_acedemic_qualification, class: 'BxBlockProfile::ProfessionalAcedemicQualification' do
    cv_id { FactoryBot.create(:cv).id }
    course { "Computer Engineering" }
    institution { "Test Insititute" }
    qualification { "Bachelors" }
    grade { "A" }
    start_date { Date.today - 5.years }
    end_date { Date.today - 1.years }
  end
end
