require 'faker'

FactoryBot.define do
  factory :tutorial, class: 'BxBlockHelpCentre::Tutorial' do
    video_title { "Video Title" }
    # video { File.open(Rails.root.join("spec/fixtures/files/test_video.mp4")) }
  end
end
