require 'faker'

PDF_MIME_TYPE = 'application/pdf'.freeze
EXAMPLE_PDF_FILE = 'example.pdf'.freeze

FactoryBot.define do
  factory :profile_bio, class: 'BxBlockProfileBio::ProfileBio' do
    transient do
      attachment { Rack::Test::UploadedFile.new(Rails.root.join('spec', 'fixtures', EXAMPLE_PDF_FILE), PDF_MIME_TYPE) }
      pdf_path { "spec/fixtures/files/#{EXAMPLE_PDF_FILE}" }
      image_path { "spec/fixtures/files/test.png" }
      pdf_path2 { "spec/fixtures/files/My_Resume.pdf" }
      video_path { "spec/fixtures/files/test_video.mp4" }
    end
    account_id { FactoryBot.create(:account).id }
    open_for { "Full-Time" }
    height_type { "cm" }
    weight_type { "kg" }
    height {123}
    weight {42}
    total_work_experience {2}
    interested_in { ["Shore"] }
    seamen_book_number {'dwefrgthyju'}
    linkedin_url {'example_url_for_linkedin'}
    available? {true}
    salary_range_usd {10000}
    covid_19_certificate do
      File.open(Rails.root.join(pdf_path))
    end
    resume do
      File.open(Rails.root.join(pdf_path2))
    end
    passport_picture do
      File.open(Rails.root.join(image_path))
    end
    selfie_picture do
      File.open(Rails.root.join(image_path))
    end
    health_record do
      [File.open(Rails.root.join(pdf_path))]
    end
    video_cv do
      File.open(Rails.root.join(video_path))
    end
    training_and_certifications { [Rack::Test::UploadedFile.new(Rails.root.join('spec', 'fixtures','files', EXAMPLE_PDF_FILE), PDF_MIME_TYPE)] }
    stcw { Rack::Test::UploadedFile.new(Rails.root.join('spec', 'fixtures','files', EXAMPLE_PDF_FILE), PDF_MIME_TYPE) }  
  end
end
