require 'faker'

FactoryBot.define do
  factory :sub_category, class: 'BxBlockCategories::SubCategory' do
    category_id {FactoryBot.create(:category).id}
    name { "test" }
  end
end
