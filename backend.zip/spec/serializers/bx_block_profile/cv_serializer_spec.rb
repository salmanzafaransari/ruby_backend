require 'rails_helper'

RSpec.describe BxBlockProfile::CvSerializer do
	let(:cv) { FactoryBot.create(:cv) }

	subject { described_class.new(cv) }

	describe '#attributes' do
		it 'includes the expected attributes' do
			expected_attributes = [
				:bio, :first_name, :middle_name, :last_name, :rank, :availability_date, :email,
        :full_phone_number, :date_of_birth, :place_of_birth, :nationality, :city, :nearest_intl_airport,
        :height, :weight, :blood_group, :gender, :boiler_suit_size, :eyes_color, :hair_color,
        :account, :passport_and_visa_detail, :seamen_book_numbers, :professional_acedemic_qualifications,
        :licence_certificates_of_competencies, :stcw_value_added_courses, :work_experiences, :video_cv
			]
			response_array = JSON.parse(subject.to_json)["data"]["attributes"].keys
			expected_attributes.each do |attr|
				expect(response_array.compact).to include(attr&.to_s)
			end
		end
	end
end