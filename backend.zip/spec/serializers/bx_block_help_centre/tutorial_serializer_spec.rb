require 'rails_helper'

RSpec.describe BxBlockHelpCentre::TutorialSerializer do
	let(:tutorial) { FactoryBot.create(:tutorial) }

	subject { described_class.new(tutorial) }

	describe '#attributes' do
		it 'includes the expected attributes' do
			expected_attributes = [:video_title, :video, :created_at, :updated_at]
			response_array = JSON.parse(subject.to_json)["data"]["attributes"].keys
			expected_attributes.each do |attr|
				expect(response_array.compact).to include(attr&.to_s)
			end
		end
	end
end