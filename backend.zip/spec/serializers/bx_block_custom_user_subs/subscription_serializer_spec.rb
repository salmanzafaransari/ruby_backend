require 'rails_helper'

RSpec.describe BxBlockCustomUserSubs::SubscriptionSerializer do
    before(:each) do
		@data = serialized_data[:data][:attributes]
	end

    describe 'serialization' do
        let!(:plan){FactoryBot.create(:subscription)}
        let(:serialized_data) { described_class.new(plan).serializable_hash }

        it 'serializes the joblisting attributes correctly' do
			expect(@data[:name]).to eq(plan.name)
			expect(@data[:description]).to eq(JSON.parse(plan.description))
			expect(@data[:price]).to eq(plan.price)
		end
    end
end