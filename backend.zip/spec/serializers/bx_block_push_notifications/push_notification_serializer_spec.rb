require 'rails_helper'

RSpec.describe BxBlockPushNotifications::PushNotificationSerializer do
	let(:push_notification) { FactoryBot.create(:push_notification) }

	subject { described_class.new(push_notification) }

	describe '#attributes' do
		it 'includes the expected attributes' do
			expected_attributes = [
        :notify_type, :remarks, :redirection_url, :push_notificable, :is_read,
				:created_at, :updated_at ]
			response_array = JSON.parse(subject.to_json)["data"]["attributes"].keys
			expected_attributes.each do |attr|
				expect(response_array.compact).to include(attr&.to_s)
			end
		end
	end
end
