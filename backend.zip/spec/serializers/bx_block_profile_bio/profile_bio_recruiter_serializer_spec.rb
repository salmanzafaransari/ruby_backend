require 'rails_helper'

RSpec.describe BxBlockProfileBio::ProfileBioRecruiterSerializer do
	let(:account) { FactoryBot.create(:account, account_role: "Recruiter") }
	let(:recruiter) { FactoryBot.create(:profile_bio, account_id: account.id,company_name: "test organization",
										country: "India", landline_number: 124325) }

	subject { BxBlockProfileBio::ProfileBioRecruiterSerializer.new(recruiter) }

	describe '#attributes' do
		it 'includes the expected attributes' do
			expected_attributes = [
				:account_id, :company_name, :country, :landline_number, :account
			]
			response_array = JSON.parse(subject.to_json)["data"]["attributes"].keys
			expected_attributes.each do |attr|
				expect(response_array.compact).to include(attr&.to_s)
			end
		end
	end
end
  