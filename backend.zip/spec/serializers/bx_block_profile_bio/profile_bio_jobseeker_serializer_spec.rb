require 'rails_helper'

RSpec.describe BxBlockProfileBio::ProfileBioJobseekerSerializer do
	let(:profile_bio) { FactoryBot.create(:profile_bio) }

	subject { described_class.new(profile_bio) }

	describe '#attributes' do
		it 'includes the expected attributes' do
			expected_attributes = [
				:account_id, :height, :weight, :height_type, :weight_type, :interested_in, :seamen_book_number, :salary_range_usd,
				:open_for, :linkedin_url, :covid_19_certificate, :selfie_picture, :health_record, :passport_picture, :video_cv,
				:training_and_certifications, :stcw, :resume, :total_work_experience, :available?, :unavailable_from, :unavailable_till, :account
			]
			response_array = JSON.parse(subject.to_json)["data"]["attributes"].keys
			expected_attributes.each do |attr|
				expect(response_array.compact).to include(attr&.to_s)
			end
		end
	end
end
  