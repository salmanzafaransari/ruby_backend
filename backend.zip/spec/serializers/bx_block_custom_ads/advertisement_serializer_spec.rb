require 'rails_helper'

RSpec.describe BxBlockCustomAds::AdvertisementSerializer do
  let(:recruiter) { FactoryBot.create(:account, account_role: "Recruiter") }
  let(:joblisting) { FactoryBot.create(:joblisting, account_id: recruiter.id) }
  let(:advertisement) { FactoryBot.create(:advertisement, account_id: recruiter.id, joblisting_id: joblisting.id) }

	subject { described_class.new(advertisement) }

	describe '#attributes' do
		it 'includes the expected attributes' do
			expected_attributes = [
        :plan_id, :status, :start_at,
      :expire_at, :ads_count, :jobs_count, :clicked_count, :views, :month_wise_clicked_counts, :month_wise_viewed_counts, :banner]
			response_array = JSON.parse(subject.to_json)["data"]["attributes"].keys
			expected_attributes.each do |attr|
				expect(response_array.compact).to include(attr&.to_s)
			end
		end
	end
end