require 'rails_helper'

RSpec.describe BxBlockCustomAds::AdsFrequencySerializer do
	let(:recruiter) { FactoryBot.create(:account, account_role: "Recruiter") }
	let(:ads_frequency) { FactoryBot.create(:ads_frequency) }

	subject { described_class.new(ads_frequency, params: {user: recruiter}) }

	describe '#attributes' do
		it 'includes the expected attributes' do
			expected_attributes = [:name, :rank, :selected]
			response_array = JSON.parse(subject.to_json)["data"]["attributes"].keys
			expected_attributes.each do |attr|
				expect(response_array.compact).to include(attr&.to_s)
			end
		end
	end
end