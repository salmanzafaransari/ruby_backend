require 'rails_helper'

RSpec.describe BxBlockOrderManagement::OrderSerializer, type: :serializer do
  let(:order) { FactoryBot.create(:order) } 

  subject { described_class.new(order).as_json }

  it 'serializes the order attributes' do
    expect(subject['data']['attributes'].keys.map(&:to_sym)).to contain_exactly(
	  :id, :order_number, :amount, :account_id, :coupon_code_id, :sub_total, :total,
	  :status, :applied_discount, :cancellation_reason, :order_date, :placed_at, :confirmed_at,
	  :delivered_at, :cancelled_at, :refunded_at, :source, :payment_failed_at, :payment_pending_at,
	  :tax_charges, :is_error, :total_tax, :created_at, :updated_at, :account, :order_transaction
	)

    expect(subject['data']['id'].to_i).to eq(order.id)
    expect(subject['data']['attributes']['order_number']).to eq(order.order_number)
    expect(subject['data']['attributes']['amount']).to eq(order.amount)
  end

  it 'includes account details' do
    expect(subject['data']['attributes']['account']).to be_present
    expect(subject['data']['attributes']['account']['id'].to_i).to eq(order.account.id)
  end

  it 'includes order transaction details' do
    expect(subject[:order_transaction]).to eq(order.order_transaction)
  end
end
