require 'rails_helper'

RSpec.describe BxBlockJoblisting::JoblistingSerializer, type: :serializer do
	before(:each) do
		@data = serialized_data[:data][:attributes]
	end
	describe 'serialization' do
		let!(:account) do
			account = FactoryBot.create(:account, account_role: 'Recruiter')
			account.save(validate: false)
			account
		end
		let(:joblisting) { FactoryBot.create(:joblisting, account_id: account.id) }
		let(:serialization_options) do
			{
				params:  {
					user: account, 
					action_name: "create"
						}
			}
		end
		let(:serialized_data) { described_class.new(joblisting, serialization_options).serializable_hash }

		it 'serializes the joblisting attributes correctly' do
			expect(@data[:job_title]).to eq(joblisting.job_title)
			expect(@data[:position_location]).to eq(joblisting.position_location)
			expect(@data[:salary_range]).to eq(joblisting.salary_range)
		end

		it 'returns required_certifications without empty values' do
			expect(@data[:required_certifications]).to eq(joblisting.required_certifications&.compact&.reject(&:empty?))
		end

		it 'returns positions without empty values' do
			expect(@data[:positions]).to eq(joblisting.positions&.compact&.reject(&:empty?))
		end

		it 'returns categories without empty values' do
			expect(@data[:categories]).to include({:name=> joblisting.categories.first.name, :sub_categories=>[]})
		end
	end
end
  