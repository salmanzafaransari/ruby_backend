require 'rails_helper'

RSpec.describe BxBlockJoblisting::UserJoblistingSerializer, type: :serializer do
  let(:account) { FactoryBot.create(:account, account_role: "Jobseeker") }
  let(:joblisting) { FactoryBot.create(:joblisting) }
  let(:user_joblisting) { FactoryBot.create(:user_joblisting, joblisting_id: joblisting.id, account_id: account.id) }
  let(:serialized_data) { described_class.new(user_joblisting).serializable_hash }
  before do
		@data = serialized_data[:data][:attributes]
	end

  describe 'serialization' do
    it 'serializes the joblisting attributes correctly' do
			expect(@data[:status]).to eq(user_joblisting.status)
			expect(@data[:joblisting]).to eq(user_joblisting.joblisting)
			expect(@data[:account]).to eq(user_joblisting.account)
		end
  end
end
