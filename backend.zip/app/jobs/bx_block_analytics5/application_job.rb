module BxBlockAnalytics5
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
