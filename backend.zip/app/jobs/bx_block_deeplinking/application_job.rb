module BxBlockDeeplinking
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
