module BxBlockElasticsearch2
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
