module BxBlockCreditdebitcardpayments
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
