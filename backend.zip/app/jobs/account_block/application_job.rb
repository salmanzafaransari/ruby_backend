module AccountBlock
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
