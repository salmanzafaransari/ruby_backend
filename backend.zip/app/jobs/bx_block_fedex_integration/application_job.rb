module BxBlockFedexIntegration
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
