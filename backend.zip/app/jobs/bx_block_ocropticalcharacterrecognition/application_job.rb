module BxBlockOcropticalcharacterrecognition
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
