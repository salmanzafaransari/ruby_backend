module BxBlockDocumentstorage
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
