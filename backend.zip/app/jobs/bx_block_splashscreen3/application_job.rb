module BxBlockSplashscreen3
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
