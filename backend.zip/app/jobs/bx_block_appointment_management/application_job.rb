module BxBlockAppointmentManagement
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
