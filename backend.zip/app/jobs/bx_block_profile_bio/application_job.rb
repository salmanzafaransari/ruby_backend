# frozen_string_literal: true

module BxBlockProfileBio
  class ApplicationJob < ActiveJob::Base
  end
end
