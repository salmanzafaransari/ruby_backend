module BxBlockEmailNotifications
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
