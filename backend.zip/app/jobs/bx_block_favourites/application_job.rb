module BxBlockFavourites
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
