module BxBlockLocation
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
