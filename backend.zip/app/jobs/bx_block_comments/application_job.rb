# frozen_string_literal: true

module BxBlockComments
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
