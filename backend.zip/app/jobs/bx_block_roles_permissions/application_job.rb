module BxBlockRolesPermissions
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
