module BxBlockJoblisting
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
