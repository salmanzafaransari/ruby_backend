module BxBlockCustomUserSubs
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
