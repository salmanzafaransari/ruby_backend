module BxBlockCors
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
