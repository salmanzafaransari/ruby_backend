module BxBlockCustomAds
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
