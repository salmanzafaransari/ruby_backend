module BxBlockSorting
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
