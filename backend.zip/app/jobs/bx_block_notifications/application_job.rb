module BxBlockNotifications
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
