module BxBlockHelpCentre
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
