module BxBlockAccountGroups
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
