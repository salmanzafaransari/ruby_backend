# frozen_string_literal: true

module BxBlockOrderManagement
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
