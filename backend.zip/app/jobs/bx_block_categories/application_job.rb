module BxBlockCategories
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
