module BxBlockCustomUserSubs
	module UserSubscriptionModule
		extend ActiveSupport::Concern

		def assign_subscription_to_user(current_user, subs_id)
			@user  = current_user
	      	subscription = BxBlockCustomUserSubs::Subscription.find(subs_id)
	        user_subscription = @user.user_subscriptions.build(account_id: current_user.id)
	        user_subscription.subscription_id = subs_id
	        user_subscription.expiry_date = Date.today + subscription&.valid_for.months
	        user_subscription.save!
	        BxBlockPushNotifications::PushNotification.create(
	          notify_type: "Subscribed a Plan",
	          remarks: "You have successfully subscribed to a new subscription plan",
	          redirection_url: Rails.application.routes.url_helpers.subscription_url(subscription, host: request.base_url),
	          push_notificable_type: "AccountBlock::Account", push_notificable_id: @user.id
	        ) unless @user.notify == false
		end

		def change_plan(current_user, subscription_id, plan_type)
	      subs = plan_type == 'signup' ? current_user.subscriptions&.signup_subscription&.first : current_user.subscriptions&.advertisement_subscription&.first
	      @user_subscription = UserSubscription.find_by(subscription_id: subs&.id, account_id: current_user.id)
	      @user_subscription.subscription_id = params[:subscription_id].to_i
	      @user_subscription.save!
	      @subscription = @user_subscription.subscription
	      update_expiry_date(@user_subscription, @subscription)
	      BxBlockPushNotifications::PushNotification.create(
	          notify_type: "Changed Subscription Plan",
	          remarks: "You have successfully updated your subscription plan",
	          redirection_url: Rails.application.routes.url_helpers.subscription_url(@subscription, host: request.base_url),
	          push_notificable_type: "AccountBlock::Account", push_notificable_id: current_user.id
	        ) unless current_user.notify == false
	    end

	    def update_expiry_date(user_subscription, subscription)
	      return unless user_subscription.present?
	      user_subscription.expiry_date = Date.today + subscription.valid_for.months
	      user_subscription.save!
	    end

		def unassign_subscribed_plan(current_user, plan_type)
			subs = plan_type == 'signup' ? current_user.subscriptions&.signup_subscription&.first : current_user.subscriptions&.advertisement_subscription&.first
			return unless subs.present?
			subscribed_plan = current_user.user_subscriptions.where(account_id: current_user.id).where(subscription_id: subs&.id)
			subscribed_plan&.first.destroy if subscribed_plan.present?
		end
	end
end