module BxBlockProfileBio
    module CvParamsModule
        extend ActiveSupport::Concern
      
        def cv_params
            params.require(:data).permit(
              attributes: [:bio, :first_name, :middle_name, :last_name, :rank, :availability_date, :email,
                :full_phone_number, :date_of_birth, :place_of_birth, :nationality, :city,
                :nearest_intl_airport, :height, :weight, :blood_group, :gender, :boiler_suit_size,
                :eyes_color, :hair_color, :linkedin_url, :account_id],
              passport_and_visa_detail_attributes: [:id, :sid, :passport_number, :us_visa, :expiry_date, :_destroy],
              seamen_book_numbers_attributes: [:id, :seamen_book_number, :place_of_issue, :issue_date, :expiry_date, :_destroy],
              professional_acedemic_qualifications_attributes: [:id, :course, :institution, :qualification, :grade, :start_date, :end_date, :_destroy],
              licence_certificates_of_competencies_attributes: [:id, :issue_authorithy, :grade, :number, :issue_date, :expiry_date, :revalidate_date, :issue_country, :_destroy],
              stcw_value_added_courses_attributes: [:id, :stcw_course, :certificate_number, :issue_date, :expiry_date, :issuing_body, :_destroy],
              work_experiences_attributes: [:id, :company, :vessel_name, :vessel_type, :vessel_dwt, :vessel_imo, :vessel_position, :start_date, :end_date, :_destroy])
        end
    end
end