module BxBlockProfile
    module PdfFormatModule
        extend ActiveSupport::Concern

        def info_format(data)
            info_data = [
          [{content: "First Name : #{data[:first_name]}", colspan: 2}, {content: "Middle Name : #{data[:middle_name]}", colspan: 2}, {content: "Last Name : #{ data[:last_name] }", colspan: 2}],
          [{ content: "Current Position/Rank: #{data[:rank]}", colspan: 3}, { content: "Date of Availability: #{data[:availability_date]}", colspan: 3}],
          [{ content: "Email: #{data[:email]}", colspan: 3}, { content: "Mobile Phone: #{data[:full_phone_number]}", colspan: 3}],
          [{content: "Date of Birth : #{data[:date_of_birth]}", colspan: 2}, {content: "Place of Birth : #{data[:place_of_birth]}", colspan: 2},
          {content: "Nationality : #{data[:nationality]}", colspan: 2}],
          [{ content: "Current Location (City): #{data[:city]}", colspan: 3},
          { content: "Nearest Int.Airport: #{data[:nearest_intl_airport]}", colspan: 3}]
        ]
        info_data
        end

        def passport_format(data)
            pass_data = [
          [{ content: "SID: #{data[:passport_and_visa_detail][:sid]}", colspan: 8}],
          [{ content: "Passport#: #{data[:passport_and_visa_detail][:passport_number]}", colspan: 4},
          { content: "Expiry: #{data[:passport_and_visa_detail][:expiry_date]}", colspan: 4}],
          [{ content: "US Visa (C1/D): #{data[:passport_and_visa_detail][:us_visa]}", colspan: 8}]
        ]
        pass_data
        end

        def cdc_format(data)
            seamen_data = [["CDC", "Number", "Place of Issue", "Date of Issue", "Date of Expiry"]]
            seamen_data += data[:seamen_book_numbers].map do |sbn|
            ["National", sbn[:seamen_book_number], sbn[:place_of_issue], sbn[:issue_date],
            sbn[:expiry_date]]
            end
            seamen_data
        end

        def academic_format(data)
            acad_data = [["Course" ,"Institution", "Qualification", "Grade", "From", "To"]]
            acad_data += data[:professional_acedemic_qualifications].map do |acad|
            [acad[:course], acad[:institution], acad[:qualification], acad[:grade],
            acad[:start_date], acad[:end_date]]
            end
            acad_data
        end

        def license_format(data)
            license_data = [["Issuing Authority", "Grade", "Number", "Date of Issue", "Date of Expiry",
            "Date Re-validated", "Country of Issue"]]
            license_data += data[:licence_certificates_of_competencies].map do |license|
            [license[:issue_authorithy], license[:grade], license[:number], license[:issue_date],
            license[:expiry_date], license[:revalidate_date], license[:issue_country]]
            end
            license_data
        end

        def stcw_format(data)
            stcw_data = [["STCW COURSE", "CERTIFICATE NO", "DATE OF ISSUE", "DATE OF EXPIRY", "ISSUING BODY"]]
            stcw_data += data[:stcw_value_added_courses].map do |stcw|
            [stcw[:stcw_course], stcw[:certificate_number], stcw[:issue_date], stcw[:expiry_date],
            stcw[:issuing_body]]
            end
            stcw_data
        end

        def work_ex_format(data)
            work_data = [["COMPANY",{ content: 'VESSEL', colspan: 5, align: :center }, { content: "SERVICE PERIOD", colspan: 2, align: :center}],[" ","Name","Type","DWT","IMO","Position","From","To"]]
            work_data += data[:work_experiences].map do |work|
            [work[:company], work[:vessel_name], work[:vessel_type], work[:vessel_dwt], work[:vessel_imo],
            work[:vessel_position], work[:start_date], work[:end_date]]
            end
            work_data
        end

        def personal_format(data)
            personal_data = [
            [{ content: "Height: #{data[:height]}", colspan: 3}, { content: "Weight: #{data[:weight]}", colspan: 3},
            { content: "Blood Group: #{data[:blood_group]}", colspan: 3}],
            [{ content: "Sex: #{data[:gender] ==0 ? 'Male' : 'Female'}", colspan: 3}, { content: "Boiler Suit Size: #{data[:boiler_suit_size]}", colspan: 3},
            { content: " ", colspan: 3}],
            [{ content: "Color of Eyes: #{data[:eyes_color]}", colspan: 3}, { content: "Color of Hair: #{data[:hair_color]}", colspan: 3},
            { content: " ", colspan: 3}]]
            personal_data
        end
    end
end