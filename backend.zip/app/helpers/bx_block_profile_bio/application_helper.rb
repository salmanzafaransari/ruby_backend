# frozen_string_literal: true

module BxBlockProfileBio
  # Application helper
  module ApplicationHelper
  end
end
