//= require active_admin/base
//= require activeadmin/quill_editor/quill
//= require activeadmin/quill_editor_input
(function($) {
	$(document).ready(function() {
	  $("#get_lower").insertAfter(".index_table");
	});
  })(jQuery);
  
  $(document).ready(function() {
	$('.category-dropdown').change(function() {
	  const categoryDropdown = $(this);
	  const subCategoryDropdown = categoryDropdown.closest('.fields').find('.sub-category-dropdown');
  
	  const categoryId = categoryDropdown.val();
	  if (categoryId !== '') {
		$.ajax({
		  url: '/categories/' + categoryId + '/get_sub_categories',
		  method: 'GET',
		  data: { category_id: categoryId },
		  success: function(response) {
			subCategoryDropdown.empty();
			$.each(response.subcategories, function(index, subcategory) {
			  subCategoryDropdown.append($('<option></option>').attr('value', subcategory.id).text(subcategory.name));
			});
		  },
		  error: function() {
			console.log('Error occurred while fetching subcategories');
		  }
		});
	  } else {
		subCategoryDropdown.empty();
	  }
	});
  
	$('.category-dropdown').trigger('change');
  });

	$(document).ready(function() {
		const promotionTypeCheckbox = $('#subscription_promotion_type');
		const maxPromotionsField = $('#subscription_max_promotions');
		toggleMaxPromotionsField();

		promotionTypeCheckbox.on('change', toggleMaxPromotionsField);
		function toggleMaxPromotionsField() {
			if (promotionTypeCheckbox.prop('checked')) {
				maxPromotionsField.prop('disabled', false);
			} else {
				maxPromotionsField.prop('disabled', true);
			}
		}
	});

	$(document).ready(function() {
		const advertisementTypeCheckbox = $('#subscription_advertisement_type');
		const maxAdvertisementsField = $('#subscription_max_advertisements');
		const adsFrequencyIdDropdown = $('#subscription_ads_frequency_id')
		toggleMaxAdvertisementsField();

		advertisementTypeCheckbox.on('change', toggleMaxAdvertisementsField);
		function toggleMaxAdvertisementsField() {
			if (advertisementTypeCheckbox.prop('checked')) {
				maxAdvertisementsField.prop('disabled', false);
				adsFrequencyIdDropdown.prop('disabled', false);
			} else {
				adsFrequencyIdDropdown.prop('disabled', true);
				maxAdvertisementsField.prop('disabled', true);
			}
		}
	});

	document.addEventListener('DOMContentLoaded', function() {
	  setTimeout(function() {
	    $('.flashes').fadeOut('slow');
	  }, 2000);
	});