module AccountBlock
  class AccountCreatedMailer < ApplicationMailer

    def account_created_email(user)
      @user = user
      mail(
        to: @user.email,
        subject: "Welcome to iSail - Your Maritime Journey Begins!"
      )
    end
  end
end