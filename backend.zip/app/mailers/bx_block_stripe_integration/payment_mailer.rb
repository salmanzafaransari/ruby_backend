module BxBlockStripeIntegration
  class PaymentMailer < ApplicationMailer

    def payment_received_email(user, order)
      @user = user
      @subscription = BxBlockCustomUserSubs::Subscription.find(order&.subscription_id)
      mail(
        to: @user.email,
        from: "hello@isail-marine.com",
        subject: "Payment Success"
      )
    end

    def payment_failed_email(user, order)
      @user = user
      @subscription = BxBlockCustomUserSubs::Subscription.find(order&.subscription_id)
      mail(
        to: @user.email,
        from: "hello@isail-marine.com",
        subject: "Payment Failed"
      )
    end
  end
end