module BxBlockProfileBio
	class WelcomeMailer < ApplicationMailer

		def welcome_email(user)
			@user = user
			mail(
				to: @user.email,
				subject: "Welcome to iSail - Your Maritime Career Awaits!"
			)
		end
	end
end