# frozen_string_literal: true

module BxBlockProfileBio
  class ApplicationMailer < BuilderBase::ApplicationMailer
    default from: 'hello@isail-marine.com'
    layout 'mailer'
  end
end
