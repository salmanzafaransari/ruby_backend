module BxBlockAdmin
    class SuperAdminMailer < ApplicationMailer
      def super_admin_email_changed
        @admin = params[:admin]
        mail(
          to: @admin.email,
          from: "hello@isail-marine.com",
          subject: "Account activation"
        ) do |format|
          format.html { render "super_admin_email_changed" }
        end
      end
    end
  end
  