module BuilderBase
  class ApplicationMailer < ::ApplicationMailer
    default from: 'hello@isail-marine.com'
    layout 'mailer'
  end
end
