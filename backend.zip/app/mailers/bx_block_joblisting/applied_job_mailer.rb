module BxBlockJoblisting
	class AppliedJobMailer < ApplicationMailer

		def job_status_mail(user, joblisting)
			@user = user
			@joblisting = joblisting
			mail(
				to: @user.email,
				from: 'hello@isail-marine.com',
				subject: "Application Progress Update for Your Recently Viewed Job"
			)
		end
	end
end