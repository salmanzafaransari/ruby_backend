module BxBlockJoblisting
  class JobStatusUpdateMailer < ApplicationMailer

    def application_status_change_email(user_joblisting)
      @user_joblisting = user_joblisting
      @user = user_joblisting.account
      @joblisting = user_joblisting.joblisting
      mail(
        to: @user.email,
        from: 'hello@isail-marine.com',
        subject: "Application Progress Update for #{@joblisting.job_title}"
      )
    end
  end
end