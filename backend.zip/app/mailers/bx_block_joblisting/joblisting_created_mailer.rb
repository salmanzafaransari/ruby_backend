module BxBlockJoblisting
  class JoblistingCreatedMailer < ApplicationMailer

    def joblisting_created_email(user)
      @user = user
      mail(
        to: @user.email,
        from: 'hello@isail-marine.com',
        subject: 'New Job Matches Available - Explore Now!'
      )
    end
  end
end