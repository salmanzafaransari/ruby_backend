module BxBlockCustomUserSubs
  class Subscription < ApplicationRecord
    has_many :user_subscriptions,
             class_name: 'BxBlockCustomUserSubs::UserSubscription'
    has_many :accounts, through: :user_subscriptions, class_name: 'AccountBlock::Account'
    validates :name, presence: true
    # validates :description, presence: true
    validates :price, presence: true
    validates :valid_for, :currency, presence: true
    validates :promotion_type, inclusion: { in: [true, false] }
    validates :max_promotions, presence: true, if: :promotion_type?
    validates :advertisement_type, inclusion: { in: [true, false] }
    validates :max_advertisements, :ads_frequency_id, presence: true, if: :advertisement_type?
    has_one_attached :image

    validate do
      valid_number_of_benefit?
    end

    scope :signup_subscription, -> {where.not(promotion_type: true).where.not(advertisement_type: true).where(active: true).includes(:image_attachment)}
    scope :advertisement_subscription, -> {where(advertisement_type: true).where(active: true).includes(:image_attachment)}
    scope :recruiter_signup_subscription, -> {where.not(promotion_type: true).where.not(advertisement_type: true).where(active: true).where(for_recruiter: true).includes(:image_attachment)}
    scope :jobseeker_signup_subscription, -> {where.not(promotion_type: true).where.not(advertisement_type: true).where(active: true).where(for_recruiter: false).includes(:image_attachment)}


    private

    def valid_number_of_benefit?
      descriptions = self.description
      if descriptions == {} || JSON.parse(descriptions).length < 1
        errors.add(:subscription, "At least One Benefit Should be There For Any Plan")
      end
      rescue Exception => e
       errors.add(:description, "Please provide correct format: {\"1\": \"some benefit\", \"2\": \"some benefit 2\"}")  
    end

    def promotion_type?
      promotion_type == true
    end

    def advertisement_type?
      advertisement_type == true
    end
  end
end
