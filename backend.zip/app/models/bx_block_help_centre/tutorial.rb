module BxBlockHelpCentre
  class Tutorial < BxBlockHelpCentre::ApplicationRecord
    self.table_name = :tutorials

    mount_uploader :video, VideoUploader

    validates :video_title, presence: true
  end
end
