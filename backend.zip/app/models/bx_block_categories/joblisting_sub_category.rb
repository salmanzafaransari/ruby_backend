module BxBlockCategories
    class JoblistingSubCategory < ApplicationRecord
      self.table_name = :joblisting_sub_categories
  
      belongs_to :joblisting_category, class_name: "BxBlockCategories::JoblistingCategory"
      belongs_to :sub_category, class_name: "BxBlockCategories::SubCategory"
    #   belongs_to :joblisting, class_name: "BxBlockJoblisting::Joblisting"
    end
end