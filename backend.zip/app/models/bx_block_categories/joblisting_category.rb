module BxBlockCategories
class JoblistingCategory < BxBlockCategories::ApplicationRecord
    self.table_name = :joblisting_categories

    belongs_to :category, class_name: "BxBlockCategories::Category"
    belongs_to :joblisting, class_name: "BxBlockJoblisting::Joblisting", inverse_of: :joblisting_categories
    has_many :joblisting_sub_categories, dependent: :delete_all
    has_many :sub_categories, through: :joblisting_sub_categories, class_name: "BxBlockCategories::SubCategory"

	validates :category, presence: true
end
end
