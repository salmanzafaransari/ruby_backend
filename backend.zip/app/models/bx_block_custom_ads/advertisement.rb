module BxBlockCustomAds
  class Advertisement < ApplicationRecord

    self.table_name = :advertisements
    belongs_to :account, class_name: 'AccountBlock::Account'
    belongs_to :joblisting, class_name: 'BxBlockJoblisting::Joblisting'
    # belongs_to :seller_account, class_name: "BxBlockCustomForm::SellerAccount"

    # enum status: ["pending", "approved", "rejected"]
    # enum advertisement_for: [:seller, :user]
    after_create do
      set_ads_count
      set_clicked_and_viewed_count_hashes
    end

    has_one_attached :banner

    # before_create :add_status

    # after_create :notify_admin

    # def add_status
    #   self.status = 0
    # end

    # def notify_admin
      # AdvertisementMailer.notify_admin(advertisement:self).deliver
    # end

    def clicked_count_verify
      count = self.try(:clicked_count)
      year = (Date.today).strftime("%Y")
      month = (Date.today).strftime("%B")
      set_clicked_and_viewed_count_hashes if self.month_wise_clicked_counts.keys.exclude?(year)
      self.month_wise_clicked_counts[year][month] += 1
      self.update_columns(clicked_count: count+1, month_wise_clicked_counts: self.month_wise_clicked_counts)
    end

    def viewed_count_verify
      count = self.try(:views)
      year = (Date.today).strftime("%Y")
      month = (Date.today).strftime("%B")
      set_clicked_and_viewed_count_hashes if self.month_wise_viewed_counts.keys.exclude?(year)
      self.month_wise_viewed_counts[year][month] += 1
      self.update_columns(views: count+1, month_wise_viewed_counts: self.month_wise_viewed_counts)
    end

    def set_clicked_and_viewed_count_hashes
      year = (Date.today).strftime("%Y")
      self.month_wise_clicked_counts ||= {}
      self.month_wise_clicked_counts[year] ||= {}
      self.month_wise_viewed_counts ||= {}
      self.month_wise_viewed_counts[year] ||= {}
      Date::MONTHNAMES.compact.each do |month_name|
        self.month_wise_clicked_counts[year][month_name] = 0
        self.month_wise_viewed_counts[year][month_name] = 0
      end
      self.save!
    end

    def set_ads_count
      current_user = self.account
      plan = current_user.subscriptions.advertisement_subscription&.first
      ads_frequency = BxBlockCustomAds::AdsFrequency.find_by_id(plan&.ads_frequency_id)
      ads = current_user.advertisements.where.not(id: self.id)
      if ads.present?
        ad = ads.where.not(ads_count: nil)&.first
        ad_count = ad.try(:ads_count)
        self.update_columns(ads_count: ad_count)
      elsif plan.present? && ads_frequency.present?
        self.update_columns(ads_count: ads_frequency.rank)
      else
        self.update_columns(ads_count: 1)
      end
      self
    end
  end
end
