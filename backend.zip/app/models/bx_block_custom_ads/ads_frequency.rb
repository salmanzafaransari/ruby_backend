module BxBlockCustomAds
  class AdsFrequency < ApplicationRecord
    self.table_name = :ads_frequencies

    before_destroy do |resource|
	    subs = BxBlockCustomUserSubs::Subscription.where(ads_frequency_id: resource[:id]).includes(:user_subscriptions)
		if subs.any? { |sub| sub.user_subscriptions.present? || sub.present?}
		  resource.errors.add(:ads_frequency, 'This object cannot be deleted. It is used in one existing subscription.')
		  throw(:abort)
		end
  	end
  end
end
