class AdminUser < ApplicationRecord
    # Include default devise modules. Others available are:
    # :confirmable, :lockable, :timeoutable, :trackable and :omniauthable
    devise :database_authenticatable,
           :recoverable, :rememberable, :validatable
    enum role: %i[admin super_admin]
    before_save :send_verification_mail
    before_validation :parse_full_phone_number

		validate :valid_phone_number

    def send_verification_mail
			if email_changed?
				BxBlockAdmin::SuperAdminMailer.with(admin: self)
					.super_admin_email_changed.deliver
			end
    end

    private

    def parse_full_phone_number
      phone = Phonelib.parse(full_phone_number)
      self.full_phone_number = phone.sanitized
      self.country_code = phone.country_code
      self.phone_number = phone.raw_national
    end

    def valid_phone_number
      unless (!full_phone_number.present? || Phonelib.valid?(full_phone_number))
        errors.add(:full_phone_number, "Invalid or Unrecognized Phone Number")
      end
    end
end
