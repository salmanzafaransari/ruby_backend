# require 'mini_magick'
# require 'rtesseract'

module BxBlockDocumentstorage
    class PrivacyPolicy < ApplicationRecord
        self.table_name = :privacy_policies
        TITLE = ['Terms and Conditions', 'Privacy Policy']
        validates :title , presence: true
        mount_uploader :file_for_description, PdfUploader

        def perform_ocr
            return unless file_for_description.present?
            temp_pdf = Tempfile.new(['file_for_description', '.pdf'])
            temp_pdf.binmode
            temp_pdf.write(file_for_description.read)
            temp_pdf.rewind
            # pdf_path  = file_for_description.path
            text = PDF::Reader.new(temp_pdf).pages.map(&:text).join("\n")
            update(description: text)
            temp_pdf.close
            temp_pdf.unlink
        end
        
    end
end
