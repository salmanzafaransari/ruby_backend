module AccountBlock
  class Account < AccountBlock::ApplicationRecord
    ActiveSupport.run_load_hooks(:account, self)
    self.table_name = :accounts

    include Wisper::Publisher
    NOT_EXIST = "account does not exist"
    # mount_uploader :personalise_cv, PdfUploader
    has_secure_password
    before_validation :parse_full_phone_number
    before_create :generate_api_key
    has_many :advertisements, class_name: 'BxBlockCustomAds::Advertisement', dependent: :destroy, inverse_of: :account
    has_one :cv, class_name: 'BxBlockProfile::Cv', dependent: :destroy
    has_one :profile_data, class_name: 'BxBlockProfileBio::ProfileBio', dependent: :destroy
    has_one :blacklist_user, class_name: 'AccountBlock::BlackListUser', dependent: :destroy
    has_many :user_subscriptions, class_name: 'BxBlockCustomUserSubs::UserSubscription', dependent: :destroy
    has_many :subscriptions, through: :user_subscriptions, class_name: 'BxBlockCustomUserSubs::Subscription'
    has_many :user_joblistings, class_name: 'BxBlockJoblisting::UserJoblisting', dependent: :destroy
    has_many :joblistings, through: :user_joblistings, class_name: 'BxBlockJoblisting::Joblisting'
    has_many :push_notifications, class_name: 'BxBlockPushNotifications::PushNotification', dependent: :destroy
    has_many :orders, class_name: 'BxBlockOrderManagement::Order', dependent: :destroy
    before_save :strip_email
    after_save :set_black_listed_user, :update_jobs_of_recruiter
    before_destroy :destroy_joblisting

    # PASSWORD_FORMAT = /\A
    #   (?=.{8,})          # Must contain 8 or more characters
    #   (?=.*\d)           # Must contain a digit
    #   (?=.*[a-z])        # Must contain a lower case character
    #   (?=.*[A-Z])        # Must contain an upper case character
    #   (?=.*[[:^alnum:]]) # Must contain a symbol
    # /x

    accepts_nested_attributes_for :profile_data
    validates :first_name, :last_name, presence: true, on: :update
    validate :valid_phone_number, on: :update
    validates :password, presence: true, length: { minimum: 8 }, format: { with:  /\A(?=.{8,})(?=.*\d)(?=.*[a-z])(?=.*[A-Z])/x, message: "Password should be a minimum of 8 characters long, contain both uppercase and lowercase characters, at least one digit"}, on: :create
    validates :email, presence: true
    validates :account_role, presence: true, on: :create
    enum account_role: %i[Jobseeker Recruiter]

    enum status: %i[regular suspended deleted deactivate]
    enum gender: %i[Male Female]#, _prefix: :gender

    scope :active, -> { where(activated: true) }
    scope :recruiters, -> { where(account_role: "Recruiter") }
    scope :jobseekers, -> { where(account_role: "Jobseeker") }
    scope :existing_accounts, -> { where(status: ["regular", "suspended"]) }


    def create_general_cv
      @cv = BxBlockProfile::Cv.create(bio: 'Enter your Bio Here', first_name: self.first_name, last_name: self.last_name, full_phone_number: self.full_phone_number, account_id: self.id, email: self.email)
      create_other_attributes if @cv.present?
    end

    private

    def parse_full_phone_number
      @phone = Phonelib.parse(full_phone_number)
      self.full_phone_number = @phone.original.include?('+') ? @phone.original : ("+" + "#{@phone.original}").strip if @phone.present?
      self.country_code = @phone.country_code
      self.phone_number = @phone.raw_national
    end

    def valid_phone_number
      unless Phonelib.valid?(full_phone_number)
        errors.add(:full_phone_number, "Invalid or Unrecognized Phone Number")
      end
    end

    def strip_email
      @email = email&.strip.gsub(/\s+/, '')
      self.email = @email
    end

    def create_other_attributes
      BxBlockProfile::SeamenBookNumber.create(seamen_book_number: '', place_of_issue: '', issue_date: '', expiry_date: '', cv_id: @cv.id)
      BxBlockProfile::PassportAndVisaDetail.create(sid: '', passport_number: '', expiry_date: '', us_visa: '', cv_id: @cv.id)
      BxBlockProfile::ProfessionalAcedemicQualification.create(course: '', institution: '', qualification: '', grade: '', start_date: '', end_date: '', cv_id: @cv.id)
      BxBlockProfile::LicenceCertificatesOfCompetency.create(issue_authorithy: '', grade: '', number: '', issue_date: '', expiry_date: '', revalidate_date: '', issue_country: '', cv_id: @cv.id)
      BxBlockProfile::StcwValueAddedCourse.create(stcw_course: '', certificate_number: '', issue_date: '', expiry_date: '', issuing_body: '', cv_id: @cv.id)
      BxBlockProfile::WorkExperience.create(company: '', vessel_name: '', vessel_type: '', vessel_dwt: '', vessel_imo: '', vessel_position: '', start_date: '', end_date: '', cv_id: @cv.id)
    end

    def generate_api_key
      loop do
        @token = SecureRandom.base64.tr("+/=", "Qrt")
        break @token unless Account.exists?(unique_auth_id: @token)
      end
      self.unique_auth_id = @token
    end

    def set_black_listed_user
      if is_blacklisted_previously_changed?
        if is_blacklisted
          AccountBlock::BlackListUser.create(account_id: id)
        else
          blacklist_user.destroy
        end
      end
    end

    def destroy_joblisting
      unless self.account_role == 'Jobseeker'
        jobs = BxBlockJoblisting::Joblisting.where(account_id: self.id)
        jobs.presence ? jobs.destroy_all : true
      else
        true
      end
    end

    def update_jobs_of_recruiter
      if self.account_role == 'Recruiter'
        joblistings = BxBlockJoblisting::Joblisting.where(account_id: self.id)
        joblistings.presence ? joblistings.update_all(recruiter_name: "#{self.first_name} #{self.last_name}") : true
      else
        true
      end
    end
  end
end
