module BxBlockJoblisting
	class Joblisting < ApplicationRecord
		self.table_name = :joblistings
		# POSITION_LOCATION = ["abc", "123", "xyz"]
		# POSITIONS = ["ship", "shore"]
		POSITIONS = JoblistingService.position
		# DURATION_OF_POSITION = ["Contractual", "Temporary", "Permanent"]
		OPEN_POSITION = JoblistingService.open_position
		JOB_TITLE = JoblistingService.all_job_title
		VESSEL_TYPE = JoblistingService.vessel_types
		LOCATION = JoblistingService.all_countries
		CURRENCIES = JoblistingService.all_currency
		PLACEHOLDER = "Enter only number"
		# REQUIRED_CERTIFICATIONS = ["abc", "123", "xyz"]
		MINIMUM_COUNT = 1
		# attr_accessible :joblisting_att:joblisting_categories_attributes

		mount_uploader :joblisting_icon, ImageUploader

		# validates :job_title, :position_location, :salary_range, :duration_of_position,
  #           :months_on_board, :vessel_type, :location, :starting_condition,
  #           :job_description, :responsibilities, presence: true

		validates :job_title, :salary_range,
			:vessel_type, :location, :starting_condition,
            :job_description, :responsibilities, :currency, :positions, presence: true
		
		scope :search_by_field, -> (query) { joins(joblisting_categories: :category)
				.where('job_title ILIKE :query OR vessel_type ILIKE :query OR categories.name ILIKE :query OR TO_CHAR(joblistings.created_at, \'YYYY-MM-DD\') ILIKE :date_query', query: "%#{query}%", date_query: valid_date?(query) ? "%#{query.to_date.strftime('%Y-%m-%d')}%" : nil)}

		# belongs_to :account, -> { recruiters }, class_name: "AccountBlock::Account"

		has_one :advertisement, class_name: "BxBlockCustomAds::Advertisement", dependent: :destroy, inverse_of: :joblisting
		has_many :joblisting_categories, class_name: "BxBlockCategories::JoblistingCategory", dependent: :delete_all, inverse_of: :joblisting
		# has_many :joblisting_sub_categories, class_name: "BxBlockCategories::JoblistingSubCategory", dependent: :delete_all
		# has_many :sub_categories, through: :joblisting_sub_categories, class_name: "BxBlockCategories::SubCategory"
		has_many :categories, through: :joblisting_categories, class_name: "BxBlockCategories::Category"
		has_many :user_joblistings, class_name: "BxBlockJoblisting::UserJoblisting", dependent: :delete_all
		has_many :accounts, through: :user_joblistings, class_name: "AccountBlock::Account"
		accepts_nested_attributes_for :joblisting_categories, allow_destroy: true

		after_create do
			check_duration_of_position
			send_job_creation_email
		end

		validate do
			valid_starting_condition_date
			check_joblisting_category_number if $admin_flag == true
		end

		def valid_joblisting_category?
			category_ids = self.joblisting_categories.pluck(:category_id)
			BxBlockCategories::Category.where(id: category_ids).present? ? true : false
		end

		def self.delete_joblisting_categories(joblisting)
			joblisting.joblisting_categories.destroy_all
		end

		private 

		def categories_count_valid?
			joblisting_categories.reject(&:marked_for_destruction?).count >= MINIMUM_COUNT
		end

		def check_joblisting_category_number
			unless categories_count_valid?
			errors.add(:joblisting_categories, "error")
			end
		end

		def self.valid_date?(date_string)
		  begin
			Date.parse(date_string)
			true
		  rescue ArgumentError, TypeError
			false
		  end
		end

		def valid_starting_condition_date
		  date_regex = /\A\d{2}\/\d{2}\/\d{4}\z/
		  unless (starting_condition =~ date_regex) && (Date.strptime(starting_condition, "%d/%m/%Y") >= Date.today)
		    errors.add(:starting_condition, "Invalid Starting Condition. Please enter future date in DD/MM/YYYY format.")
		  end
		end

		def send_job_creation_email
			@users = AccountBlock::Account.where(account_role: "Jobseeker")
			@users.map { |user| JoblistingCreatedMailer.joblisting_created_email(user).deliver_later }
		end

		def check_duration_of_position
			self.duration_of_position.present? ? true : self.update_column(:duration_of_position, "NA")
		end
	end
end
