module BxBlockJoblisting
  class UserJoblisting < ApplicationRecord
		self.table_name = :user_joblistings

		belongs_to :account, class_name: "AccountBlock::Account", inverse_of: :user_joblistings
    	belongs_to :joblisting, class_name: "BxBlockJoblisting::Joblisting"

		mount_uploader :resume, PdfUploader
		mount_uploader :video_cv, VideoUploader
		mount_uploader :stcw, PdfUploader
		mount_uploaders :training_and_certifications, PdfUploader


		enum status: %i(applied viewed shortlisted rejected in_progress)

		validates :full_name, :email, :resume, presence: true
		validate :valid_phone_number

		private

	    def valid_phone_number
				phone = Phonelib.parse(full_phone_number)
	      self.full_phone_number = phone.sanitized
	      unless Phonelib.valid?(full_phone_number)
	        errors.add(:full_phone_number, "Invalid or Unrecognized Phone Number")
	      end
	    end
	end
end
