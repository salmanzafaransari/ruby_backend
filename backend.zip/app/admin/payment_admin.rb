# module PaymentAdmin
# 	class Load
# 		@@loaded_from_gem = false
# 		def self.is_loaded_from_gem
# 			@@loaded_from_gem
# 		end

# 		def self.loaded
# 			#empty
# 		end

# 		def self.link_tag
#       #empty
# 		end

# 		# Check if this file is loaded from gem directory or not
# 		# The gem directory looks like
# 		# /template-app/.gems/gems/bx_block_custom_user_subs-0.0.7/app/admin/payment_admin.rb
# 		# if it has block's name in it then it's a gem
# 		@@loaded_from_gem = Load.method(:loaded).source_location.first.include?("bx_block_")
# 	end
# end
  
# unless PaymentAdmin::Load.is_loaded_from_gem
# 	ActiveAdmin.register BxBlockPaymentAdmin::PaymentAdmin, as: "PaymentAdmin" do
# 		RESTRICTED_ACTIONS = ["edit", "new", "destroy"]
#     actions :all

# 		controller do
# 			before_action :check_super_admin_user

# 			def action_methods
#         super - RESTRICTED_ACTIONS
#       end

# 			def check_super_admin_user
# 				user = current_admin_user || resource
# 				unless user.role && user.role == "super_admin"
#           flash[:error] = "You are not authorized to perform this action."
# 					redirect_to :admin_dashboard
#         end
# 			end
# 		end
		
# 		index do 
# 			selectable_column
# 			id_column
# 			column :transaction_id
# 			column "Account" do |object|
# 				object.account.full_name || "#{object.account.first_name} #{object.account.last_name}"
# 			end
# 			column :payment_status
# 			column :payment_method
# 			column :user_amount
# 			column :post_creator_amount
# 			column :third_party_amount
# 			column :admin_amount
# 			actions
# 			div(id: 'get_lower') do
#         render partial: 'bx_block_admin/monthly_transaction_reports', locals:{context: self}
#       end
# 		end

# 		show do
# 			attributes_table do
# 				row :transaction_id
# 				row "Account" do |object|
# 					object.account.full_name || "#{object.account.first_name} #{object.account.last_name}"
# 				end
# 				row :payment_status
# 				row :payment_method
# 				row :user_amount
# 				row :post_creator_amount
# 				row :third_party_amount
# 				row :admin_amount
# 			end
# 		end
#   end
# end
