module Joblisting
	class Load
		@@loaded_from_gem = false
		def self.is_loaded_from_gem
			@@loaded_from_gem
		end

		def self.loaded
			#empty
		end

		def self.link_tag
			"Click For Resume"
		end
		# Check if this file is loaded from gem directory or not
		# The gem directory looks like
		# /template-app/.gems/gems/bx_block_custom_user_subs-0.0.7/app/admin/subscription.rb
		# if it has block's name in it then it's a gem
		@@loaded_from_gem = Load.method(:loaded).source_location.first.include?("bx_block_")
	end
end
  
unless Joblisting::Load.is_loaded_from_gem
	ActiveAdmin.register BxBlockJoblisting::Joblisting, as: "Joblisting" do
		actions :all
		permit_params :job_title, :position_location, :currency, :salary_range, :duration_of_position, :months_on_board, :months_off_board, :open_position, :vessel_type, :location, :starting_condition, :job_description, :joblisting_icon, :responsibilities, {positions: []}, required_certifications: [], joblisting_categories_attributes: [:id, :category_id, :_destroy]
		before_action :convert_certifications_params, :set_active_admin_flag, only: [:create, :update]
		before_action :set_highest_recruiter, only: [:index]
		after_action :remove_blank_data_from_attributes, only: [:create, :update]

		member_action :new_recruiter_assignment, method: :get do
			@joblisting = BxBlockJoblisting::Joblisting.find(params[:id])
			@recruiters = AccountBlock::Account.where(account_role: "Recruiter").where.not(first_name: nil).where.not(last_name: nil)
			render partial: 'admin/joblistings/new_recruiter_assignment', :layout => false
		end

		member_action :assign_recruiter, method: :patch do
			user_id = params[:bx_block_joblisting_joblisting][:account_id].to_i
			@joblisting = BxBlockJoblisting::Joblisting.find(params[:id])
			recruiter = AccountBlock::Account.find(user_id)
			@recruiter_name = "#{recruiter&.first_name} #{recruiter&.last_name}"
			@joblisting.update(account_id: user_id, recruiter_name: @recruiter_name)

			redirect_to admin_joblisting_path(@joblisting), notice: 'Recruiter assigned successfully!'
		end

		controller do
			# def scoped_collection
			#       end_of_association_chain.includes(joblisting_categories: [:category, :sub_categories])
			#     end

			def create
				super do |success, failure|
				  failure.html do
					flash[:error] = if resource.errors[:joblisting_categories].present?
					  "Atleast One Category Need To Be Present"
					else
					  "There are errors in the form. Please check the fields."
					end
					render :new
				  end
				end
			end
		  
			def update
				super do |success, failure|
				  failure.html do
					flash[:error] = if resource.errors[:joblisting_categories].present?
					  "Atleast One Category Need To Be Present"
					else
					  "There are errors in the form. Please check the fields."
					end
					render :edit
				  end
				end
			end

			def destroy
				if params[:id].present?
					@joblisting = BxBlockJoblisting::Joblisting.find(params[:id])
					BxBlockJoblisting::Joblisting.delete_joblisting_categories(@joblisting)
					@joblisting.destroy
					flash[:success] = "Joblisting deleted Succesfully"
					redirect_to action: :index
				end
			end

			private
			
			def set_active_admin_flag
				$admin_flag = true
			end

			def remove_blank_data_from_attributes
				unless resource.errors.any?
				position = resource.positions.reject(&:empty?)
				resource.update_columns(positions: position)
				end
			end

			def convert_certifications_params
      		# Parse the comma-separated values into an array before saving or updating the database
      		params[:bx_block_joblisting_joblisting][:positions] = params[:bx_block_joblisting_joblisting][:positions].split(',').map(&:strip)
    		end

    	def set_highest_recruiter
    		recruiter_id = BxBlockJoblisting::Joblisting.group(:account_id).count.max_by { |_, count| count }&.first
    		@max_recruiter = AccountBlock::Account.find_by_id(recruiter_id) unless recruiter_id.blank?
    	end
		end

		filter :job_title 
		filter :categories
		filter :location, as: :select, collection: BxBlockJoblisting::Joblisting::LOCATION
		filter :vessel_type, as: :select, collection: BxBlockJoblisting::Joblisting::VESSEL_TYPE
		filter :recruiter_name
		filter :created_at

		index do
			selectable_column
			id_column
			column :job_title
			column :location
			column :currency
			column :duration_of_position
			column :vessel_type
			column "Categories" do |object|
				object.categories.pluck(:name).reject(&:empty?)
			end
			column "Recruiter's Name" do |object|
				object&.recruiter_name
			end
			column :created_at
			column :updated_at
			actions defaults: true do |joblisting|
				link_to 'Assign Recruiter', new_recruiter_assignment_admin_joblisting_path(joblisting)
			end

			div(id: 'get_lower') do
        panel 'Recruiter with Highest Jobs' do
          render partial: 'highest_recuriter'
        end
      end
		end

		show do |joblisting|
			attributes_table do
				row :job_title
				row :positions do |joblisting|
					joblisting.positions&.reject(&:empty?)
				end
				row :currency
				row :salary_range
				row :duration_of_position
				row :vessel_type
				row :location
				row :starting_condition
				row :job_description
				row :responsibilities
				row :joblisting_icon
				row :recruiter_name
				panel 'Categories' do
          columns do
            table_for joblisting.joblisting_categories do |cat|
							column "Category Name" do |object|
								object.try(:category)&.name
							end
						end
					end
				end
			end
		end

		form(:html => { :multipart => true }) do |f|

			if f.object.new_record?
				div class: 'warning-message' do
				  ul do
					li 'Atleast One Joblisting category should be present'
				  end
				end
			elsif f.object.persisted? && f.object.joblisting_categories.size <= 1
				div class: 'warning-message' do
				  ul do
					li 'Atleast One Joblisting category should be present'
					li 'Don\'t try to update any field to blank'
				end
				end
			end
		  
			f.semantic_errors
			f.inputs "Joblisting Details" do
				f.input :job_title, as: :select, collection: BxBlockJoblisting::Joblisting::JOB_TITLE, multiple: false
				f.input :positions, as: :select, collection: BxBlockJoblisting::Joblisting::POSITIONS,
				multiple: false
				f.input :currency, as: :select, collection: BxBlockJoblisting::Joblisting::CURRENCIES,
				multiple: false
				f.input :salary_range
				# f.input :duration_of_position, as: :select, collection: BxBlockJoblisting::Joblisting::DURATION_OF_POSITION
				f.input :duration_of_position, as: :string, input_html: { placeholder: BxBlockJoblisting::Joblisting::PLACEHOLDER }
				f.input :vessel_type, as: :select, collection: BxBlockJoblisting::Joblisting::VESSEL_TYPE
				f.input :location, as: :select, collection: BxBlockJoblisting::Joblisting::LOCATION
				f.input :starting_condition, as: :string, input_html: { placeholder: 'DD/MM/YYYY'}
				f.input :job_description
				f.input :responsibilities
				f.input :joblisting_icon, as: :file
				f.inputs "Add Categories" do
          		f.has_many :joblisting_categories, heading: false, allow_destroy: joblisting.joblisting_categories.size > 1 do |cd|
					cd.input :category_id, as: :select, collection: BxBlockCategories::Category.all.map { |c| [c.name, c.id] }, include_blank: "Select", input_html: { class: 'form-control' }
					# if f.object.persisted?
					# cd.input :sub_category_ids, as: :select, collection: BxBlockCategories::SubCategory.where(category_id: cd.object.category_id).map { |s| [s.name, s.id] }, include_blank: "Select", input_html: { class: 'form-control', multiple: true }
					# end
				end
				end
			end
			f.actions
		end
  end
end
