module Tutorial
	class Load
		@@loaded_from_gem = false
		def self.is_loaded_from_gem
			@@loaded_from_gem
		end

		def self.loaded
			#empty
		end

		def self.link_tag
      #empty
		end

		# Check if this file is loaded from gem directory or not
		# The gem directory looks like
		# /template-app/.gems/gems/bx_block_custom_user_subs-0.0.7/app/admin/tutorial.rb
		# if it has block's name in it then it's a gem
		@@loaded_from_gem = Load.method(:loaded).source_location.first.include?("bx_block_")
	end
end
  
unless Tutorial::Load.is_loaded_from_gem
	ActiveAdmin.register BxBlockHelpCentre::Tutorial, as: "FAQ" do
		menu label: "FAQs"
		permit_params :video_title

		controller do

			def create
				BxBlockHelpCentre::Tutorial.destroy_all
				super
			end

			def destroy
				if resource.destroy
					flash[:success] = "Tutorial was successfully destroyed."
					render :index
				end
			end

		end

    index do
      selectable_column
			id_column
			column "FAQs", :video_title
			column :created_at
			column :updated_at
			actions
    end

    show do
			attributes_table do
				row "FAQs" do |tutorial|
			      tutorial.video_title.html_safe
			    end
				row :updated_at
			end
		end

    form :html => { :enctype => "multipart/form-data" } do |f|
			f.semantic_errors *f.object.errors.keys
	    f.inputs do
				f.input :video_title, label: "FAQs", as: :quill_editor, input_html: {data: {
                options: {
                          modules: {
                            toolbar: [
                              ['bold', 'italic', 'underline', 'strike'],
                              ['link', 'image'],                 
                              [{ 'list': 'ordered' }, { 'list': 'bullet' }],
                              [{ 'indent': '-1' }, { 'indent': '+1' }],
                            ],
                          },
                          placeholder: 'Type something...',
                          theme: 'snow',
                        }
                      }
                    }
			end
			f.actions
		end
  end
end
