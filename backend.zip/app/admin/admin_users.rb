module AdminUsers
  class Load
    @@loaded_from_gem = false
    def self.is_loaded_from_gem
      @@loaded_from_gem
    end

    def self.loaded
    end

    # Check if this file is loaded from gem directory or not
    # The gem directory looks like
    # /template-app/.gems/gems/bx_block_custom_user_subs-0.0.7/app/admin/subscription.rb
    # if it has block's name in it then it's a gem
    @@loaded_from_gem = Load.method('loaded').source_location.first.include?('bx_block_')
  end
end

unless AdminUsers::Load.is_loaded_from_gem
  ActiveAdmin.register AdminUser do
    permit_params :first_name, :last_name, :full_phone_number, :email, :country, :landline_number, :password, :password_confirmation, :role, :activated?
    RESTRICTED_ACTIONS = ["edit", "new", "destroy"]
    actions :all
  
    controller do
      def action_methods
        user = current_admin_user || resource
        if user.role && user.role == "super_admin"
          super
        else
          super - RESTRICTED_ACTIONS
        end
      end
    end

    index do
      selectable_column
      id_column
      column :first_name
      column :last_name
      column :email
      column :full_phone_number
      column :country
      column :landline_number
      column :role
      column "activated?" do |object|
        if object.role == "super_admin"
          "N/A"
        else
          object.activated?
        end
      end
      column :current_sign_in_at
      column :sign_in_count
      column :created_at
      actions
      div(id: 'get_lower') do
        render partial: 'bx_block_admin/ad_hoc_reports', locals:{context: self}
      end
    end

    filter :email
    filter :current_sign_in_at
    filter :sign_in_count
    filter :created_at

    form do |f|
      f.inputs do
        f.input :first_name
        f.input :last_name
        f.input :full_phone_number
        f.input :landline_number
        f.input :country, as: :string
        f.input :email, input_html: { disabled: f.object.persisted? }
        f.input :password
        f.input :password_confirmation
        f.input :role, input_html: { disabled: f.object.persisted? }
        if object.role != "super_admin"
          f.input :activated?
        end
      end
      f.actions
    end

    show do |admin_user|
      attributes_table do
        row :first_name
        row :last_name
        row :email
        row :full_phone_number
        row :country
        row :landline_number
        row :role
        row "activated?" do |object|
          if object.role == "super_admin"
            "N/A"
          else
            object.activated?
          end
        end
        row :current_sign_in_at
        row :sign_in_count
        row :created_at
        row :updated_at
      end
    end
  end
end
