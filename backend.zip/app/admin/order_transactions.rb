module OrderTransactions
  class Load
    @@loaded_from_gem = false
    def self.is_loaded_from_gem
      @@loaded_from_gem
    end

    def self.loaded
      #empty
    end

    # Check if this file is loaded from gem directory or not
    # The gem directory looks like
    # /template-app/.gems/gems/bx_block_custom_user_subs-0.0.7/app/admin/subscription.rb
    # if it has block's name in it then it's a gem
    @@loaded_from_gem = Load.method('loaded').source_location.first.include?('bx_block_')
  end
end

unless OrderTransactions::Load.is_loaded_from_gem
  ActiveAdmin.register BxBlockOrderManagement::OrderTransaction, as: "Payment Transactions" do
    actions :all, except: [:destroy, :new, :create]
    permit_params :account_id, :order_id, :amount, :payment_type, :subscription_id, :currency, :plan_type, :user_email
    scope :offline
    scope :online
    before_action :set_highest_paid_subscription, :success_status, :failed_status, only: :index

    filter :created_at
    filter :user_email
    filter :user_name

form do |f|
  f.inputs do
    f.input :amount, input_html: { id: 'order_transaction_amount' }
    f.input :currency, as: :select, collection: ['usd', 'inr'], multiple: false
    f.input :charge_status
    f.input :payment_type
    f.input :user_name
    f.input :user_email

    @user_role = AccountBlock::EmailAccount.find_by(email: BxBlockOrderManagement::OrderTransaction.find(params[:id].to_i).user_email)&.account_role
    plan_type = BxBlockOrderManagement::OrderTransaction.find(params[:id].to_i).plan_type.downcase

    if @user_role == 'Recruiter'
      if plan_type == 'advertisement'
        f.input :subscription_id, as: :select, collection: BxBlockCustomUserSubs::Subscription.advertisement_subscription.map { |sub| [sub.name, sub.id, { 'data-amount': sub.price }] }, include_blank: "Select", input_html: { id: 'order_transaction_plan_type'}, multiple: false, label: "Plan"
      else
        f.input :subscription_id, as: :select, collection: BxBlockCustomUserSubs::Subscription.recruiter_signup_subscription.map { |sub| [sub.name, sub.id, { 'data-amount': sub.price }] }, include_blank: "Select", input_html: { id: 'order_transaction_plan_type'}, multiple: false, label: "Plan"
      end
    elsif @user_role == 'Jobseeker'
      f.input :subscription_id, as: :select, collection: BxBlockCustomUserSubs::Subscription.jobseeker_signup_subscription.map { |sub| [sub.name, sub.id, { 'data-amount': sub.price }] }, include_blank: "Select", input_html: { id: 'order_transaction_plan_type'}, multiple: false, label: "Plan"
    end
    
    if @user_role == 'Recruiter'
    f.input :plan_type, input_html: { value: plan_type == 'advertisement' ? "Yes" : "No", disabled: true }, label: "Advertisement Type"
  end

    f.actions
  end
end

    controller do
      include BxBlockCustomUserSubs::UserSubscriptionModule

      def set_highest_paid_subscription
          # time = Time.now + (5 * 3600) + (30 * 60)
        transactions = BxBlockOrderManagement::OrderTransaction
        transactions_today = transactions.where("DATE(created_at) = ?", Date.today)
        @total_amount_today = transactions_today.sum(:amount)
        transactions_yesterday = transactions.where("DATE(created_at) = ?", Date.today - 1.days)
        @total_amount_yesterday = transactions_yesterday.sum(:amount)

        current_month_transactions = monthly_transactions(transactions)
        @total_amount_of_month = current_month_transactions.sum(:amount)
        @highest_order_transaction_id = transactions.order(amount: :desc).first&.id

        subscription_id = BxBlockOrderManagement::OrderTransaction.group(:subscription_id).count.max_by { |_, count| count }&.first
        @highest_paid_subscription = BxBlockCustomUserSubs::Subscription.find_by_id(subscription_id) if subscription_id.present?

        @total_successful_payment, @total_failed_payment, @total_amount_with_no_action = payment_calculate(transactions)
      end

      def success_status
        return 'Succeeded Transaction'
      end

      def failed_status
        return 'Failed Transaction'
      end

      # def check_user_subscription_presence(user, subscription_id)
      #   user_subscription = BxBlockCustomUserSubs::UserSubscription.find_by(subscription_id: UserSubscription, account_id: user.id)
      #   user_subscription.present? ? true : false
      # end


      private

      def monthly_transactions(transactions)
        current_month_start = Date.today.beginning_of_month
        current_month_end = Date.today.end_of_month
        current_month_transactions = transactions.where(created_at: current_month_start..current_month_end)
        return current_month_transactions
      end

      def payment_calculate(transactions)
        successfully_paid_amount = transactions.where(charge_status: success_status).sum(:amount)
        failed_amount = transactions.where(charge_status: failed_status).sum(:amount)
        total_amount_with_no_action_taken = transactions.where(charge_status: 'Payment Initiated').sum(:amount)
        return [successfully_paid_amount, failed_amount, total_amount_with_no_action_taken]
      end
    end
   
    member_action :update_status, method: :patch do
        if params[:id].to_i.zero?
          flash[:alert] = 'Invalid transaction ID'
          redirect_to admin_payment_transactions_path
          return
        end
        @order_trx = BxBlockOrderManagement::OrderTransaction.find(params[:id].to_i)  
        @user = AccountBlock::Account.find(@order_trx.account_id)
        new_status = params[:status]
        old_status = @order_trx.charge_status
        unless new_status == old_status
          if new_status == success_status
            @order_trx.update_column(:charge_status, new_status)
            unassign_subscribed_plan(@user,  @order_trx.plan_type)
            assign_subscription_to_user(@user, @order_trx.subscription_id)
            BxBlockStripeIntegration::PaymentMailer.payment_received_email(@user, @order_trx).deliver_now
          else new_status == failed_status
            @order_trx.update_column(:charge_status, new_status)
            BxBlockStripeIntegration::PaymentMailer.payment_failed_email(@user, @order_trx).deliver_now
          end
          redirect_to admin_payment_transaction_path(@order_trx), notice: 'Transaction status successfully!'
        else
           redirect_to admin_payment_transaction_path(@order_trx), notice: 'Transaction status already updated with the same' 
        end
    end

    index do
      selectable_column
      id_column
      column :payment_type
      column :amount
      column :charge_status
      column "user_email" do |object|
        "#{object&.user_email}"
      end
      column "Advertisment Type" do |object|
    object.plan_type == 'advertisement' ? 'Yes' : 'No'
      end
      actions defaults: true do |object|
        if object&.charge_status == 'Payment Initiated'
          status_options = {
            "Success" => 'Succeeded Transaction',
            "Failed" => 'Failed Transaction'
          }
          links = status_options.map do |label, status|
            link_to label, update_status_admin_payment_transaction_path(object, status: status), method: :patch
          end
          safe_join(links, " | ")
        end
      end

      div(id: 'get_lower') do
        panel 'Plan Transaction Analytics' do
          render partial: 'highest_paid_subscription_plan'
        end
      end
    end
  end
end