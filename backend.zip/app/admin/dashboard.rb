module Dashboard
  class Load
    @@loaded_from_gem = false
    def self.is_loaded_from_gem
      @@loaded_from_gem
    end

    def self.loaded
    end

    @@loaded_from_gem = Load.method('loaded').source_location.first.include?('bx_block_')
  end
end

unless Dashboard::Load.is_loaded_from_gem
  ActiveAdmin.register_page "Dashboard" do
    menu priority: 1, label: proc { I18n.t("active_admin.dashboard") }

    content title: proc { I18n.t("active_admin.dashboard") } do

      columns do
        column do
          panel "Registered Users Details" do
            table_for AccountBlock::Account do
              column("Total Users") { AccountBlock::Account.count }
              column("Total Recruiters") { AccountBlock::Account.recruiters.count }
              column("Total Job Seekers") { AccountBlock::Account.jobseekers.count }
            end
          end
        end
      end
    end 
  end
end
