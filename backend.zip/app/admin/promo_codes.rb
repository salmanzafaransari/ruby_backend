module PromoCodes
  class Load
    @@loaded_from_gem = false
    def self.is_loaded_from_gem
      @@loaded_from_gem
    end

    def self.loaded
      #empty
    end

    # Check if this file is loaded from gem directory or not
    # The gem directory looks like
    # /template-app/.gems/gems/bx_block_custom_user_subs-0.0.7/app/admin/subscription.rb
    # if it has block's name in it then it's a gem
    @@loaded_from_gem = Load.method('loaded').source_location.first.include?('bx_block_')
  end
end

unless PromoCodes::Load.is_loaded_from_gem
  ActiveAdmin.register BxBlockCouponCg::CouponCode, as: "PromoCode" do
    permit_params :title, :description, :code, :discount_type,:discount, :valid_from, :valid_to, :min_cart_value,:max_cart_value

    form do |f|
      f.inputs 'Coupon Code Details' do
        f.input :title
        f.input :description
        f.input :code
        f.input :discount_type, as: :select, collection: BxBlockCouponCg::CouponCode::DISCOUNT_TYPE.values
        f.input :discount
        f.input :valid_from
        f.input :valid_to
      end
      f.actions
    end

    filter :title
    filter :created_at
    filter :code
    filter :discount_type, as: :select, collection: BxBlockCouponCg::CouponCode::DISCOUNT_TYPE.values

      index do
      selectable_column
      id_column
      column :title
      column :description
      column :code
      column :discount_type
      column :discount do |dis|
        if dis.discount_type == BxBlockCouponCg::CouponCode::DISCOUNT_TYPE[:percentage]
          "#{dis.discount}%"
        else
          dis.discount
        end
      end
      column :valid_from
      column :valid_to
      actions
    end
  end
end