module Subscription
  class Load
    @@loaded_from_gem = false
    def self.is_loaded_from_gem
      @@loaded_from_gem
    end

    def self.loaded
    end
    
    @@loaded_from_gem = Load.method('loaded').source_location.first.include?('bx_block_')
  end
end

unless Subscription::Load.is_loaded_from_gem
  ActiveAdmin.register BxBlockCustomUserSubs::Subscription do
    menu label: "Subscription/Plans"
    actions :all, except: [:destroy]
    permit_params :name, :description, :valid_for, :price, :image, :advertisement_type, :max_advertisements, :currency, :active, :ads_frequency_id, :for_recruiter
    before_action :set_max_subscription, only: [:index]
    after_action :remove_ads_frequency, only: [:update]
    includes :image_attachment

    filter :name
    filter :promotion_type
    filter :advertisement_type
    filter :active

    form do |f|
      f.inputs do
        f.input :name
        f.input :description, as: :text, input_html: { rows: 10, placeholder: 'Enter key-value pairs (e.g., {"Key1": "Value1", "Key2": "Value2"})' }
        f.input :currency, as: :select, collection: ['usd', 'inr'],
        multiple: false
        f.input :price
        f.input :valid_for
        f.input :advertisement_type
        f.input :max_advertisements
        f.input :image, as: :file
        f.input :ads_frequency_id, as: :select, collection: BxBlockCustomAds::AdsFrequency.all.map { |ad| [ad.name, ad.id] }, include_blank: "Select", input_html: { class: 'form-control' }
        f.inputs "Conditions" do
          columns do
            column do
              f.input :active, as: :boolean, input_html: { class: 'custom-checkbox' } 
            end
            column do
              f.input :for_recruiter, as: :boolean
            end
          end
        end
      end

      f.actions
    end

    index  title: 'Subscriptions/Plans' do
      id_column
      column :name
      column :description
      column :price
      column :valid_for do |sub|
        "#{sub.valid_for} months"
      end
      column :advertisement_type
      column :max_advertisements
      column :active
      column :for_recruiter
      column :image do |s|
        s.image.attached? ? (Rails.application.routes.url_helpers.rails_blob_path(
          s.image,only_path: true)) : 'Image Not Attached'
      end
      
      div(id: 'get_lower') do
        panel 'Most Popular Subscription Plan' do
          render partial: 'max_subscriptions_plan'
        end

        panel 'Subscription Percentage' do
          render partial: 'subscription_percentage'
        end
      end

      actions
    end

    show do
      attributes_table do
        row :name
        row :description
        row :price
        row :valid_for do |sub|
          "#{sub.valid_for} months"
        end
        row :advertisement_type
        row :max_advertisements
        row :active 
        row :for_recruiter
        row :image do |s|
          s.image.attached? ? (image_tag url_for(s.image)) : ''
        end
        row :ads_frequency do |ad|
          BxBlockCustomAds::AdsFrequency.find_by_id(ad&.ads_frequency_id)&.name
        end
      end
    end

    controller do 
      def set_max_subscription
        @max_subscription = BxBlockCustomUserSubs::Subscription.joins(:accounts).group('bx_block_custom_user_subs_subscriptions.id').order('COUNT(accounts.id) DESC').first

        subscription_counts = BxBlockCustomUserSubs::UserSubscription.group(:subscription_id, :account_id).count
        subscription_account_counts = subscription_counts&.group_by { |keys, _| keys[0] }.transform_values { |values| values&.size }
        total_unique_accounts = subscription_counts&.map { |keys, _| keys[1] }.uniq.size
        @percentage_by_subscription = {}

        subscription_account_counts&.each do |subscription_id, count|
          unless total_unique_accounts.zero?
            @percentage_by_subscription[subscription_id] = (count.to_f / total_unique_accounts * 100).round(0)
          else
            @percentage_by_subscription[subscription_id] = nil
          end
        end
      end

      def remove_ads_frequency
        if resource.advertisement_type == false
          resource.ads_frequency_id = nil
          resource.save!
        end
      end
    end
  end
end
