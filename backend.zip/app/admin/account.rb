module Account
	class Load
		@@loaded_from_gem = false
		def self.is_loaded_from_gem
			@@loaded_from_gem
		end

		def self.loaded
			#empty
		end

		def self.link_tag
			"Click For Viewing"
		end

		# Check if this file is loaded from gem directory or not
		# The gem directory looks like
		# /template-app/.gems/gems/bx_block_custom_user_subs-0.0.7/app/admin/subscription.rb
		# if it has block's name in it then it's a gem
		@@loaded_from_gem = Load.method(:loaded).source_location.first.include?("bx_block_")
	end
end
  
unless Account::Load.is_loaded_from_gem
	ActiveAdmin.register AccountBlock::Account, as: "Users" do
		permit_params :first_name, :last_name, :type, :status, :email, :activated, :gender, :full_phone_number, :account_role, :password, profile_data_attributes: [ :id, :height_type, :weight_type, :height, :weight, :company_name, :total_work_experience, :country, :landline_number, :resume, :selfie_picture, :covid_19_certificate, :video_cv, :open_for, :seamen_book_number, :available?, :currency, :salary_range_usd, :linkedin_url, :passport_picture,
			{training_and_certifications:[]}, :stcw, {health_record: []},
			{personality: []}, {interests: []}, {interested_in: []}, :_destroy ]

		controller do
			after_action :send_account_created_email, only: :create

			def send_account_created_email
				@user = resource
				if @user.valid? 
				 @user.create_general_cv if @user.account_role == 'Jobseeker'
				 AccountBlock::AccountCreatedMailer.account_created_email(@user).deliver_now
				end
			end
		end

		index do
			selectable_column
			id_column
			column :first_name
			column :last_name
			column :email
			column :full_phone_number
			column :activated
			column :type
			column :status
			column :gender
			column :date_of_birth
			column :account_role
			column "company_name" do |object|
				object.profile_data&.company_name
			end
			column "Total Work Experience" do |object|
				object.profile_data&.total_work_experience
			end
			column "country" do |object|
				object.profile_data&.country
			end
			column "landline_number" do |object|
				object.profile_data&.landline_number
			end
			column "height" do |object|
				object.profile_data&.height
			end
			column "weight" do |object|
				object.profile_data&.weight
			end
			column "personality" do |object|
				object.profile_data&.personality&.reject(&:blank?)
			end
			column "interests" do |object|
				object.profile_data&.interests&.reject(&:blank?)
			end
			column "open for" do |object|
				object.profile_data&.open_for
			end
			column "interested in" do |object|
				object.profile_data&.interested_in&.reject(&:blank?)
			end
			actions
		end

		filter :first_name
		filter :last_name
		filter :email
		filter :account_role, as: :select, collection: AccountBlock::Account::account_roles
		filter :created_at

	  form(:html => { :multipart => true }) do |f|
			f.semantic_errors *f.object.errors.keys
	    f.inputs do
				f.input :type, as: :select, collection: ["EmailAccount", "SmsAccount", "SocialAccount"]
	      f.input :first_name
	      f.input :last_name
				f.input :status
				f.input :email
				f.input :activated
				f.input :gender
				f.input :account_role
				f.input :full_phone_number
				if request.filtered_parameters['action'] == 'edit'
					f.input :password, input_html: { disabled: true }
				else
					f.input :password
				end

				f.inputs "Profile Bio", for: [:profile_data, f.object.profile_data || BxBlockProfileBio::ProfileBio.new] do |cd|
					cd.input :height_type
					cd.input :weight_type
					cd.input :height
					cd.input :weight
					cd.input :open_for
					cd.input :interested_in, as: :check_boxes, collection: BxBlockProfileBio::ProfileBio::INTERESTED_IN_VALUES, multiple: true
					cd.input :seamen_book_number
					cd.input :currency, as: :select, collection: BxBlockJoblisting::Joblisting::CURRENCIES, multiple: false
					cd.input :salary_range_usd
					cd.input :available?
					cd.input :linkedin_url
					cd.input :personality, as: :select, collection: BxBlockProfileBio::ProfileBio::PERSONALITY_VALUES, multiple: true
					cd.input :interests, as: :select, collection: BxBlockProfileBio::ProfileBio::INTERESTS_VALUES, multiple: true
					cd.input :resume, as: :file
					cd.input :selfie_picture, as: :file
					cd.input :passport_picture, as: :file
					cd.input :covid_19_certificate, as: :file 
					cd.input :training_and_certifications, as: :file, input_html: { multiple: true }
					cd.input :stcw, as: :file
					cd.input :health_record, as: :file, input_html: { multiple: true }
					cd.input :video_cv, as: :file
					cd.input :company_name
					cd.input :total_work_experience
					cd.input :country, as: :string
					cd.input :landline_number
				end
	    end
	    f.actions
	  end

		show do |account|
			attributes_table do
				row :first_name
				row :last_name
				row :status
				row :email
				row :activated
				row :type
				row :gender
				row :full_phone_number
				row :account_role
				row "company name" do |object|
					object.profile_data&.company_name
				end
				row "total_work_experience" do |object|
					object.profile_data&.total_work_experience
				end
				row "country" do |object|
					object.profile_data&.country
				end
				row "landline number" do |object|
					object.profile_data&.landline_number
				end
				row "height type" do |object|
					object.profile_data&.height_type
				end
				row "weight type" do |object|
					object.profile_data&.weight_type
				end
				row "height" do |object|
					object.profile_data&.height
				end
				row "weight" do |object|
					object.profile_data&.weight
				end
				row "open for" do |object|
					object.profile_bio&.open_for
				end
				row "interested in" do |object|
					object.profile_bio&.interested_in&.reject(&:blank?)
				end
				row "seamen book number" do |object|
					object.profile_bio&.seamen_book_number
				end
				row "personality" do |object|
					object.profile_data&.personality&.reject(&:blank?)
				end
				row "interests" do |object|
					object.profile_data&.interests&.reject(&:blank?)
				end
				row "linkedin_url" do |object|
					object.profile_data&.linkedin_url&.present? ? (link_to(object.profile_data.linkedin_url, object.profile_data.linkedin_url, target: "_blank")) : nil 
				end
				row "resume" do |object|
					object.profile_data&.resume&.present?  ? (link_to Account::Load.link_tag, "#{object.profile_data&.resume}", target: "_blank") : nil 
				end
				row "selfie picture" do |object|
					object.profile_data&.selfie_picture.present? ? (image_tag(object.profile_data.selfie_picture.url, style: "width: 100px")) : nil
				end
				row "passport picture" do |object|
					object.profile_data&.passport_picture.present? ? (image_tag(object.profile_data.passport_picture.url, style: "width: 100px")) : nil
				end
				row "covid 19 certificate" do |object|
					object.profile_data&.covid_19_certificate&.present?  ? (link_to Account::Load.link_tag, "#{object.profile_data&.covid_19_certificate}", target: "_blank") : nil 
				end
				row "training_and_certifications" do |object|
					object.profile_data&.training_and_certifications&.present?  ? object.profile_data&.training_and_certifications&.map{ |train_and_cert|(link_to Account::Load.link_tag,
						"#{train_and_cert}", target: "_blank")} : nil 
				end
				row "stcw" do |object|
					object.profile_data&.stcw&.present?  ? (link_to Account::Load.link_tag, "#{object.profile_data&.stcw}", target: "_blank") : nil 
				end
				row "health record" do |object|
					object.profile_data&.health_record&.present?  ? object.profile_data&.health_record&.map{|image| (link_to Account::Load.link_tag, "#{image}", target: "_blank")} : nil 
				end
				row "video cv" do |object|
					object.profile_data&.video_cv&.present?  ? (link_to Account::Load.link_tag, "#{object.profile_data&.video_cv}", target: "_blank") : nil 
				end
				columns do
            	table_for account&.cv do |cv|
							column "Users Cv Id" do |object|
								object.present?	? object&.id : "NA"
							end
							column "Seamen Book Number Ids" do |object|
								object.present?	? object&.seamen_book_numbers.pluck(:id) : "NA"
							end
							column "Professional Acedemic Qualification Ids" do |object|
								object.present?	? object&.professional_acedemic_qualifications.pluck(:id) : "NA"
							end
							column "Licence Certificates Of Competencies Ids" do |object|
								object.present?	? object&.licence_certificates_of_competencies.pluck(:id) : "NA"
							end
							column "Work Experience Ids" do |object|
								object.present?	? object&.work_experiences.pluck(:id) : "NA"
							end
							column "STCW Value Added Courses Ids" do |object|
								object.present?	? object&.stcw_value_added_courses.pluck(:id) : "NA"
							end
						end
				end
			end
		end
	end
end
  