module BxBlockLogin
  class LoginsController < ApplicationController
    def create
      case params[:data][:type] #### rescue invalid API format
      when 'sms_account', 'email_account', 'social_account'
        account = OpenStruct.new(jsonapi_deserialize(params))
        account.type = params[:data][:type]
        role = params[:data][:attributes][:account_role] rescue nil

        unless role.present?
          return render json: {
                  errors: [{
                    failed_login: 'Please specify your role for login.',
                  }],
                }, status: :unauthorized
        end

        output = AccountAdapter.new

        output.on(:account_not_found) do |account|
          render json: {
            errors: [{
              failed_login: "No account registered with this email as #{role}",
            }],
          }, status: :unprocessable_entity
        end

        output.on(:account_not_activated) do |account|
          render json: {
            errors: [{
              failed_login: 'Account not activated',
            }],
          }, status: :unprocessable_entity
        end

        output.on(:failed_login) do |account|
          render json: {
            errors: [{
              failed_login: 'Incorrect password',
            }],
          }, status: :unauthorized
        end

        output.on(:successful_login) do |account, token, refresh_token|
          response_json = account.slice(:first_name, :last_name, :email, :full_phone_number, :notify)
          response_json[:selfie_picture] = account.profile_bio&.selfie_picture&.url
          response_json[:signup_plan_taken] = account.subscriptions&.signup_subscription&.first.present?
          response_json[:offline] = account.orders&.last&.order_transaction.present? ? true : false


          render json: {
            account: response_json,
            meta: {
              token: token,
              refresh_token: refresh_token,
              id: account.id
            }
          }
        end

        output.login_account(account)
      else
        render json: {
          errors: [{
            account: 'Invalid Account Type',
          }],
        }, status: :unprocessable_entity
      end
    end
  end
end
