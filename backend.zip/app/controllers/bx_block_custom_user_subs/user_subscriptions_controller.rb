module BxBlockCustomUserSubs
  class UserSubscriptionsController < ApplicationController
    before_action :user_subscriptions, only: [:index]

    def index
      subscription = @user_subscriptions.signup_subscription&.first
      user_sub = subscription.user_subscriptions.find_by(account_id: current_user.id)
      expiry = user_sub.expiry_date < Date.today ? true : false
      render json: BxBlockCustomUserSubs::SubscriptionSerializer
                       .new(subscription, params: {user: current_user, expired: expiry, type: :as_sign_up})
                       .serializable_hash
    end

    # def show
    #   subscription = user_subscriptions.find(params[:id])
    #   render json: BxBlockCustomUserSubs::SubscriptionSerializer
    #                    .new(subscription, params: {user: current_user})
    #                    .serializable_hash
    # end

    # def create
    #   user_subscription = BxBlockCustomUserSubs::UserSubscription.create(
    #     subscription_id: params[:id],
    #     account_id: current_user.id
    #   )
    #   subscription = user_subscription.subscription
    #   render json: BxBlockCustomUserSubs::SubscriptionSerializer
    #                    .new(subscription, params: {user: current_user})
    #                    .serializable_hash
    # end

    private

    def user_subscriptions
      @user_subscriptions = BxBlockCustomUserSubs::Subscription.joins(:user_subscriptions).where(
        'user_subscriptions.account_id = ?', current_user.id
      )
      if !@user_subscriptions.present?
        render json: {error: "No Subscried Plan Yet..!!"}
      else
        @user_subscriptions
      end
    end

  end
end
