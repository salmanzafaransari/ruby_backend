module BxBlockCustomUserSubs
  class SubscriptionsController < ApplicationController

    def index
      subscriptions = current_user.Recruiter? ? BxBlockCustomUserSubs::Subscription.recruiter_signup_subscription : BxBlockCustomUserSubs::Subscription.jobseeker_signup_subscription
      render json: BxBlockCustomUserSubs::SubscriptionSerializer
                       .new(subscriptions, params: {user: current_user, type: :as_sign_up})
                       .serializable_hash
    end

    def advertisement_plan_list
      @subscriptions=  BxBlockCustomUserSubs::Subscription.advertisement_subscription
      if @subscriptions.present?
        render json: BxBlockCustomUserSubs::SubscriptionSerializer
          .new(@subscriptions, params: {user: current_user, type: :as_advertisement})
            .serializable_hash, status: :ok
      else
       render json: { error: "No subscribed plans of this user." },  status: :not_found
      end
    end

    private

    def user_subscribing_params
      params.permit(:subscription_id)
    end
  end
end
