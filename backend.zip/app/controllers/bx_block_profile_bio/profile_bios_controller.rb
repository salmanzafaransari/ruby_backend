# frozen_string_literal: true
require 'rubygems'
require 'pdf-reader'
require 'mini_magick'
require 'tempfile'
require 'rtesseract'
module BxBlockProfileBio
  # app/controller/ProfileBiosController
  class ProfileBiosController < ApplicationController
    include BxBlockProfileBio::CvParamsModule

    before_action :load_account, only: %i[show]
    before_action :check_account_activated, only: %i[update show destroy]
    before_action :check_phone_number_validity, only: %i[create update]
    before_action :validate_email, :check_existing_user, only: %i[create update]

    def create
      profile = BxBlockProfileBio::ProfileBio.includes(:account).find_by(accounts: {id: current_user.id})
      if profile.present?
        render json: {errors: [
          {profile: "Profile bio has been already created"}
        ]}, status: :unprocessable_entity and return
      end

      begin
        profile_bio = current_user.build_profile_bio(profile_params)
        # Commented below line because UpdateAccountValidator not working properly, instead added account and profile_bio model validations
        # account_validator = BxBlockProfile::UpdateAccountValidator.new(current_user.id, account_update_params)

        if profile_bio.valid? && current_user.update(account_update_params) && profile_bio.save
          @user = profile_bio.try(:account)
          create_cv_from_resume(profile_bio.resume)
          send_welcome_email_and_notification
          if profile_bio.account.account_role == "Jobseeker"
            render json: BxBlockProfileBio::ProfileBioJobseekerSerializer.new(profile_bio).serializable_hash, status: :ok
          else
            render json: BxBlockProfileBio::ProfileBioRecruiterSerializer.new(profile_bio).serializable_hash, status: :ok
          end
        else
          render_create_validation_errors(profile_bio)
        end
      rescue Exception => e
        render json: {errors: [e.message]},
          status: :unprocessable_entity
      end
    end

    def edit
      if params[:profile_bio_id].to_i == current_user.id
        profile_bio = current_user.try(:profile_bio)
        if profile_bio.nil?
          render json: {
            message: "Profile bio doesn't exists"
          }, status: :not_found and return
        else
          account_data = AccountBlock::AccountSerializer.new(profile_bio.account).serializable_hash[:data][:attributes].as_json
          profile_bio_data = BxBlockProfileBio::ProfileBioJobseekerSerializer.new(profile_bio).serializable_hash[:data][:attributes].as_json
          response_json = {
            first_name: account_data['first_name'],
            last_name: account_data['last_name'],
            email: account_data['email'],
            full_phone_number: account_data['full_phone_number'],
            linkedin_url: profile_bio_data['linkedin_url'],
            profile_pic: profile_bio_data['selfie_picture']
          }
          render json: response_json
        end
      else
        render json: {errors: [
            {profile: 'Profile not found'}
          ]}, status: 404
      end
    end

    def update
      if params[:id].to_i == current_user.id
        profile = current_user.try(:profile_bio)
        if profile.nil?
          render json: {
            message: "Profile bio doesn't exists"
          }, status: :not_found and return
        end

        profile.assign_attributes(profile_params)
  
        if profile.valid? && current_user.update(account_update_params) && profile.save
          if profile.account.account_role == "Jobseeker"
            update_linkedin_url_in_cv
            render json: BxBlockProfileBio::ProfileBioJobseekerSerializer.new(profile).serializable_hash, status: :ok
          else
            render json: BxBlockProfileBio::ProfileBioRecruiterSerializer.new(profile).serializable_hash, status: :ok
          end
        else
          render json: {errors: [
            {profile: profile.errors.full_messages},
            {account: current_user.errors.full_messages}
          ]}, status: :unprocessable_entity
        end
      else
        render json: {errors: [
            {profile: 'Profile not found'}
          ]}, status: 404
      end
    rescue Exception => e
      render json: {errors: [e.message]},
        status: :unprocessable_entity
    end  

    def show_user_cv
      user_cv = fetch_user_cv
      if user_cv.present?
        serialized_cv = BxBlockProfile::CvSerializer.new(user_cv).serializable_hash
        message = "Your iSail CV is almost ready. Please proceed to verify and edit your details."
        render json: { message: message, data: serialized_cv }, status: :ok
      else
        render json: { data: [] }, status: :ok
      end
    end

    def airport_list
      begin
        airport_names = read_airport_names
        render json: { airports: airport_names }, status: :ok
      rescue StandardError => e
        Rails.logger.error("Error in airport_list: #{e.message}")
        render json: { error: 'Failed To Retrieve Airport Names' }, status: :internal_server_error
      end
    end

    # def destroy
    #   profile =current_user.try(:profile_bio)
    #   if profile.nil?
    #     render json: {
    #       message: "Profile bio doesn't exists"
    #     }, status: :not_found and return
    #   elsif profile.destroy!
    #     render json: {message: "Deleted Successfully"}, status: :ok
    #   end
    # rescue Exception => e
    #   render json: {errors: [e.message]},
    #     status: :unprocessable_entity
    # end

    # def index
    #   profile = BxBlockProfileBio::ProfileBio.includes(:account)
    #     .find_by(accounts: {id: current_user.id})
    #   if profile.nil?
    #     render json: {
    #       message: "Profile bio doesn't exists"
    #     }, status: :not_found and return
    #   else
    #     render json: BxBlockProfileBio::ProfileBioSerializer.new(profile).serializable_hash, status: :ok
    #   end
    # end

    # def show
    #   return if @account.nil?

    #   find_distance_and_assign_values

    #   json_data = BxBlockProfileBio::BasicProfileSerializer.new(@account,
    #     params: {current_user_id: current_user.id}).serializable_hash
    #   json_data[:favourite] = profile_favourite.present? ? profile_favourite.as_json : {}
    #   json_data[:like] = profile_like.present? ? profile_like.as_json : {}
    #   json_data[:is_profile] = @account.profile_bio.present?
    #   render json: json_data,
    #     status: :ok
    # end

    # def fetch_interests
    #   interests_values = BxBlockProfileBio::ProfileBio::INTERESTS_VALUES
    #   if params[:search_item].present?
    #     interests_values = interests_values.select { |item| item.downcase.include?(params[:search_item]) }
    #   end
    #   render json: interests_values,
    #     status: :ok
    # end

    # def fetch_personalities
    #   personalities_values = BxBlockProfileBio::ProfileBio::PERSONALITY_VALUES
    #   if params[:search_item].present?
    #     personalities_values = personalities_values.select { |item| item.downcase.include?(params[:search_item]) }
    #   end
    #   render json: personalities_values,
    #     status: :ok
    # end

    private

    # def profile_favourite
    #   @favourites ||= BxBlockFavourites::Favourite.where(
    #     favourite_by_id: current_user.id,
    #     favouriteable_id: @account.id,
    #     favouriteable_type: "AccountBlock::Account"
    #   ).last
    # end

    # def profile_like
    #   @profile_like ||= BxBlockLike::Like.where(
    #     like_by_id: current_user.id,
    #     likeable_id: @account.id,
    #     likeable_type: "AccountBlock::Account"
    #   ).last
    # end

    # def find_distance_and_assign_values
    #   @account.is_favourite = profile_favourite.present?
    #   @account.is_liked = profile_like.present?
    #   return if current_user&.location.blank? || @account&.location.blank?

    #   @account.distance_away = Geocoder::Calculations.distance_between(
    #     [current_user.location.latitude, current_user.location.longitude],
    #     [@account.location["latitude"], @account.location["longitude"]],
    #     units: :km
    #   ).round(2)
    # end

    # def update_profile_bio(profile)
    #   profile.save
    #   render json: BxBlockProfileBio::ProfileBioSerializer.new(profile).serializable_hash, status: :ok
    # end

    def render_create_validation_errors(profile_bio)
      errors_arr = []
      errors_arr << profile_bio.errors.full_messages if profile_bio.errors.present?
      errors_arr << current_user.errors.full_messages if current_user.errors.present?
      render json: {errors: errors_arr}, status: :unprocessable_entity
    end

    def profile_params
      allowed_params = params.require(:data)[:attributes].permit(
        :height, :weight, :height_type, :weight_type, :open_for, :seamen_book_number, :covid_19_certificate, :video_cv, :selfie_picture, {health_record: []}, {training_and_certifications: []}, :stcw , :passport_picture, :resume, :total_work_experience, :currency, :salary_range_usd, :linkedin_url, :nearest_intl_airport, :available?, :unavailable_from, :unavailable_till, :body_type, :mother_tougue,
        :company_name, :country, :landline_number,
        :religion, :zodiac, :marital_status, :smoking, :drinking, :looking_for,
        :about_me, :about_business, :category_id, custom_attributes: {}, languages: [], personality: [],
        interests: [], interested_in: [],
        educations_attributes: %i[id qualification description year_from year_to _destroy],
        achievements_attributes: %i[id title achievement_date detail url _destroy],
        careers_attributes: [:id, :profession, :is_current, :experience_from,
          :experience_to, :payscale, :company_name, :sector, :_destroy, {
            accomplishment: []
          }]
      )
      if params[:action] == "create"
        allowed_params.tap do |whitelisted|
          whitelisted[:covid_19_certificate] ||= {}
          whitelisted[:video_cv] ||= {}
          whitelisted[:resume] ||= {}
          whitelisted[:passport_picture] ||= {}
          whitelisted[:selfie_picture] ||= {}
          whitelisted[:health_record] ||= []
          whitelisted[:training_and_certifications] ||= {}
          whitelisted[:stcw] ||= {}
        end
      end
      return allowed_params
    end

    def create_cv_from_resume(resume)
      if resume.present?
        temp_pdf = Tempfile.new(['resume', '.pdf'])
        temp_pdf.binmode
        temp_pdf.write(resume.read)
        temp_pdf.rewind
        extracted_text = pdf_convert(temp_pdf)
        personal = personal_data(extracted_text) 
        bio = map_bio_data(extracted_text)
        qualifications = map_academic_qualification_data(extracted_text)
        work_ex = map_work_ex_data(extracted_text)
        passport = map_passport_data(extracted_text)
        cv_attributes = cv_attributes_data(bio, qualifications, work_ex, personal, passport)
        temp_pdf.close
        temp_pdf.unlink
        BxBlockProfile::Cv.create(cv_attributes)
      end
    end

    def cv_attributes_data(bio, qualifications, work_ex, personal, passport)
        permitted_params = cv_params
        cv_attributes = permitted_params[:attributes]
        cv_attributes[:bio] = bio
        cv_attributes[:account_id] = current_user.id
        cv_attributes[:first_name] = personal&.first || current_user&.first_name
        cv_attributes[:last_name] = personal[2] || current_user&.last_name
        cv_attributes[:full_phone_number] = personal[11] || current_user&.full_phone_number
        cv_attributes[:email] = current_user.email
        cv_attributes[:linkedin_url] = current_user.profile_bio.try(:linkedin_url)
        cv_attributes[:gender] = personal[5] || nil
        cv_attributes[:date_of_birth] = personal[4] || nil
        cv_attributes[:place_of_birth] = personal[6] || nil
        cv_attributes[:city] = personal[7] || nil
        cv_attributes[:availability_date] = current_user.profile_bio&.unavailable_till
        cv_attributes[:nearest_intl_airport] = current_user.profile_bio&.nearest_intl_airport

        cv_attributes[:professional_acedemic_qualifications_attributes] = academic_hash(qualifications)

        cv_attributes[:seamen_book_numbers_attributes] = [
          {
            seamen_book_number: current_user.profile_bio.seamen_book_number.nil? ? '' : current_user.profile_bio.seamen_book_number,
            place_of_issue: '',
            issue_date: Date.today - 2.years,
            expiry_date: Date.today
          }
        ]

        cv_attributes[:passport_and_visa_detail_attributes] = {
          sid: '',
          passport_number: passport.present? ? passport[0]: '',
          us_visa: '',
          expiry_date: passport.present? ? passport[passport.length-1]: ''
        }

        cv_attributes[:work_experiences_attributes] = work_exp_hash(work_ex)

        cv_attributes[:licence_certificates_of_competencies_attributes] = [
          {
            issue_authorithy: "",  
            number: "",
            grade: "",
            issue_date: "",
            expiry_date: "",
            revalidate_date: "",
            issue_country: ""
          }
        ]

        cv_attributes[:stcw_value_added_courses_attributes] = [
          {
            stcw_course: "",
            certificate_number: "",
            issue_date: "",
            expiry_date: "",
            issuing_body: ""
          }
        ]
        return cv_attributes
    end

    ## For now Passport image data extraction is pending
    # def perform_ocr(passport)
    #   return unless passport.present?
    #   image_path  = passport.path
    #   text = RTesseract.new(image_path).to_s
    #   text
    # end

    def pdf_convert(pdf_path)
      texts = PDF::Reader.new(pdf_path)
      extracted_text = texts.pages.each do |page|
      page.text
      end
      return extracted_text.join("\n")
    end

    def map_bio_data(text)
      bio_keywords = ['Bio', 'Objective', 'Resume summary', 'Resume objective', 'Career objective',
                      'Career goals', 'Personal statement', 'Professional profile',
                      'Professional summary', 'Professional objective']

      bio_pattern = bio_keywords.map { |keyword| Regexp.escape(keyword) }.join('|')
      bio_regex = build_regex(bio_pattern)

      matches = text.match(bio_regex)
      if matches
        bio = matches[2].strip.gsub(/\s+/, ' ')
      else
        bio = "Put your Bio/Summary here."
      end
    end

    def map_academic_qualification_data(text)
      academic_pattern = /Academic Details\s+seajob\.net\n\n\n #\s+Qualification\s+Board \/University\s+Passing Year\s+Percentage\n\n((?:\s+\d+\s+.*?\s+.*?\s+\d{4}\s+\d+%.*?\n)+)(?=\n\n\s+Course Details)/m
      matches = text.match(academic_pattern)
      if matches
        academic_qualifications = matches[1].strip
        qualifications = academic_qualifications.scan(/\d+\s+(.*?)\s+(.*?)\s+(\d{4})\s+(\d+%)/).map { |match| match.join(' , ') }
        return qualifications.empty? ? ["No academic qualifications found"] : qualifications
      else
        academic_qualifications = ["Fill Your Academic Courses"]
      end
    end

    def map_work_ex_data(text)
      work_ex_regex = /Seamen Experience Details\s+[^:\n]+\n\n\n(.+?)\n\n\n\s*Total Experience\s+[^:\n]+/m
      matches = text.match(work_ex_regex)
      if matches.present?
        work_ex = matches[1].strip.split(/\n\s+/)
        return work_ex
      else
        work_ex = ["Fill Your Work Experiences"]
      end
    end

    def map_passport_data(text)
      passport_regex = /Passport No\. :\s*(\w+)\s*Issue Authority :\s*(.*?)\s*Issue Date :\s*(\d{2}-\w{3}-\d{4})\s*Expiry Date :\s*(\d{2}-\w{3}-\d{4})/

      matches = text.scan(passport_regex)
      if matches.present?
        passport_data = matches.flatten
        return passport_data
      else
        passport_data = ["Fill Your passport details"]
      end
    end

    def personal_data(text)
      personal_contact_regex = /First Name\s*:\s*(.*?)\s*Middle Name\s*:\s*(.*?)\s*Sur Name\s*:\s*(.*?)\s*Email Address\s*:\s*(.*?)\s*Date Of Birth\s*:\s*(.*?)\s*Gender\s*:\s*(.*?)\s*Country\s*:\s*(.*?)\s*City\s*:\s*(.*?)\s*State\s*:\s*(.*?)\s*Zipcode\s*:\s*(.*?)\s*Phone No\s*:\s*(.*?)\s*Mobile No\s*:\s*(.*?)\s*Covid Vaccine Name\s*:\s*(.*?)(?=\n|$)/m

      matches = text.match(personal_contact_regex)

      if matches
        first_name = matches[1].strip
        middle_name = matches[2].strip
        sur_name = matches[3].strip
        email_address = matches[4].strip
        date_of_birth = matches[5].strip
        gender = matches[6].strip
        country = matches[7].strip
        city = matches[8].strip
        state = matches[9].strip
        zipcode = matches[10].strip
        phone_no = matches[11].strip
        mobile_no = matches[12].strip

        [first_name, middle_name, sur_name, email_address, date_of_birth, gender, country,
        city, state, zipcode, phone_no, mobile_no]
      else
        [matches]
      end  
    end

    def academic_hash(academics)
      acad_arr = []
      academics.map do |academic|
       acad = academic.split(' , ')
       hash = {
          course: '',
          institution: acad[1],
          qualification: acad[0],
          grade: acad[3],
          start_date: '',
          end_date: acad[2]
        }
        acad_arr << hash
      end
      return acad_arr
    end

    def work_exp_hash(work_exps)
      works = work_exps.map {|line| line.strip.split(/\s{2,}/)}
      work_arr = []
      works.map.with_index do |work, index|
        if index.odd? 
          hash = {
            company: work[2] || '',
            vessel_name: work[4] || '',
            vessel_type: works[index+1] || '',
            vessel_dwt: work[3] || '',
            vessel_imo: "",
            vessel_position: work[1] || '',
            start_date: work[5] || '',
            end_date: work[6] || '',
          }
          work_arr << hash
        elsif work[index] == "Fill Your Work Experiences"
          hash = {
            company: work[index],
            vessel_name: '',
            vessel_type: '',
            vessel_dwt: '',
            vessel_imo: "",
            vessel_position: '',
            start_date: '',
            end_date: '',
          }
          work_arr << hash
        else
          work_arr
        end
      end
      return  work_arr
    end

    def build_regex(pattern)
      regex = /(#{pattern})\s*(.+?)(?=\n{3,}|\z)/mi
      return regex
    end

    def account_update_params
      params.require(:account_data)[:attributes].permit( :full_phone_number, :gender,
        :date_of_birth, :age, :first_name, :last_name, :email )
    end

    def fetch_user_cv
      cv = current_user.try(:cv)
      return cv
    end

    def validate_email
      if account_update_params[:email].present?
        email_validator = AccountBlock::EmailValidation.new(account_update_params[:email])
        return render json: {errors: [{account: "Email invalid"}]}, status: :unprocessable_entity if !email_validator.valid?
      else
        return
      end
    end

    def check_phone_number_validity
      parsed_phone_number = Phonelib.parse(account_update_params[:full_phone_number])
      sanitized_phone_number = parsed_phone_number&.raw_national
      passed_country_code = parsed_phone_number&.country_code
      if sanitized_phone_number.present? 
        email_account = AccountBlock::EmailAccount.find_by(phone_number: sanitized_phone_number, country_code: passed_country_code)
        general_account = AccountBlock::Account.find_by(phone_number: sanitized_phone_number, country_code: passed_country_code)
        err_msg = "This Phone Number is already Registered with another account"
        render json: {errors: [{account: err_msg}]}, status: :unprocessable_entity if (!email_account.blank? || !general_account.blank?) && (email_account&.id != current_user.id || general_account&.id != current_user.id)
      end
    end

    def send_welcome_email_and_notification
      name = (current_user.full_name || "#{current_user.first_name} #{current_user.last_name}")
      WelcomeMailer.welcome_email(current_user).deliver_now
      BxBlockPushNotifications::PushNotification.create(
        notify_type: "Welcome to iSail",
        remarks: "Welcome to iSail, #{name}! Discover maritime opportunities and connections.", 
        push_notificable_type: "AccountBlock::Account", push_notificable_id: current_user.id,
        redirection_url: Rails.application.routes.url_helpers.joblistings_url(host: request.base_url)
      ) if current_user.account_role == "Jobseeker"

      BxBlockPushNotifications::PushNotification.create(
        notify_type: "Welcome to iSail",
        remarks: "Welcome to iSail, #{name}! Discover maritime connections.", 
        push_notificable_type: "AccountBlock::Account", push_notificable_id: current_user.id,
        redirection_url: Rails.application.routes.url_helpers.joblistings_url(host: request.base_url)
      ) if current_user.account_role == "Recruiter"
    end

    def read_airport_names
      airport_names = []

      CSV.foreach('public/uploads/airport_list/airports.dat', headers: true) do |row|
      i = 0
        row.headers.map do |header|
          airport_names << row[header] if i==1
          i+=1
        end
      end
      airport_names.compact.uniq
    end

    def update_linkedin_url_in_cv
      user_cv = current_user&.cv
      new_linkedin_url = current_user&.profile_bio&.linkedin_url
      user_cv.linkedin_url = new_linkedin_url
      user_cv.save!
    end

    def check_existing_user
      return unless (account_update_params[:email].present? && current_user.email != account_update_params[:email])
      user = AccountBlock::EmailAccount.where("LOWER(email) = ?", account_update_params[:email]&.strip.gsub(/\s+/, '')).first
      render json:{error: 'Email has already been taken'}, status: :unprocessable_entity and return if user.present?
    end

    # def load_account
    #   @account = AccountBlock::Account.find_by(id: params[:id])

    #   if @account.nil?
    #     render json: {
    #       message: "Account doesn't exists"
    #     }, status: :not_found
    #   end
    # end
  end
  # rubocop:enable Metrics/ClassLength, Metrics/AbcSize, Naming/MemoizedInstanceVariableName, Metrics/MethodLength, Style/GuardClause, Layout/LineLength, Lint/RescueException
end
