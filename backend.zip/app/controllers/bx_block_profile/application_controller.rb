module BxBlockProfile
  class ApplicationController < BuilderBase::ApplicationController
    include BuilderJsonWebToken::JsonWebTokenValidation
    before_action :validate_json_web_token
    # serialization_scope :view_context

    private

    def format_activerecord_errors(errors)
      result = []
      errors.each do |attribute, error|
        result << { attribute => error }
      end
      result
    end

    def current_user
      @current_user ||= AccountBlock::Account.find(@token.id) if @token.present?
    end

    def check_account_activated
      account = AccountBlock::Account.find_by(id: current_user.id)
      unless account.activated
        render json: { error: {
          message: 'Account has been not activated'
        } }, status: :unprocessable_entity
      end
    end
  end
end
