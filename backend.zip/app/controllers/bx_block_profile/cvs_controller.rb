require 'prawn'
require 'prawn/table'
module BxBlockProfile
  class CvsController < ApplicationController
    include BxBlockProfile::PdfFormatModule
    include BxBlockProfileBio::CvParamsModule

    before_action :validate_json_web_token
    before_action :check_account_activated
    before_action :find_cv, only: %i[show update destroy]

    def show
      render json: BxBlockProfile::CvSerializer.new(@cv).serializable_hash, status: :ok
    end

    def create
      if current_user.Jobseeker?
        cv = BxBlockProfile::Cv.new(cv_params)
        cv.account_id = current_user.id
        if cv.save
          render json: BxBlockProfile::CvSerializer.new(cv).serializable_hash, status: :created
        else
          render json: cv.errors, status: :unprocessable_entity
        end
      else
        render json: {error: "Only Jobseeker is authorized to perform this action."}, status: :unprocessable_entity
      end
    rescue Exception => e
      render json: {errors: [e.message]},
        status: :unprocessable_entity
    end

    def update
      if current_user.Jobseeker? && @cv.account_id == current_user.id
        if @cv.update(cv_params)
          generate_pdf(@cv)
          render json: BxBlockProfile::CvSerializer.new(@cv).serializable_hash, status: :ok
        else
          render json: {errors: @cv.errors}, status: :unprocessable_entity
        end
      else
        render json: {error: "You are not authorized to perform this action."}, status: :unprocessable_entity
      end
    rescue Exception => e
      render json: {errors: [e.message]},
        status: :unprocessable_entity
    end

    def destroy
      if current_user.Jobseeker? && @cv.account_id == current_user.id
        if @cv.destroy
          render json: {success: "CV destroyed successfully."}, status: :ok
        else
          render json: {errors: [{cv: @cv.errors.full_messages}]}, status: :unprocessable_entity
        end
      else
        render json: {error: "You are not authorized to perform this action."}, status: :unprocessable_entity
      end
    rescue Exception => e
      render json: {errors: [e.message]},
        status: :unprocessable_entity
    end

    def download_cv
      if current_user && current_user.personalise_cv.present?
        render json: {personalise_cv: current_user.personalise_cv}, status: :ok
      else
        render json: {error: "Cv Not present."}, status: :ok
      end
    end

    def certifications
      candidate = AccountBlock::Account.find_by(id: params[:candidate_id])
      if candidate.present? && params[:joblisting_id].present?
        @certificate = BxBlockJoblisting::UserJoblisting.find_by(account_id: candidate.id, joblisting_id: params[:joblisting_id])
        if @certificate.present?
          case params[:type]
          when 'stcw'
            render_certificate(@certificate.stcw, "stcw_certificate")
          when 'training_and_certifications'
            render_certificate(@certificate.training_and_certifications, "training_and_certifications")
          else
            render json: { error: "Invalid certificate type specified." }, status: :bad_request
          end
        else
          render json: { error: "No certificate found for the specified candidate and job listing." }, status: :not_found
        end
      else
        render json: { error: "Candidate ID or job listing ID not provided." }, status: :bad_request
      end
    end


    def download_candidate_cv
      candidate = AccountBlock::Account.find(params[:candidate_id])
      if candidate.present? && params[:joblisting_id].present?
        downloadable_cv = BxBlockJoblisting::UserJoblisting.find_by(account_id: candidate.id, joblisting_id: params[:joblisting_id])
        if downloadable_cv.present?
          render json: {personalise_cv: downloadable_cv.resume.url,
                        file_name: downloadable_cv.resume.file.filename}, status: :ok
        else
          render json: {error: "Cv Not present."}, status: :ok
        end
      else
        render json: {error: "Candidate Doesn't exist anymore or Joblisting is unavailable."}, status: :ok
      end
    end

    def get_location_for_cv
      if !params[:location].blank?
        set_location = params[:location]
        searched_location = Geocoder.search(set_location)
        if searched_location.present?
          searched_location_arr = params[:only_city] == 'true' ? searched_location.map{|locate| locate.address.split(',').first } : searched_location.map{|locate| locate.display_name }
          render json: { locations: searched_location_arr&.uniq }
        else
          render json: { error: "No Location found with this Name" }, status: :not_found
        end
      elsif current_user&.cv&.city.present?
        render json: { locations: [current_user&.cv&.city] }, status: :ok
      else
        render json: { locations: [] }, status: :ok
      end
    end

    private

    def render_certificate(certificate, certificate_type)
      if certificate.present?
        urls = certificate_type == 'stcw_certificate' ? { certificate_type.to_sym => certificate.url, file_name: certificate.file.filename } : certificate.map { |cert| { certificate_type.to_sym => cert.url, file_name: cert.file.filename } }
       render json: { data: urls }, status: :ok
      else
      render json: { error: "No certificate found." }, status: :not_found
      end
    end

    def find_cv
      @cv = BxBlockProfile::Cv.find(params[:id])
    end

    def generate_pdf(cv)
      data = BxBlockProfile::CvSerializer.new(cv).serializable_hash[:data][:attributes]
      temp_pdf_file = Tempfile.new(["#{current_user&.first_name}"+ "_"+ "#{current_user&.last_name}", '.pdf'])

      Prawn::Document.generate(temp_pdf_file.path) do |pdf|
        watermark_image_path = "#{Rails.root}/public/uploads/watermark_logo/jobportal-watermark.png"

        watermark_opacity = 0.1
        watermark_width = 70
        watermark_height = 30

        # Iterate through each page and add watermark logo
        pdf.repeat :all do
          pdf.image watermark_image_path,
                    at: [pdf.bounds.right, pdf.bounds.bottom],
                    width: watermark_width,
                    height: watermark_height,
                    opacity: watermark_opacity
        end

        pdf.font "Helvetica"

        pdf.text "<u>BIO</u>", inline_format: true, style: :bold, size: 12
        pdf.move_down 5
        bio_data = [[data[:bio]]]
        pdf.table(bio_data, cell_style: { border_width: 0.75, size: 10 })
        pdf.move_down 15

        pdf.text "<u>INFORMATION</u>", inline_format: true, style: :bold, size: 12
        pdf.move_down 5
        info_data = info_format(data)
        pdf.table(info_data, cell_style: { border_width: 0.75, size: 10 })
        pdf.move_down 20

        pdf.text "<u>INDOS, PASSPORT & VISA DETAILS</u>", inline_format: true, style: :bold, size: 12
        pdf.move_down 5
        pass_data = passport_format(data)
        pdf.table(pass_data, cell_style: { border_width: 0.75, size: 10 })
        pdf.move_down 20

        pdf.text "<u>SEAMEN BOOK NUMBER(S)</u>", inline_format: true, style: :bold, size: 12
        pdf.move_down 5
        seamen_data = cdc_format(data)
        pdf.table(seamen_data, cell_style: { border_width: 0.75, size: 10 })
        pdf.move_down 20

        pdf.text "<u>PROFESSIONAL / ACADEMIC QUALIFICATIONS</u>", inline_format: true, style: :bold, size: 12
        pdf.move_down 5
        acad_data = academic_format(data)
        pdf.table(acad_data, cell_style: { border_width: 0.75, size: 10 })
        pdf.move_down 20

        pdf.text "<u>LICENSE /CERTIFICATES OF COMPETENCY</u>", inline_format: true, style: :bold, size: 12
        pdf.move_down 5
        license_data = license_format(data)
        pdf.table(license_data, cell_style: { border_width: 0.75, size: 10 })
        pdf.move_down 20

        pdf.text "<u>STCW AND VALUE ADDED COURSES</u>", inline_format: true, style: :bold, size: 12
        pdf.move_down 5
        stcw_data = stcw_format(data)
        pdf.table(stcw_data, cell_style: { border_width: 0.75, size: 10 })
        pdf.move_down 20

        pdf.text "<u>WORK EXPERIENCE</u>", inline_format: true, style: :bold, size: 12
        pdf.move_down 5
        work_data = work_ex_format(data)
        pdf.table(work_data, cell_style: { border_width: 0.75, size: 10 })
        pdf.move_down 20

        pdf.text "<u>PERSONAL INFORMATION</u>", inline_format: true, style: :bold, size: 12
        pdf.move_down 5
        personal_data = personal_format(data)
        pdf.table(personal_data, cell_style: { border_width: 0.75, size: 10 })
        pdf.move_down 20
      end

      pdf_file_uploader = PdfUploader.new(current_user, :pdf)
      pdf_file_uploader.cache!(temp_pdf_file)
      pdf_file_uploader.store!
      current_user.update_column(:personalise_cv, pdf_file_uploader.url)

      temp_pdf_file.close
      temp_pdf_file.unlink
    end
  end
end
