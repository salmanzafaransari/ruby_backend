module BxBlockPromotecontent
  class FeatureContentsController < ApplicationController
    before_action :assign_contents, only: [:index]
    skip_before_action :validate_json_web_token, only: [:index]

    def index
      filter_content
      if @contents.present?
        feature_contents = BxBlockPromotecontent::FeatureContent.where(bx_block_content_management_content_managment_id: @contents.pluck(:id))
        render json: BxBlockPromotecontent::FeatureContentSerializer.new(feature_contents).serializable_hash, status: :ok
      else
        render json: {errors: "Record not found"}.to_json, status: 422
      end
    end

    def filter_content
      params.each do |key, value|
        if key == 'content_type_name'
          @contents = @contents.where(content_types: {identifier: value})
        end
      end
    end

    private

    def assign_contents
      @contents = BxBlockContentManagement::ContentManagement.published
    end
  end
end
