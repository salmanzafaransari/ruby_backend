module BxBlockJoblisting
	class UserJoblistingsController < ApplicationController
		# include BuilderJsonWebToken::JsonWebTokenValidation
        # before_action :validate_json_web_token
        # before_action :recruiter_login, only: [:show, :application_status_change]
        # before_action :parameter_check,only: [:application_status_change]
        # before_action :status_check, only: [:application_status_change]

        # def show
        #     @user_joblisting = BxBlockJoblisting::UserJoblisting.find_by(id: params[:id])
        #     if @user_joblisting.present?
        #         @user_joblisting.update(status: 'viewed')
        #         render json: UserJoblistingSerializer.new(@user_joblisting, serialization_options).serializable_hash, status: :ok
        #     else
        #         render json: {errors: "No Application found"}, status: :unprocessable_entity
        #     end
        # end

        # def application_status_change
        #     case params[:status]
        #     when 'approved'
        #         @user_joblisting.update(status: 'shortlisted')
        #     when 'rejected'
        #         @user_joblisting.update(status: 'rejected')
        #     else
        #         @user_joblisting.update(status: 'in_progress')
        #     end
        #     render json: UserJoblistingSerializer.new(@user_joblisting, serialization_options).serializable_hash, status: :ok
        # end

        # private

        # def recruiter_login
        #    if current_user.Recruiter?
        #         return true
        #    else
        #         render json: {error: "Only Recruiter Have Access To This Feature" }, status: :unprocessable_entity
        #    end
        # end

        # def parameter_check
        #     unless (params[:user_joblisting_id].present? && params[:data][:status].present?)
        #         render json: {error: "parameter missing" }, status: :unprocessable_entity
        #     end
        # end

        # def status_check
        #     @user_joblisting = BxBlockJoblisting::UserJoblisting.find_by(id: params[:user_joblisting_id])
        #     status_now = params[:status]
        #     if @user_joblisting.status_was == params[:status]
        #         render json: {error: "Already uptodated with status #{status_now}"}, status: :ok
        #     end
        # end
    end
end