module BxBlockJoblisting
	class JoblistingsController < ApplicationController
		include BuilderJsonWebToken::JsonWebTokenValidation
		
    	before_action :validate_json_web_token
		before_action :set_admin_flag, :check_signup_plan, only: [:create, :update, :apply]
		before_action :find_joblisting, only: [:show, :update, :destroy]
		before_action :jobseeker_login, only: [:index]
		before_action :recruiter_login, only: [:show_cv, :application_status_change, :recruiter_joblisting, :create, :candidates_list, :download_video_cv, :promote_joblisting]
    	before_action :parameter_check,only: [:application_status_change]
		before_action :find_joblisting_for_custom_api, only: [:show_cv, :application_status_change, :candidates_list, :promote_joblisting]
		before_action :joblisting_belongs_to_recruiter?, only: [:show_cv, :candidates_list, :update, :application_status_change]
    	before_action :status_check, only: [:application_status_change]
		before_action :validate_email, only: [:apply]
		before_action :pagination_data, only: %i[index filter_joblisting]

		def create
			@joblisting = Joblisting.new(joblisting_params)
			@joblisting.account_id = current_user.id
			@joblisting.recruiter_name = "#{current_user.first_name} #{current_user.last_name}"
			if @joblisting.save
				create_joblisting_categories(@joblisting)
				if @joblisting.valid_joblisting_category?
					send_joblisting_created_notification
					render json: JoblistingSerializer.new(@joblisting, serialization_options).serializable_hash, status: :created
      	else
					@joblisting.destroy
					render json: {errors: "Atleast One Category is Required"}, status: :unprocessable_entity
				end
			else
				render json: {errors: @joblisting.errors}, status: :unprocessable_entity
			end
		end

		def update
			if @joblisting.present?
				@joblisting.update(joblisting_params)
				create_joblisting_categories(@joblisting)
				render json: JoblistingSerializer.new(@joblisting, serialization_options).serializable_hash, status: :ok
			else
				render json: {errors: @joblisting.errors}, status: :unprocessable_entity
			end
		end

		def index
			@joblistings = params[:query].present? ? Joblisting.search_by_field(params[:query]) : Joblisting.all
			@joblistings = sort_and_prioritize_promoted_jobs(params[:sort_by])
			total_records = @joblistings&.flatten&.count
			@joblistings = Kaminari.paginate_array(@joblistings).page(@page).per(@per)
			joblisting_json = JoblistingSerializer.new(@joblistings&.flatten, serialization_options).serializable_hash
			response_json = {
				joblistings: joblisting_json,
				meta: {
					total_records: total_records,
					total_pages: (total_records.to_f / @per).ceil
				}
			}
			if @joblistings.present?
				render json: response_json, status: :ok
			else
				render json: {errors: "No job listed yet"}, status: :ok
			end
		end

		def sort_and_prioritize_promoted_jobs(sort_by)
			promoted_jobs, regular_jobs = @joblistings.partition(&:promoted)

			# promoted_jobs = promoted_jobs.sort_by(&:promoted_at).reverse
			regular_jobs = sort_joblistings(regular_jobs, sort_by)
			return regular_jobs
		end

		def sort_joblistings(joblistings, sort_by)
			case sort_by
			when "created_at"
				joblistings = joblistings.sort_by { |r| r.created_at }.reverse
			when "starting_condition"
				valid_records, invalid_records = joblistings.partition do |record|
					begin
						Date.strptime(record.starting_condition, "%d/%m/%Y")
						true
					rescue Date::Error
						false
					end
				end
				valid_records = valid_records.sort_by { |r| Date.strptime(r.starting_condition, "%d/%m/%Y") }.reverse
				joblistings = valid_records + invalid_records
			else
				current_user.cv.present? ? sort_by_past_experience(joblistings, current_user.cv) : joblistings
			end
		end

		def filter_joblisting
			@joblistings = Joblisting.all
			filter_params = %i[vessel_type job_title] 
			filter_params.each do |param|
				if params[param].present?
					@joblistings = @joblistings.where("#{param} ILIKE ?", params[param])
				end
			end
			# filter_by_date_of_creation if params[:created_at].present?
			filter_with_positions
			filter_by_salary
			@joblistings = @joblistings.order("#{params[:sort_by]} desc") if params[:sort_by].present?
			total_records = @joblistings.count
			@joblistings = @joblistings.page(@page).per(@per)
			response_json = {
				joblistings: JoblistingSerializer.new(@joblistings, serialization_options).serializable_hash,
				meta: {
					total_records: total_records,
					total_pages: (total_records.to_f / @per).ceil
				}
			}
			render json: response_json, status: :ok
		end

		def show
			render json: JoblistingSerializer.new(@joblisting, serialization_options)
				.serializable_hash, status: :ok
		end

		def candidates_list
			@user_joblistings = @joblisting.try(:user_joblistings)
			if @user_joblistings.present?
				candidate_ids = @user_joblistings.pluck(:account_id)
				final_list = []
				candidate_ids.map{|candidate_id|
				candidate = AccountBlock::Account.includes(:user_joblistings).find(candidate_id)
				status_of_application = candidate.user_joblistings.where(joblisting_id: params[:joblisting_id]).pluck(:status)&.first
				candid_hash = {
					id: candidate.id,
					name: "#{candidate.first_name} #{candidate.last_name}",
					email: candidate&.email,
					status: status_of_application,
					profile_picture: candidate.profile_bio&.selfie_picture,
					experience_in_years: candidate.profile_bio&.total_work_experience
				}
				final_list << candid_hash			
			}
			render json: final_list, status: :ok
			else
				render json: { error: "No Jobseeker applied for this joblisting yet." }, status: :ok
			end
		end

		def show_cv
			return unless params[:candidate_id].present?
			@candidate = AccountBlock::Account.find(params[:candidate_id])
			@cv = @candidate.cv
			render json: BxBlockProfile::CvSerializer.new(@cv, serialization_options)
				.serializable_hash, status: :ok if @cv.present?
			rescue ActiveRecord::RecordNotFound
				return not_found
		end

		def download_video_cv
      candidate = AccountBlock::Account.find(params[:candidate_id])
      job_application = candidate.user_joblistings.where.not(status: 'rejected')
				.find_by(joblisting_id: params[:joblisting_id])
			if candidate.present? && job_application.present?
				if job_application.video_cv.present?
					render json: { video_cv: job_application.video_cv.url, filename: job_application.video_cv.file.filename }, status: :ok
				else
					render json: { error: "Video CV not uploaded." }, status: :unprocessable_entity
				end
			else
				render json: { error: "Candidate or job application not found." }, status: :not_found
			end
    end

		def application_status_change
			@jobseeker = @user_joblisting.account
			case user_joblisting_params[:status]
			when 'approved'
				@user_joblisting.update(status: 'shortlisted')
			when 'rejected'
				@user_joblisting.update(status: 'rejected')
			else
				@user_joblisting.update(status: 'in_progress')
			end
			application_status_change_email_and_notification unless @jobseeker.notify == false
			render json: UserJoblistingSerializer.new(@user_joblisting, serialization_options).serializable_hash, status: :ok
		end

		def job_application
			@user = current_user
			@joblisting = Joblisting.find(params[:joblisting_id])
			response_body = { full_name: (@user.full_name || "#{@user.first_name} #{@user.last_name}"), email: @user.email,
			phone: @user.full_phone_number, job_id: @joblisting.id,
			video_cv: @user.profile_bio&.video_cv,stcw: @user.profile_bio&.stcw, training_and_certifications: @user.profile_bio&.training_and_certifications }

			render json: response_body, status: :ok
		end

		def apply
			@user = current_user
			begin
				@joblisting = Joblisting.find(params[:joblisting_id])
			rescue ActiveRecord::RecordNotFound
				return not_found
			end

			if @user.Jobseeker?
				@user_joblisting_status = BxBlockJoblisting::UserJoblisting.where(account_id: @user.id, joblisting_id: @joblisting.id).pluck(:status)
				if @user.joblistings.include?(@joblisting) && @user_joblisting_status.reject{ |status| status == ("rejected" || "shortlisted")}.count > 0
					render json: { error: "You have already applied to this job listing." }, status: :unprocessable_entity
				else
					@user_joblisting = @user.user_joblistings.build(application_params)
					@user_joblisting.joblisting_id = params[:joblisting_id]
					@user_joblisting.save!
					job_applied_email_and_notification unless @user.notify == false
					render json: { success: "Application submitted successfully." }, status: :ok
				end
			else
				render json: { error: "Only Jobseeker users can apply to job listings." }, status: :unprocessable_entity
			end
		rescue Exception => e
			render json: {errors: [e.message]}, status: :unprocessable_entity
		end

		def applied_joblistings
			if current_user.Jobseeker?
				@user_joblistings = current_user.user_joblistings
				if @user_joblistings.blank?
					render json: {message: "You have not applied to any jobs yet."}, status: :ok
				else
					render json: UserJoblistingSerializer.new(@user_joblistings, serialization_options).serializable_hash, status: :ok
				end
			else
				render json: {error: "Only Jobseeker users can perform this action."}, status: :unprocessable_entity
			end
		rescue Exception => e
			render json: {errors: [e.message]}, status: :unprocessable_entity
		end

		def destroy
			if @joblisting.account_id == current_user.id || ["Super Admin", "Admin"].include?(current_user.account_role)
				Joblisting.delete_joblisting_categories(@joblisting)
				@joblisting.destroy
				render json: {message: "Your Joblisting Deleted Successfully"}, status: :ok
			else
				render json: {message: "You are not authorized to perform this action."}, status: :unprocessable_entity
			end

    	rescue Exception => e
      	render json: {errors: [e.message]},
        status: :unprocessable_entity
		end

		def recruiter_joblisting
		  recruiter_joblisting = Joblisting.where(account_id: current_user.id)
		  @joblisting = params[:query].present? ? recruiter_joblisting.search_by_field(params[:query]) : recruiter_joblisting 
          render json: JoblistingSerializer.new(@joblisting, serialization_options).serializable_hash, status: :ok
		end

		# def fetch_advertisements(jobs_viewed=0)
		# 	@jobs_viewed = jobs_viewed.to_i
		# 	@recruiters = AccountBlock::Account.where(account_role: "Recruiter")
		# 	@advertisements = []
		# 	@recruiters.each do |r|
		# 		@recruiter_ads = r.advertisements
		# 		if @recruiter_ads && @recruiter_ads.first&.ads_count
		# 			ads = @recruiter_ads.first&.ads_count
		# 			per_jobs = @recruiter_ads.first&.jobs_count
		# 			count = 0
		# 			(1..ads).each do |i|
		# 				if ((per_jobs/ads) * i).between?((@jobs_viewed + 1), (@jobs_viewed + @per + 1))
		# 					count += 1
		# 				end
		# 			end
		# 			min_views = @recruiter_ads.minimum(:views)
		# 			ads_to_be_shown = @recruiter_ads.where(views: min_views).sample(count)
		# 			@advertisements << ads_to_be_shown
		# 		end
		# 	end
		# 	return @advertisements.flatten
		# end

		def promote_joblisting
			recruiter_subscription = current_user.subscriptions.find_by(promotion_type: true)
			return render json: {error: "You don't have any job promotion subscription plan."}, status: :unprocessable_entity unless recruiter_subscription.present?
			
			jobs_promoted = BxBlockJoblisting::Joblisting.where(account_id: current_user.id, promoted: true).count
			if jobs_promoted < recruiter_subscription.max_promotions
				@joblisting.update(promoted: true, promoted_at: Date.today)
				render json: JoblistingSerializer.new(@joblisting, serialization_options).serializable_hash, status: :ok
				DemoteJoblistingWorker.perform_at((Time.now + 30.days), @joblisting.id)
			else
				render json: {error: "You have promoted maximum jobs as per your plan"}, status: :ok
			end
		end

		private
		def joblisting_params
			params.require(:data)[:attributes].permit(:job_title,
				:position_location, :currency, :salary_range,
				:duration_of_position, :months_on_board,
				:months_off_board, :joblisting_icon, :open_position,
				:vessel_type, :location, :starting_condition,
				:job_description, :promoted, :promoted_at,
				:responsibilities, {required_certifications: []},
				{positions: []})
		end

		def application_params
			params.require(:data)[:attributes].permit(:full_name, :email, :full_phone_number, :resume, :video_cv, :stcw,
				{training_and_certifications: []})
		end

		def user_joblisting_params
			params.require(:data).permit(:status)
		end

		def find_joblisting
			@joblisting = Joblisting.find_by(id: params[:id])
		end

		def find_joblisting_for_custom_api
			@joblisting = Joblisting.find_by(id: params[:joblisting_id])
		end

		def create_joblisting_categories(joblisting)
			if params[:joblisting_categories].present? && params[:joblisting_categories][:attributes].present?
				category_ids = params[:joblisting_categories][:attributes][:category_ids].as_json
				sub_category_ids = params[:joblisting_categories][:attributes][:sub_category_ids].as_json
				joblisting.joblisting_categories.destroy_all if params[:action] == "update"
				@sub_categories = BxBlockCategories::SubCategory.where(id: sub_category_ids)
				category_ids.each do |cat_id|
					joblisting_category = joblisting.joblisting_categories.create(category_id: cat_id)
					@sub_categories.where(category_id: cat_id).each {|sub_cat| joblisting_category.sub_categories << sub_cat }
					joblisting_category.save
				end
			end
		end

		def filter_with_positions
			if params[:positions].present?
				positions_query = params[:positions].first.downcase
				@joblistings = @joblistings.where("EXISTS (SELECT 1 FROM unnest(positions) AS position WHERE position ILIKE ANY (array[?]))", [positions_query])	
			end
		end

		def filter_by_salary
			unless params[:lower_salary_range].blank? || params[:upper_salary_range].blank?
			lower_range = params[:lower_salary_range].present? ? params[:lower_salary_range] : 0
			upper_range = params[:upper_salary_range].present? ? params[:upper_salary_range] : 10000000
			@joblistings = @joblistings.where(salary_range: lower_range..upper_range)	
			end
		end

		# def filter_by_date_of_creation
		# 	case params[:created_at]
		# 	when "more_than_6_months"
		# 		date_range = 1.years.ago..DateTime.now
		# 	when "less_than_6_months"
		# 		date_range = 6.months.ago..DateTime.now
		# 	when "more_than_1_year"
		# 		date_range = 1.years.ago-6.months..DateTime.now
		# 	else
		# 		date_range = 2.years.ago..DateTime.now
		# 	end
		# 	@joblistings = @joblistings.where(created_at: date_range)
		# end
		
		def set_admin_flag
			$admin_flag = false
		end

		def recruiter_login
			if current_user.Recruiter?
				 return true
			else
				 render json: {error: "Only Recruiter Have Access To This Feature" }, status: :unprocessable_entity
			end
		end

		def jobseeker_login
			if current_user.Jobseeker?
				 return true
			else
				 head :unprocessable_entity
			end
		end
 
		def parameter_check
			unless (params[:joblisting_id].present? && user_joblisting_params[:status].present? && params[:user_id].present?)
				render json: {error: "parameter missing" }, status: :unprocessable_entity
			end
		end

		def joblisting_belongs_to_recruiter?
			if @joblisting.account_id == current_user.id
				return true
			else
				head :unprocessable_entity
			end
		end

		def status_check
			@user_joblisting = BxBlockJoblisting::UserJoblisting.where(joblisting_id: params[:joblisting_id], account_id: params[:user_id]).last
			status_now = user_joblisting_params[:status]
			status_was = @user_joblisting.status
			if status_was == status_now
				render json: {error: "Already updated with status #{status_now}"}, status: :ok
			elsif (status_now == 'approved' && status_was == 'shortlisted')
				render json: {error: "You have already #{status_now} the Candidate"}, status: :ok
			end
		end

		def validate_email
      email_validator = AccountBlock::EmailValidation.new(jsonapi_deserialize(params)["email"])
      return render json: {errors: [
        {account: "Email invalid"}
      ]}, status: :unprocessable_entity if !email_validator.valid?
    end

		def pagination_data
			@page = params[:page].present? ? params[:page].to_i : 1
			@per = params[:per].present? ? params[:per].to_i : 10
		end

		def sort_by_past_experience(joblistings, cv)
			@work_experiences = cv.work_experiences
			return @joblistings unless @work_experiences.present?

			@joblistings = joblistings.sort_by do |joblisting|
				relevance_score(joblisting, @work_experiences)
			end.reverse
		end

		def relevance_score(joblisting, work_experiences)
			joblisting_params = [
				joblisting.job_title,
				joblisting.job_description,
				joblisting.vessel_type,
				joblisting.positions.join(', '),
				joblisting.categories.pluck(:name).join(', ')
			]

			work_experiences_keywords = work_experiences.pluck(:vessel_name, :vessel_position, :vessel_imo, :vessel_dwt, :vessel_type).compact.flatten
			work_experiences_keywords = work_experiences_keywords.map(&:downcase).uniq

			score = 0

			joblisting_params.each do |param|
				keywords = param.downcase.split(', ')
				score += (keywords && work_experiences_keywords).size
			end

			score
		end

		def send_joblisting_created_notification
			jobseeker_ids = AccountBlock::Account.where(account_role: 'Jobseeker').where(notify: true).pluck(:id)
			return unless jobseeker_ids.present?

			title = "New Job Matches Available"
			message = "We've found a job that matches your skills and preferences. Check it out on iSail!"
			redirection_url = Rails.application.routes.url_helpers.joblisting_url(@joblisting, host: request.base_url)
			# user_id = current_user.id
			BxBlockPushNotifications::NotificationWorker.perform_async(jobseeker_ids, title, message, redirection_url)
		end

		def job_applied_email_and_notification
			push_notificable_type = "AccountBlock::Account"
			BxBlockPushNotifications::PushNotification.create(
				notify_type: "Application Confirmation", push_notificable_type: push_notificable_type, push_notificable_id: @user.id,
				remarks: "Your application for the #{@joblisting.job_title} has been received. We'll keep you updated on its progress.", 
				redirection_url: Rails.application.routes.url_helpers.joblisting_url(@joblisting, host: request.base_url)
			)
			BxBlockPushNotifications::PushNotification.create(
				notify_type: "Candidate job application", push_notificable_type: push_notificable_type, push_notificable_id: @joblisting.account_id,
				remarks: "Candidate #{@user.first_name} #{@user.last_name} has applied to your job #{@joblisting.job_title}.", 
				redirection_url: Rails.application.routes.url_helpers.joblisting_url(@joblisting, host: request.base_url)
			)
			BxBlockJoblisting::AppliedJobMailer.job_status_mail(@user, @joblisting).deliver_now
		end

		def application_status_change_email_and_notification
			BxBlockPushNotifications::PushNotification.create(
				notify_type: "Application Status changed.",
				remarks: "Your Job application for the job #{@joblisting.job_title} has been #{@user_joblisting.status}", 
				push_notificable_type: "AccountBlock::Account", push_notificable_id: @jobseeker.id,
				redirection_url: Rails.application.routes.url_helpers.joblisting_url(@joblisting, host: request.base_url)
			)
			BxBlockJoblisting::JobStatusUpdateMailer.application_status_change_email(@user_joblisting).deliver_now
		end

		def check_signup_plan
			subscription = current_user.subscriptions&.signup_subscription&.first
			return render json: {error: "You don't have access to perform this action"}, status: :unprocessable_entity unless subscription.present?
			check_expired_signup_plan(subscription)
		end

		def check_expired_signup_plan(subscription)
			user_subscription = subscription.user_subscriptions.find_by(subscription_id: subscription.id, account_id: current_user.id)
			return render json: {error: "Your Signup Plan has expired."}, status: :unprocessable_entity if user_subscription&.expiry_date < Date.today
		end
	end
end
