module BxBlockCustomAds
  class AdvertisementsController < ApplicationController
    before_action :recruiter_login, only: %i[create update destroy set_advertisements_frequency get_viewed_and_clicked_count]
    before_action :check_existing_ads, :ads_plan_and_max_ads_check, only: [:create]
    after_action :update_ads_viewed_count, only: [:index]

    def index
      @advertisements = current_user.Recruiter? ? BxBlockCustomAds::Advertisement.where(account_id: current_user.id) : BxBlockCustomAds::Advertisement.all
      if @advertisements.present?
        @advertisements.order(ads_count: :desc, created_at: :desc)
        render json: AdvertisementSerializer.new(@advertisements, serialization_options).serializable_hash, status: :ok
      else
        render json: {message: "No advertisements present."}, status: :ok
      end
    end

    def create
      @advertisement = Advertisement.new(advertisement_params)
      @advertisement.account_id = current_user.id
      if @advertisement.save
        render json: AdvertisementSerializer.new(@advertisement, serialization_options).serializable_hash, status: :created
      else
        render json: { errors: @advertisement.errors }, status: :unprocessable_entity
      end
    rescue Exception => e
      render json: {errors: [e.message]},
        status: :unprocessable_entity
    end

    def set_advertisements_frequency
			recruiter_advertisements = BxBlockCustomAds::Advertisement.where(account_id: current_user.id)
      if recruiter_advertisements.present?
        recruiter_advertisements.update_all(ads_count: params[:ads_count], jobs_count: params[:jobs_count])
        recruiter_advertisements.reload
        render json: AdvertisementSerializer.new(recruiter_advertisements, serialization_options).serializable_hash, status: :ok
      else
        render json: {error: "You don't have any advertisements yet. Please create atleast one advertisement."}, status: :unprocessable_entity
      end
		end

    def show
      @advertisement = Advertisement.find_by(id: params[:id])
      if @advertisement
        @advertisement.clicked_count_verify
        render json: AdvertisementSerializer.new(@advertisement, serialization_options).serializable_hash, status: :ok
      else
        render json: { error: "Advertisement not found" }
      end
    end

    def get_viewed_and_clicked_count
      if current_user.try(:advertisements).present?
        ads = current_user.advertisements
        params[:year] = params[:year].present? ? params[:year] : Date.today.strftime("%Y")
        total_clicked_count_monthly = monthly_count(ads, "clicked")
        total_clicked_count_in_a_year = yearly_count(ads, "clicked")
        total_viewed_count_monthly = monthly_count(ads, "viewed")
        total_viewed_count_in_a_year = yearly_count(ads, "viewed")
        render json: {monthly_clicked_count: total_clicked_count_monthly, monthly_viewed_count: total_viewed_count_monthly,
                      total_clicked_in_this_year: total_clicked_count_in_a_year, total_viewed_in_this_year: total_viewed_count_in_a_year}
      else
        render json: { error: "No Advertisement found" }
      end
    end

    private

    def advertisement_params
      params.require(:advertisement).permit( :status, :banner, :joblisting_id, :ads_count)
    end

    def recruiter_login
      return render json: {error: "You are not authorized to perform this action."}, status: :unprocessable_entity unless current_user.Recruiter?
    end

    def monthly_count(ads, type)
      total_count = {}
      ads.each do |ad|
        count = type == "clicked" ? (ad.month_wise_clicked_counts[params[:year]] || {}) : (ad.month_wise_viewed_counts[params[:year]] || {})
        count.each do |month, value|
          total_count[month] ||= 0
          total_count[month] += value
        end
      end
      sorted_count_monthly = total_count.sort_by { |month, _count| Date::MONTHNAMES.index(month) }
      result_count_hash = Hash[sorted_count_monthly]
      return result_count_hash
    end

    def yearly_count(ads, type)
      total_count = 0
      ads.each do |ad|
        count = type == "clicked" ? (ad.month_wise_clicked_counts[params[:year]] || {}) : (ad.month_wise_viewed_counts[params[:year]] || {})
        count.each do |month, value|
          total_count += value
        end
      end
      return total_count
    end

    def ads_plan_and_max_ads_check
      @subscribed_plan = current_user&.subscriptions.find_by(advertisement_type: true)
      @user_subscription = @subscribed_plan.user_subscriptions.find_by(subscription_id: @subscribed_plan&.id, account_id: current_user.id) if @subscribed_plan.present?
      if !@subscribed_plan.present?
        render_error("You don't have access to create Ads")
      elsif current_user.advertisements&.count >= @subscribed_plan.max_advertisements
        render_error("You have reached your maximum limit of Ads.")
      elsif @user_subscription&.expiry_date < Date.today
        render_error("Your Advertisement Plan has expired.")
      else
        true
      end
    end

    def render_error(message)
      render json: {error: message}, status: :unprocessable_entity
    end

    def check_existing_ads
      ad = current_user.advertisements.where(joblisting_id: advertisement_params[:joblisting_id])
      render json: {error: 'You already have a Advertisement for this Job'}, status: :unprocessable_entity if ad.present?
    end

    def update_ads_viewed_count
      @advertisements = BxBlockCustomAds::Advertisement.where(id: @advertisements.map(&:id))
      @advertisements.each do |ad|
          ad.viewed_count_verify
      end
    end
  end
end
