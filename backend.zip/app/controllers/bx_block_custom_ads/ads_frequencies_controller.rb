module BxBlockCustomAds
  class AdsFrequenciesController < ApplicationController
    before_action :recruiter_login, only: %i[index]
    
    def index
      @ads_frequencies = BxBlockCustomAds::AdsFrequency.all
      if @ads_frequencies.present?
        render json: AdsFrequencySerializer.new(@ads_frequencies, serialization_options).serializable_hash, status: :ok
      else
        render json: {message: "No Ads Frequencies present."}, status: :ok
      end
    end

    private

    def recruiter_login
      return render json: {error: "You are not authorized to perform this action."}, status: :unprocessable_entity unless current_user.Recruiter?
    end
  end
end
