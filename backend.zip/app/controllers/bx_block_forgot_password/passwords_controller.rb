module BxBlockForgotPassword
  class PasswordsController < ApplicationController
    include BuilderJsonWebToken::JsonWebTokenValidation

    before_action :validate_json_web_token, only: [:change_password]
    before_action :valid_confirmation_password, only: [:create]

    def create
      return render_missing_fields_error if missing_fields?
        # Try to decode token with OTP information
        begin
          token = BuilderJsonWebToken.decode(create_params[:token])
        rescue JWT::DecodeError => e
          return render json: {
            errors: [{
              token: 'Invalid token',
            }],
          }, status: :bad_request
        end
        # Try to get OTP object from token
        begin
          otp = token.type.constantize.find(token.id)
        rescue ActiveRecord::RecordNotFound => e
          return render json: {
            errors: [{
              otp: 'Token invalid',
            }],
          }, status: :unprocessable_entity
        end

        if otp.try(:pin) == create_params[:otp_code].to_i
          otp.activated = true
          otp.save
        else
          return render json: {
            errors: [{
              otp: 'Invalid OTP code',
            }],
          }, status: :unprocessable_entity
        end

        # Check if OTP was validated
        unless otp.activated?
          return render json: {
            errors: [{
              otp: 'OTP code not validated',
            }],
          }, status: :unprocessable_entity
        else
          # Check new password requirements
          password_validation = AccountBlock::PasswordValidation
            .new(create_params[:new_password])
          error_message = password_validation.errors.full_messages.first

          unless password_validation.valid?
            return render json: {
              errors: [{
                password: error_message,
              }],
            }, status: :unprocessable_entity
          else
            # Update account with new password
            update_account_with_new_password(otp, token)
          end
        end
    end

    def change_password
      account_id = @token.id
      user = AccountBlock::Account.find_by(id: account_id)
      new_password = params[:new_password]
      new_password_confirmation = params[:new_password_confirmation]
      password = params[:current_password]
      unless user&.authenticate(password)
        return render json: { errors: "Current Password is not correct"}, status: :unprocessable_entity
      end
      unless new_password.present? && new_password_confirmation.present?
        return render json: { errors: "Password fields can't be empty"}, status: :unprocessable_entity
      end
      unless new_password == new_password_confirmation
        return render json: { errors: "Confirmation Password doesn't match the New Password"}, status: :unprocessable_entity
      end
      response = BxBlockProfile::ChangePasswordCommand.execute(account_id, password, new_password)
      return render json: { data: response[1]}, status: response.first&.to_sym if response.first&.to_s == "created"
      return render json: { errors: response[1]&.last}, status: response.first&.to_sym
    end

    private

    def create_params
      params.require(:data)
        .permit(*[
          :email,
          :full_phone_number,
          :token,
          :otp_code,
          :new_password,
          :new_password_confirmation,
        ])
    end

    def missing_fields?
      create_params[:token].blank? || create_params[:new_password].blank? || create_params[:otp_code].blank?
    end
    
    def render_missing_fields_error
      render json: { errors: [{ otp: 'All fields are required' }] }, status: :unprocessable_entity
    end

    def valid_confirmation_password
      if create_params[:new_password] != create_params[:new_password_confirmation] 
        return render json: {
              errors: [{otp: "New Confirmation Password doesn't match the New Password",
              }],}, status: :unprocessable_entity
      else
        true
      end
    end

    def update_account_with_new_password(otp, token)
      account = AccountBlock::Account.find(token.account_id)

      if account.update(:password => create_params[:new_password])
        # Delete OTP object as it's not needed anymore
        otp.destroy

        serializer = AccountBlock::AccountSerializer.new(account)
        serialized_account = serializer.serializable_hash

        render json: serialized_account, status: :created
      else
        render json: {
          errors: [{
            profile: 'Password change failed',
          }],
        }, status: :unprocessable_entity
      end
    end
  end
end
