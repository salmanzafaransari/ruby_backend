module BxBlockHelpCentre
  class TutorialsController < ApplicationController
    before_action :find_tutorial, only: [:show_faq]

    def index
      @tutorials = BxBlockHelpCentre::Tutorial.all
      if @tutorials.present?
        render json: TutorialSerializer.new(@tutorials, serialization_options).serializable_hash, status: :ok
      else
        render json: {message: "No tutorials present."}, status: :ok
      end
    end

    def show_faq
      render json: TutorialSerializer.new(@tutorial, serialization_options).serializable_hash, status: :ok
    end

    private

    def find_tutorial
      @tutorial = BxBlockHelpCentre::Tutorial.last
    end      
  end
end
