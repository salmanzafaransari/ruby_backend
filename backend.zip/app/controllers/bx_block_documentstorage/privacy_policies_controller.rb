module BxBlockDocumentstorage
    class PrivacyPoliciesController < ApplicationController
        before_action :validate_json_web_token, except: [:show_term_and_condition, :show_static_files]

        def show_term_and_condition
        	if params[:type]
            @privacy_policy = BxBlockDocumentstorage::PrivacyPolicy.find_by(title: params[:type])
        	else
        	@privacy_policy = []
        	end
            render json: PrivacyPolicySerializer.new(@privacy_policy, serialization_options).serializable_hash, status: :ok
        end

        def show_static_files
            sanitized_filename = params[:filename].gsub(/[^0-9A-Za-z.\-]/, '_')
            file_path = File.join(Rails.root, 'public', 'static', sanitized_filename)
            if File.exist?(file_path)
              send_file file_path, type: 'text/html', disposition: 'inline'
            else
              head :not_found
            end
        end
    end
end