module BxBlockStripeIntegration
  class PaymentsController < BxBlockStripeIntegration::ApplicationController
    include BxBlockCustomUserSubs::UserSubscriptionModule

    before_action :check_create_stripe_customer, only: [:create]
    before_action :check_subscribed_plan, only: [:create, :offline_payment_request]
    before_action :check_trx_valid_user, only: [:update_online_trx_status]
    before_action :check_offline_payment_order, only: [:offline_payment_request]
    after_action :create_order_transaction, only: [:create]

    def create
      return unless validate_parameters(payment_params, %w[subscription_id])

      subscription = BxBlockCustomUserSubs::Subscription.find_by_id(payment_params[:subscription_id])
      order = BxBlockOrderManagement::Order.find_by(id: payment_params[:order_id])
      if subscription.present? && order.present?
        amount = (order.sub_total.to_f * 100).to_i       
          begin
            customer_ephemeral_key = customer_ephemeral_key() 
            stripe_payment_intent = payment_intent_data(@result, amount, subscription) 
            render json: {'stripe_payment_intent': PaymentIntentSerializer.new(PaymentIntent.new(stripe_payment_intent)).serializable_hash,'ephemeral_key': customer_ephemeral_key['secret']}
          rescue Stripe::StripeError => e
            render json: {errors: [{stripe: e.message}]}, status: :unprocessable_entity
          end
      else
        render json: {errors: [subscription: "Plan is no more Active."]}, status: :not_found
      end
    end

    def offline_payment_request
      if order_trx_params[:order_management_order_id].present? && order = BxBlockOrderManagement::Order.find_by_id(order_trx_params[:order_management_order_id])
          trx_params_data(order)
        ot = BxBlockOrderManagement::OrderTransaction.create(order_trx_params)
        ot.account_id = current_user.id
        ot.save!
        render json: {success: "Your request has been created, iSail team will contact you soon."}
      else
        render json: {errors: [order: "Subscription not Active anymore."]}, status: :not_found
      end
    end

    def update_online_trx_status
      return unless params[:status].present?
      status = params[:status] == 'succeeded' ? 'Successful Transaction' : 'Failed Transaction'
      @trx.update_columns(charge_status: status, plan_type: params[:type] )
      order_status_update(@trx, status)
      if status == 'Successful Transaction'
        params[:payment_for] == 'updating_plan' ? change_plan(current_user, params[:subscription_id],  params[:type]) : assign_subscription_to_user(current_user, params[:subscription_id])
        BxBlockStripeIntegration::PaymentMailer.payment_received_email(current_user, @trx).deliver_now
        render json: { success: 'You have successfully subscribed to a new plan.' }, status: :ok
      else
        BxBlockStripeIntegration::PaymentMailer.payment_failed_email(current_user, @trx).deliver_now
        render json: {failed: 'Payment has Failed. Please fill the card details correctly.'}, status: :ok
      end
    end

    def confirm
      return unless validate_parameters(payment_params, %w[payment_method_id payment_intent_id])

      unless current_user.stripe_id.present?
        render json: {
          error: "Customer stripe id is not found"
        }, status: :not_found and return
      end

      begin
        stripe_payment_intent = Stripe::PaymentIntent.confirm(
          payment_params[:payment_intent_id],
          {
            payment_method: payment_params[:payment_method_id],
            receipt_email: current_user.email
          }
        )
        render json: PaymentIntentSerializer.new(PaymentIntent.new(stripe_payment_intent)).serializable_hash
      rescue Stripe::StripeError => e
        render json: {
          errors: [{stripe: e.message}]
        }, status: :unprocessable_entity
      end
    end

    private

    def payment_params
      params.require(:payment).permit(:order_id, :subscription_id, :payment_method_id, :payment_intent_id)
    end

    def order_trx_params
      params.permit(:order_management_order_id, :amount, :payment_type, :charge_status,:subscription_id, :user_name, :currency, :user_email, :plan_type)
    end

    def payment_method_params
      params.require(:payment_method).permit(:number, :exp_month, :exp_year, :cvc)
    end

    def billing_params
      params.require(:details).permit(:name)
    end

    def payment_intent_data(pm_data, amount, subscription)
      Stripe::PaymentIntent.create(
              customer: current_user.stripe_id,
              amount: amount,
              currency: 'usd',
              #payment_method: pm_data.id,
              automatic_payment_methods: {
                enabled: true,
              },
              description: "Amount #{subscription.currency}#{amount/100} charged for #{subscription.name}."
            )
    end

    def customer_ephemeral_key
      Stripe::EphemeralKey.create({
        customer: current_user.stripe_id,
      }, {stripe_version: '2024-04-10'})
    end

    def create_order_transaction
      return unless payment_params[:order_id].present?
      trx_amount = BxBlockOrderManagement::Order.find(payment_params[:order_id])&.sub_total
      BxBlockOrderManagement::OrderTransaction.create(
        order_management_order_id: payment_params[:order_id], account_id: current_user&.id,
        payment_type: 'online', subscription_id: payment_params[:subscription_id],
        charge_status: payment_initiated, amount: trx_amount, currency: 'usd',
        user_name: "#{current_user.first_name} #{current_user.last_name}",
        user_email: current_user.email)
    end

    def trx_params_data(order)
      params[:user_email] = current_user.email
      params[:payment_type] = 'offline'
      params[:amount] = order&.sub_total
      params[:currency] = 'usd'
      params[:charge_status] = payment_initiated
      params[:user_name] =  "#{current_user.first_name} #{current_user.last_name}"
      params
    end

    def check_trx_valid_user
      @trx = BxBlockOrderManagement::OrderTransaction.where(order_management_order_id: params[:order_id]).where(account_id: current_user.id)&.last
      unless @trx.present?
        head :forbidden
      end
    end

    def order_status_update(order_trx, order_status)
      order = BxBlockOrderManagement::Order.find(order_trx.order_management_order_id)
      order.update_column(:status, order_status)
      order
    end

    def check_subscribed_plan
    if params[:payment] && params[:payment][:subscription_id].present?
      check_subscription(params[:payment][:subscription_id])
    elsif params[:subscription_id].present?
      check_subscription(params[:subscription_id])
    else
      render json: { errors: [{ subscription: "Plan is no longer active." }] }, status: :not_found
    end
  end

  def check_subscription(subscription_id)
    user_subscription = current_user.user_subscriptions.where(subscription_id: subscription_id)&.first
    if (user_subscription.present? && user_subscription.expiry_date >= Date.today)
      render json: { error: "You have already subscribed to this plan." }, status: :unprocessable_entity
    else
      true
    end
  end

  def check_offline_payment_order
    order_trx = BxBlockOrderManagement::OrderTransaction.where(account_id: current_user.id).where(charge_status: payment_initiated)
    unless !order_trx.present?
      render json: {error: 'You already have a request. Please wait till iSail team contacts.'}, status: :unprocessable_entity
    end
  end

  def detach_card
    payment_method_id = @result&.id
    if payment_method_id.present? && payment_method_id != payment_params[:payment_method_id]
      begin
      Stripe::PaymentMethod.detach(payment_method_id)
      rescue Stripe::StripeError => e
        render json: {errors: [{stripe: e.message}]}, status: :ok
      end
    else
      true
    end
  end

  end
end
