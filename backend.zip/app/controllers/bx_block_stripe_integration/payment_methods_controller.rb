module BxBlockStripeIntegration
  class PaymentMethodsController < BxBlockStripeIntegration::ApplicationController
    before_action :check_create_stripe_customer, only: [:index, :create]

    def index
      stripe_payment_methods = Stripe::PaymentMethod.list(customer: current_user.stripe_id, type: "card")
      payment_methods = []
      stripe_payment_methods.each do |stripe_pm|
        payment_methods << PaymentMethod.new(stripe_pm)
      end
      render json: PaymentMethodSerializer.new(payment_methods, params: {user: current_user}).serializable_hash
    rescue Stripe::StripeError => e
      render json: {
        errors: [{stripe: e.message}]
      }, status: :unprocessable_entity
    end    
  end
end
