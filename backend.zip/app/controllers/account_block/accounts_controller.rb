module AccountBlock
  class AccountsController < ApplicationController
    include BuilderJsonWebToken::JsonWebTokenValidation

    before_action :validate_json_web_token, only: [:search, :change_email_address, :change_phone_number, :specific_account, :logged_user, :destroy, :deactivate, :save_device_token, :get_location, :update_location, :notification_status_change]
    before_action :find_account, only: [:get_location, :destroy, :change_phone_number, :change_email_address, :specific_account, :logged_user, :deactivate, :save_device_token, :update_location, :notification_status_change]
    before_action :validate_email, :password_confirmation_check, :validate_password, :check_privacy_policy_status, only: [:create]

    def create
      case params[:data][:type] #### rescue invalid API format
      when "sms_account"
        # validate_json_web_token

        # unless valid_token?
        #   return render json: {errors: [
        #     {token: "Invalid Token"}
        #   ]}, status: :bad_request
        # end

        # begin
        #   @sms_otp = SmsOtp.find(@token[:id])
        # rescue ActiveRecord::RecordNotFound => e
        #   return render json: {errors: [
        #     {phone: "Confirmed Phone Number was not found"}
        #   ]}, status: :unprocessable_entity
        # end

        # params[:data][:attributes][:full_phone_number] =
        #   @sms_otp.full_phone_number
        # @account = SmsAccount.new(jsonapi_deserialize(params))
        # @account.activated = true

        # save_sms_account(@account)
      when "email_account"
        account_params = jsonapi_deserialize(params)
        query_email = account_params["email"]&.strip.gsub(/\s+/, '').downcase
        account = EmailAccount.where("LOWER(email) = ?", query_email).first

        if account
          @object = check_profile_bio_existent(account)
          return render json: @object[:response], status: @object[:status].to_sym
        end

        @account = EmailAccount.new(jsonapi_deserialize(params))
        @account.platform = request.headers["platform"].downcase if request.headers.include?("platform")

        save_email_account(@account)
      when "social_account"
        # @account = SocialAccount.new(jsonapi_deserialize(params))
        # @account.password = @account.email
        # save_social_account(@account)
      else
        render json: {errors: [
          {account: "Invalid Account Type"}
        ]}, status: :unprocessable_entity
      end
    end

    # def search
    #   @accounts = Account.where(activated: true)
    #     .where("first_name ILIKE :search OR " \
    #                        "last_name ILIKE :search OR " \
    #                        "email ILIKE :search", search: "%#{search_params[:query]}%")
    #   if @accounts.present?
    #     render json: AccountSerializer.new(@accounts, meta: {message: "List of users."}).serializable_hash, status: :ok
    #   else
    #     render json: {errors: [{message: "Not found any user."}]}, status: :unprocessable_entity
    #   end
    # end

    def change_email_address#jobseeker/recruiter can change their email with this API
      query_email = params["new_email"]
      account = EmailAccount.where("LOWER(email) = ?", query_email).first

      validator = EmailValidation.new(query_email)

      if account || !validator.valid?
        return render json: {errors: "Email invalid"}, status: :unprocessable_entity
      else
        @account.update(email: query_email)
        render json: AccountSerializer.new(@account).serializable_hash, status: :ok
      end
    end

    def change_phone_number
      if @account && @account.update(full_phone_number: params["full_phone_number"])
        render json: AccountSerializer.new(@account).serializable_hash, status: :ok
      # else
      #   render json: {errors: "account user phone_number is not updated"}, status: :unprocessable_entity
      end
    end

    def specific_account
      if @account && @account.present?
        render json: AccountSerializer.new(@account).serializable_hash, status: :ok
      end
    end

    # def index
    #   @accounts = Account.all
    #   if @accounts.present?
    #     render json: AccountSerializer.new(@accounts).serializable_hash, status: :ok
    #   else
    #     render json: {errors: "accounts data does not exist"}, status: :unprocessable_entity
    #   end
    # end

    def logged_user
      if @account && @account.present?
        render json: AccountSerializer.new(@account).serializable_hash, status: :ok
      end
    end

    #jobseeker/recruiter can delete their account with this API
    def destroy
      if @account && @account.destroy
        render json: {success: "account deleted successfully."}, status: :ok
      end
    end

    def deactivate
      if @account && @account.update(status: 'deactivate', activated: false)
        render json: {success: "account deactivated successfully."}, status: :ok
      end
    end

    def check_profile_bio_existent(account)
      if account.profile_bio
        response = {errors: [
          {account: "Account already exist!"}
        ]}
        status = "unprocessable_entity"
        @object = {response: response, status: status}
      else
        # EmailValidationMailer
        # .with(account: account, host: request.base_url)
        # .activation_email.deliver #rescue nil
        response = EmailAccountSerializer.new(account, meta: {
          token: encode(account.id)}).serializable_hash
        status = "created"
        @object = {response: response, status: status}
      end
      @object
    end

    def save_email_account(account)
      if account.save
        # EmailValidationMailer
        #   .with(account: account, host: request.base_url)
        #   .activation_email.deliver #rescue nil
        render json: EmailAccountSerializer.new(account, meta: {
          token: encode(account.id)
        }).serializable_hash, status: :created
      else
        render json: {errors: account.errors&.full_messages},
          status: :unprocessable_entity
      end
    end

    # def save_social_account(account)
    #   if account.save
    #     render json: SocialAccountSerializer.new(account, meta: {
    #       token: encode(account.id)
    #     }).serializable_hash, status: :created
    #   else
    #     render json: {errors: format_activerecord_errors(account.errors)},
    #       status: :unprocessable_entity
    #   end
    # end

    # def save_sms_account(account)
    #   if account.save
    #     render json: SmsAccountSerializer.new(account, meta: {
    #       token: encode(account.id)
    #     }).serializable_hash, status: :created
    #   else
    #     render json: {errors: format_activerecord_errors(account.errors)},
    #       status: :unprocessable_entity
    #   end
    # end

    def save_device_token
      if @account.device_ids.include?(params[:device_id])
        return render json: {message: "Device token already present"}, status: :ok
      else
        @account.device_ids << params[:device_id]
        @account.save
        render json: AccountSerializer.new(@account).serializable_hash, status: :ok
      end
    end

    def get_location
      if !params[:location].blank?
        set_location = params[:location]
        searched_location = Geocoder.search(set_location)
        if searched_location.present?
          searched_location_arr = params[:only_city] == 'true' ? searched_location.map{|locate| locate.address.split(',').first } : searched_location.map{|locate| locate.display_name }
          render json: { locations: searched_location_arr }
        else
          render json: { error: "No Location found with this Name" }, status: :not_found
        end
      elsif @account.profile_bio.try(:country).present? && city_data[@account.profile_bio.try(:country)].present?
        cities = cities_list
        render json: { locations: cities }
      else
        locations = city_data.flat_map { |country, cities| cities.map { |city| "#{city}, #{country}" } }
        locations << @account.user_location unless (@account.user_location.nil? || locations.include?(@account.user_location))
        render json: { locations: locations }
      end
    end

    def update_location
      return unless @account
      if params[:new_location].present? 
        if @account.try(:user_location) != params[:new_location]
          @account.update(user_location: params[:new_location])
          render json: AccountSerializer.new(@account).serializable_hash, status: :ok
        else
          render json: {errors: "Your Location is already Updated"}, status: :ok
        end
      else
        render json: {errors: "You Haven't Selected any Location"}, status: :unprocessable_entity
      end
    end

    def notification_status_change
      @account.notify == true ? @account.update_column(:notify, false) : @account.update_column(:notify, true)
      render json: AccountSerializer.new(@account).serializable_hash, status: :ok
    end

    private

    # def format_activerecord_errors(errors)
    #   result = []
    #   errors.each do |attribute, error|
    #     if (attribute.to_s == "password") && (error == "is invalid")
    #       result << { attribute => "must be one capital letter, one lowercase letter, one numeric and minimum 8 digit." }
    #     else
    #       result << { attribute => error }
    #     end
    #   end
    #   result
    # end

    def encode(id)
      BuilderJsonWebToken.encode id
    end

    # def search_params
    #   params.permit(:query)
    # end
    
    def find_account
      @account = Account.find(@token.id)
    end

    def validate_email
      email_validator = EmailValidation.new(jsonapi_deserialize(params)["email"])
      return render json: {errors: [
        {account: "Email invalid"}
      ]}, status: :unprocessable_entity if !email_validator.valid?
    end

    def validate_password
      password_validator = PasswordValidation.new(jsonapi_deserialize(params)['password'])
      return render json: {errors: [
        {account: password_validator.errors&.full_messages&.first}
      ]}, status: :unprocessable_entity if !password_validator.valid?
    end

    def check_privacy_policy_status
      return render json: {errors: [
        {account: "Please accept Privacy Policy."}
      ]}, status: :unprocessable_entity unless params[:data][:privacy_policy].present? || params[:data][:privacy_policy].to_s == "true"
    end

    def password_confirmation_check
      return render json: {errors: [
        {account: "Password Confirmation is missing."}
      ]}, status: :unprocessable_entity unless params[:data][:attributes][:password_confirmation].present?
    end

    def cities_list
      country = @account.profile_bio.try(:country)
      location_country = city_data[country]
      cities = location_country.map { |location| "#{location}, #{country}" }
      cities << @account.user_location unless (@account.user_location.nil? || cities.include?(@account.user_location))
      cities
    end

    def city_data
      {
        "India" => ["Mumbai", "Delhi", "Bangalore", "Chennai", "Kolkata"],
        "United States" => ["New York", "Los Angeles", "Chicago", "San Francisco", "Miami"],
        "United Kingdom" => ["London", "Manchester", "Birmingham", "Edinburgh", "Glasgow"],
        "Canada" => ["Toronto", "Vancouver", "Montreal", "Calgary", "Ottawa"],
        "Australia" => ["Sydney", "Melbourne", "Brisbane", "Perth", "Adelaide"],
        "France" => ["Paris", "Marseille", "Lyon", "Toulouse", "Nice"],
        "Germany" => ["Berlin", "Munich", "Hamburg", "Cologne", "Frankfurt"],
        "Brazil" => ["Sao Paulo", "Rio de Janeiro", "Brasilia", "Salvador", "Fortaleza"],
        "Japan" => ["Tokyo", "Osaka", "Kyoto", "Nagoya", "Sapporo"],
        "South Africa" => ["Johannesburg", "Cape Town", "Durban", "Pretoria", "Port Elizabeth"],
        "Saudi Arabia" => ["Riyadh", "Jeddah", "Mecca", "Medina", "Dammam"],
        "United Arab Emirates" => ["Dubai", "Abu Dhabi", "Sharjah", "Ajman", "Ras Al Khaimah"],
        "Qatar" => ["Doha", "Al Rayyan", "Al Wakrah", "Mesaieed", "Al Khor"],
        "Egypt" => ["Cairo", "Alexandria", "Giza", "Shubra El-Kheima", "Port Said"],
        "Turkey" => ["Istanbul", "Ankara", "Izmir", "Bursa", "Antalya"]
      }
    end
  end
end
